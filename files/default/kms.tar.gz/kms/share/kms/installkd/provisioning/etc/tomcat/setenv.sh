export DISPLAY=:2
export JAVA_OPTS="-server -Xmx512m -Xss16m -XX:+AggressiveHeap -Djava.awt.headless=true"