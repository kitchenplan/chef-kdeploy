kms
===

A collection of scripts to streamline development @kunstmaan

Install server:
===============
```
git clone git@github.com:Kunstmaan/kms.git
sudo mv kms /opt/kms
sudo /opt/kms/libexec/kms-installkd /opt/kms/share/kms/installkd/ mysqlrootpassword
```
install kDeploy:
================
see https://github.com/Kunstmaan/kDeploy#ubuntu
