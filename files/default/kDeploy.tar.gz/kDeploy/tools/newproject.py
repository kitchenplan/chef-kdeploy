#!/usr/bin/env python

import sys
sys.path.append('/usr/lib/python%s/site-packages/oldxml' % sys.version[:3])

from smllib.query import query
from smllib.information import Information
from smllib.shell import *
from smllib.skeleton import SkeletonCopier
import smllib.postman
import smllib.projectinformation
import smllib.aspn

smllib.aspn.lock()


globalConfig = smllib.projectinformation.getBaseInformation()
p = Information(None)
p.mergeWith(globalConfig)

if (len(sys.argv) < 1):
    p.queryUser("project.name")
else:
    p['project.name'] = sys.argv[1]

while p['project.name'] in smllib.projectinformation.getProjects():
    smllib.shell.warn("A project with name %s already exists!" % p['project.name'])
    p.queryUser("project.name")

p.queryUser("project.dir")
p.queryUser("project.user")
p.queryUser("project.group")

action("creating project " + p['project.name'])
CMD("mkdir -p %s" % p["project.dir"])
p.bindXML("%s/conf/config.xml" % (p["project.dir"]))
skeletonName = "base"
skc = SkeletonCopier(skeletonName, p["config.skeletonsdir"]+"/" + skeletonName , p["project.dir"])
skc.performAction(p)
p.save()
actionok()

action("Sending log to admin")
smllib.postman.getThePostman().send("Project Creation: %s" % p['project.name'])
actionok()

D("Now start applying skeletons to your project with applyskel.py.", 0)

smllib.aspn.unlock()
