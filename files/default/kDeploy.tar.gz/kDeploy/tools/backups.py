#!/usr/bin/env python

import sys

from smllib.information import Information
import smllib.projectinformation
import smllib.backup
import smllib.aspn


smllib.aspn.lock()

#overwrite projectnames list with a single string if one particular project is supplied as
#command line argument

quickMode = False
allQuick = False
if len(sys.argv) > 1:
	projectnames = []
	for i in range(1,len(sys.argv)):
	        if sys.argv[i] in ["all-quick"]:
	                quickMode = True
	                allQuick = True
		if sys.argv[i] in ["quick","q"] :
    			quickMode = True
		else :
			projectnames.append(sys.argv[i])
else:
	projectnames = smllib.projectinformation.getProjects()

if allQuick:
	projectnames = smllib.projectinformation.getProjects()


# generate list of projectInformations
globalConfig = smllib.projectinformation.getBaseInformation()
projects = []
for project in projectnames:
	#load the project's configuration
	projectInformation = Information(None)
	projectInformation.bindXML("%s/%s/conf/config.xml" % (globalConfig['config.projectsdir'], project))
	projectInformation.mergeWith(globalConfig)
	projects.append(projectInformation)

for p in projects:
    smllib.backup.doBackup(p, quickMode)


smllib.aspn.unlock()
