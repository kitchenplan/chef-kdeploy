# superclass for all creation plugins.
# (kind of interface-hack)

#this line is necessary for all implementations of this class
#from smllib.creationplugin import CreationPlugin

import smllib.shell

class CreationPlugin:
	def __init__(self):
		pass
		
	def getAbout(self):
		"""
			returns a string containing the reason for this plugins existance
		"""
		smllib.shell.showerror("getAbout not implemented in %s" % self.getPluginName())
	    	raise UserWarning()

	def getPluginName(self):
		"""
			returns the name of this plugin (string)
		"""
		smllib.shell.showerror("getPluginName not implemented")
	    	raise UserWarning()
		
	def performAction(self, information):
		"""
			does what this plugin is made for, once per project
		"""
		smllib.shell.showerror("doOnProject not implemented in %s" % self.getPluginName())
	    	raise UserWarning()	  
		
#def getPlugin():
#    return CreationPlugin()