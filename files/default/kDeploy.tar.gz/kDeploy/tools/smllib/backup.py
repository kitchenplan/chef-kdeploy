from smllib.shell import *
import smllib.tarmodule
from smllib.information import Information
from smllib.plugins import Loader
import smllib.projectinformation
import sys

#this script will backup a project

#load global configuration
globalConfig = smllib.projectinformation.getBaseInformation()

# generate instances for every plugin in the system
# each plugin is now referencable from the plugin hash
# with its corresponding skeleton as key
skeletons = os.listdir(globalConfig['config.skeletonsdir'])
#skeletons.remove("CVS")
plugins = {}
for skeleton in skeletons:
    skeletondir = globalConfig["config.skeletonsdir"] + "/" + skeleton
    plugindir = skeletondir + "/plugins/backup"
    pluginloader = Loader(plugindir)
    plugins[skeleton] = pluginloader.loadPlugins()

def doBackup(projectinformation, quickMode):

	backupConfig = Information(None)
	backupConfig.bindXML("%s/%s/conf/backup.xml" % (globalConfig['config.projectsdir'], projectinformation['project.name']))
	projectinformation.mergeWith(backupConfig)
	#do pre tar stuff (e.g. database dumps, include and exclude lists, ...)
	action("Executing pre-backup operations on project %s" % projectinformation['project.name'])
	for skeleton in projectinformation['project.skeletons']:
		if skeleton in plugins:
			for plugin in plugins[skeleton]:
				plugin.doPreTar(projectinformation)	
	actionok()

	#tar the project
	if quickMode == False :
		action("Storing project %s" % projectinformation['project.name'])
		smllib.tarmodule.tarProject(projectinformation, globalConfig['config.backupdir'], projectinformation['backup.excludes'])
		actionok()
	
	#do post tar stuff (e.g. removing temporary files)
	action("Executing post-backup operations on project %s" % projectinformation['project.name'])
	for skeleton in projectinformation['project.skeletons']:
		if skeleton in plugins:
			for plugin in plugins[skeleton]:
				plugin.doPostTar(projectinformation)	
	actionok()
	
	action("Sending log to admin")
	smllib.postman.getThePostman().send("Project Backup: %s" % projectinformation['project.name'])
	actionok()