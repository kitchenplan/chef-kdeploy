# superclass for all maintenance plugins.
# (kind of interface-hack)

#this line is necessary for all implementations of this class
#from smllib.maintenanceplugin import MaintenancePlugin

import smllib.shell

class MaintenancePlugin:
	def __init__(self):
		pass
		
	def getAbout(self):
		"""
			returns a string containing the reason for this plugins existance
		"""
		smllib.shell.showerror("getAbout not implemented in %s" % self.getPluginName())
	    	raise UserWarning()

        def canSkip(self):
                """
                	returns true if this plugin can be skipped in quick mode
                """
		return False
            
	def getPluginName(self):
		"""
			returns the name of this plugin (string)
		"""
		smllib.shell.showerror("getPluginName not implemented")
	    	raise UserWarning()
	
	def checkPreconditions(self, information):
		"""
			runs before the plugin is really executed
			the plugin will only have effect if it passes this test
		"""
	    	smllib.shell.showerror("checkPreconditions not implemented")
	    	raise UserWarning()
	
	def doPreProjects(self):
		"""
			does dome pre processing before the doOnProject
			happens only once (not once per project!)
		"""
		smllib.shell.showerror("doPreProjects not implemented in %s" % self.getPluginName())
	    	raise UserWarning() 
		
	def doOnProject(self, information):
		"""
			actually does what this plugin is made for, once per project
		"""
		smllib.shell.showerror("doOnProject not implemented in %s" % self.getPluginName())
	    	raise UserWarning()

	def doPostProjects(self):
		"""
			does dome post processing after the doOnProject
			happens only once (not once per project!)
		"""
		smllib.shell.showerror("doPostProjects not implemented in %s" % self.getPluginName())
	    	raise UserWarning()