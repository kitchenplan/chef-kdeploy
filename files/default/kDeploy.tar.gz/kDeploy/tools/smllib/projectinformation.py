import os
from smllib.information import Information

def existsFile(filename):
        """
               check if a file exists (python / jython)
        """
        try:
        	return os.access(filename,os.F_OK)
	except AttributeError:
		""" assuming jython """
		import java.io.File
		return java.io.File(filename).isFile()

def getBaseProjectDir():
	projdir = getBaseInformation()["config.projectsdir"]
	if "config.projectsdirprefix" in getBaseInformation().keys():
		projdir = getBaseInformation()["config.projectsdirprefix"]+projdir
	getBaseInformation()["tmp.projectsdir"] = projdir
	return projdir

def getProjectDirs():
	"""
		returns array of valid projectdirs
		and are considered to be valid if a file named /conf/config.xml exists
		this array can be empty, but not null
	"""
	projdir = getBaseProjectDir()

	dirs = [projdir + x for x in os.listdir(projdir) if existsFile(projdir + x + "/conf/config.xml")]
	if len(dirs) == 0:
	    print("*WARNING* no projects found in %s" % projdir)
	return dirs

def getProjectDir(projName):
    """
        returns the projectdir of projName 
        and is considered to be valid if a file named /conf/config.xml exists
        if valid it returns a string with the projectdir, else it returns null
    """
    projDir = getBaseProjectDir()
    if existsFile(projDir + projName + "/conf/config.xml"):
        return projDir + projName 
    else:
        print("*WARNING* no project %s found in  %s" % (projName,projDir))
        return None
	
baseconfig = []
def getBaseInformation():
    if (len(baseconfig) == 0):
	globalConfig = Information(None)
	globalConfig.bindXML("./config.xml")
	baseconfig.append(globalConfig)
    return baseconfig[0]

def getProjects():
	"""
		returns a list of valid projects on this machine
		a project is considered to be valid if a file named /conf/config.xml exists
		in the projectdir
	"""
	projdir = getBaseProjectDir()

	#this is needed only for the first time...
	os.system("mkdir -p %s" % projdir)
	
	projdirs = os.listdir(projdir)
	return [x for x in projdirs if existsFile(projdir + "/" + x + "/conf/config.xml")]
