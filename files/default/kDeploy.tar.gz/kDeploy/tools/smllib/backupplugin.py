# superclass for all maintenance plugins.
# (kind of interface-hack)

#this line is necessary for all implementations of this class
#from smllib.maintenanceplugin import MaintenancePlugin

import smllib.shell

class BackupPlugin:
	def __init__(self):
		pass
		
	def getAbout(self):
		"""
			returns a string containing the reason for this plugins existance
		"""
		smllib.shell.showerror("getAbout not implemented in %s" % self.getPluginName())
	    	raise UserWarning()

	def getPluginName(self):
		"""
			returns the name of this plugin (string)
		"""
		smllib.shell.showerror("getPluginName not implemented")
	    	raise UserWarning()
	
	def doPreTar(self):
		"""
			does dome pre processing before the doOnProject
			happens only once (not once per project!)
		"""
		smllib.shell.showerror("doPreProjects not implemented in %s" % self.getPluginName())
	    	raise UserWarning() 
		
	def doPostTar(self):
		"""
			does dome post processing after the doOnProject
			happens only once (not once per project!)
		"""
		smllib.shell.showerror("doPostProjects not implemented in %s" % self.getPluginName())
	    	raise UserWarning()