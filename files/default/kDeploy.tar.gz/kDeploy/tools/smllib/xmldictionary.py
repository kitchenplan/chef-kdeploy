import xml.dom.minidom
import os
import smllib.improvexml

class XMLDictionary:
	def __init__(self, filename):
		self.filename = filename
		self.toSave = ["project"]
		try:
			self.doc = xml.dom.minidom.parse(filename)
		except IOError:
			self.doc = xml.dom.minidom.Document()
			configNode = self.doc.createElement('config')
			self.doc.appendChild(configNode)
		
		self.dict = self._getDict()

	def __str__(self):
		return '<XML Dictionary: ' + Print(self.doc) + ' >'

	#returns the first <config> node in de XML file (there should be only one)
	#and creates one when none is found
	def _getConfigNode(self):
		el = self.doc.getElementsByTagName('config')
		if (len(el) == 0):
		    configNode = self.doc.createElement('config')
		    self.doc.appendChild(configNode)
		    return configNode
		return el[0]

	def _getVarNodes(self):
		return self._getConfigNode().getElementsByTagName('var')

	def _getDict(self):
		dict = {}
		for x in self._getVarNodes():
			name = str(x.getAttribute('name'))
			value = str(x.getAttribute('value'))
			items = x.getElementsByTagName("item")
			if (len(items) > 0):
			    value = []
			    for item in items:
				value.append(str(item.getAttribute('value')))
			dict[name] = value
		return dict
	
	def __getitem__(self, key):
		return self.dict[key]

	def __setitem__(self, key, value):
		self.dict[key] = value

	def __delitem__(self, key):
		del self.dict[key]

	def __len__(self):
		return len(self.dict)

	def __contains__(self, key):
	    	return key in self.keys()
		
	def keys(self):
		return self.dict.keys()

	def _haveToSave(self, key):
		for x in self.toSave:
		    	if key.startswith(x):
			    	return True
		return False

	def _saveDict(self):
		cn = self._getConfigNode()
		vn = self._getVarNodes()
		[cn.removeChild(x) for x in vn]
		
		for key in self.dict.keys():
			if (self._haveToSave(key)):
				vn = self.doc.createElement('var')
				vn.setAttribute('name',key)
				if (type(self.dict[key]) == str):
					vn.setAttribute('value',self.dict[key])
				if (type(self.dict[key]) == list):
				    	for item in self.dict[key]:
					    xitem = self.doc.createElement('item')
					    xitem.setAttribute('value',item)
					    vn.appendChild(xitem)
				cn.appendChild(vn)

	def save(self):
		self._saveDict()
		#PrettyPrint(self.doc)
		myf = file("%s-new" % self.filename, 'w')
		myf.write(smllib.improvexml.makeXMLReadable(self.doc))
		###PrettyPrint(self.doc, myf)
		myf.close()
		os.system("mv %s-new %s" % (self.filename,self.filename))
