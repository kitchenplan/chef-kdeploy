from smllib.shell import *
import smllib.tarmodule
from smllib.information import Information
from smllib.plugins import Loader
import smllib.projectinformation
import sys

#this script will remove a project

#load global configuration
globalConfig = smllib.projectinformation.getBaseInformation()

# generate instances for every plugin in the system
# each plugin is now referencable from the plugin hash
# with its corresponding skeleton as key
skeletons = os.listdir(globalConfig['config.skeletonsdir'])
#skeletons.remove("CVS")
plugins = {}
for skeleton in skeletons:
    skeletondir = globalConfig["config.skeletonsdir"] + "/" + skeleton
    plugindir = skeletondir + "/plugins/removal"
    pluginloader = Loader(plugindir)
    plugins[skeleton] = pluginloader.loadPlugins()

def cleanProjectDir(project):
	"""
		remove (-Rf) the loeftovers of the projectdir
	"""
	D("Removing directory structure %s" % project['project.dir'])
	CMD("rm -Rf %s" % project['project.dir'])


def doRemove(projectinformation):

	projectinformation
	#do pre removal stuff
	action("killing leftover processes")
	pu = projectinformation["project.user"].strip().lower()
	if (pu == None or pu == '' or pu == 'root'):
            raise "not killing processes of user \"%s\"" % pu
	CMD("su - %s -c 'kill -9 -1'" % (pu))
	actionok()
	
	action("Executing pre-removal operations on project %s" % projectinformation['project.name'])
	for skeleton in projectinformation['project.skeletons']:
		for plugin in plugins[skeleton]:
			plugin.doPreRemove(projectinformation)	
	actionok()

	#delete the project
	action("Removing project %s" % projectinformation['project.name'])
        cleanProjectDir(projectinformation)
	actionok()
	
	#do post removal stuff
	action("Executing post-removal operations on project %s" % projectinformation['project.name'])
	for skeleton in projectinformation['project.skeletons']:
		for plugin in plugins[skeleton]:
			plugin.doPostRemove(projectinformation)	
	actionok()
	
	action("Sending log to admin")
	smllib.postman.getThePostman().send("Project Removal: %s" % projectinformation['project.name'])
	actionok()
