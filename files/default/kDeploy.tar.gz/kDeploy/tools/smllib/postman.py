import smtplib
from smllib.projectinformation import getBaseInformation
from smllib.information import Information

class Postman:
	"""
		SMTP implementation to send mails to a configured reciepient
	"""	    
    
	def __init__(self, smtpserver,nomails):
		"""
			initialises the message's body, subject, from and to address
		"""
		self.smtpserver = smtpserver
		
		# Load the globalconfig, as we can find the To:-address in there
		globalConfig  = getBaseInformation()    
		self.toaddr   = globalConfig['config.adminmail']
		self.fromaddr = "kdeploy@kunstmaan.be"
		self.subject  = "Server Maintenance"
		self.nomails = nomails
		self.message = ''
		
		#the postman wiill only mail at a preconfigured errorleveltreshold
		#(0: always, 1: at warnings, 2: at errors)
		self.errorlevel = 0
		self.errorleveltreshold = int(globalConfig['config.mailverbosity'])

	def setErrorlevel(self, elevel):
	    """
	    	sets the errorlevel to elevel if the current value is lower than elevel
	    """
	    if (self.getErrorlevel() < elevel):
		self.errorlevel = elevel
	    	print("[postman] set the errorlevel to %s\n" % elevel)	
		
	def send(self, subject = ""):
		"""
			makes a connection to the server,
			sends the collected message if the errorlevel is high enough
			(meaning: if the messages are severe enough to tell the admin about)
			and closes the connection again
		"""
		
		if (self.nomails == "true"):
			print "not sending any mails .."
			return
		
		if subject == "":
		    subject = self.subject
		
		# Add the From: and To: headers to the message body
		header = ("From: %s\r\nTo: %s\r\nSubject:[%s] %s\r\n\r\n" % (self.fromaddr, self.toaddr, self.getErrorlevelType(self.getErrorlevel()), subject))
		
		if (self.getErrorlevel() >= self.errorleveltreshold):
			server = smtplib.SMTP(self.smtpserver)
			server.sendmail(self.fromaddr, self.toaddr, header + "\n *** errorlevel %s *** \n" % self.getErrorlevelType(self.getErrorlevel()) + self.message)
			server.quit()
			print("\tI sent a mail with errorlevel %s to %s" % (self.errorlevel, self.toaddr))
		else:
		    	print("\t[errorlevel %s] I did not send any mail as nothing important happened :-)" % self.errorlevel)
	
	def collect(self, message):
		"""
			add message to the mail body
		"""
		self.message += "\n"+message
		
	def getErrorlevel(self):
		"""
			returns the currect errorlevel of the collected message
		"""
	    	return self.errorlevel
		
	def getErrorlevelType(self, elevel):
		"""
			returns a string representation of the given errorlevel
		"""
		if elevel == 0:
		    return "info"
		elif elevel == 1:
		    return "warning"
		elif elevel == 2:
		    return "error"
		return "unknown"
		
#this is a singleton class
global thePostman
globalConfig  = getBaseInformation()    
thePostman = Postman(globalConfig['config.mailserver'],globalConfig['config.nomails'])

def getThePostman():
    return thePostman
