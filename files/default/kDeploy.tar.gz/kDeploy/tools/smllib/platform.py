import os
def getPlatform():
	fin = os.popen("uname")
	x = fin.readline()[:-1]
	fin.close
	try:
		import java.io.File
		y = "jython"
	except ImportError:
		y = "CPython"
	return (x,y)

