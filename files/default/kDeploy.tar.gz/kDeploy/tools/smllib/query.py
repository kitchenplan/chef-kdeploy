explanation = {
	"project.name"        : "name of the project",
	"project.dir"         : "folder where the project is stored",
	"project.user"        : "user associated with the project",
	"project.group"       : "group associated with the project",
	"tmp.skeleton"        : "the name of the skeleton you wish to apply",
	"project.ip"          : "ip address attached to the project",
	"project.statsurl"    : "url to reach the project statistics",
	"project.url"         : "url to reach the project website",
	"project.admin"       : "project admin's email address",
	"project.monuri"      : "uri relative to the project url to monitor",
	"project.monregexp"   : "regular expressions matching the text that should be on the monitored pages",
	"project.hostmachine" : "hostname of the machine this project is hosted on",
	"project.keeprotated" : "number of rotated apache logfiles to keep before removing"
}

defaults = {
	"project.user"        : "@project.name@",
	"project.group"       : "@project.name@",
	"project.dir"         : "@config.projectsdir@@project.name@",
	"project.statsurl"    : "stats.@project.url@",
	"project.admin"       : "support@kunstmaan.be",
	"project.monuri"      : "/",
	"project.hostmachine" : "front5.smartlounge.be",
	"project.keeprotated" : "5"
}

def query(name, searchreplacer, defaultValue=None):
	"""
		queries the user for a value for a key
	"""
	exp = "no explanation available"
	if (name in explanation.keys()):
		exp = searchreplacer.replace(explanation[name])
	default = ""
	defaultstr = ""
	if (defaultValue != None):
		default = defaultValue
		defaultstr = "[%s]" % default
	elif (name in defaults.keys()):
		default = searchreplacer.replace(defaults[name])
		defaultstr = "[%s]" % default
		
	print("/ no value for %s\n|\t%s" % (name, exp))
	
	res = raw_input("\\ --- (%s) %s --- > " % (name, defaultstr))
	if (res == '' and default != ''):
            return default
        return res