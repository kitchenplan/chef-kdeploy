from java.lang import *
from java.sql import *

def getMysqlConnection(host,user,password,database):
  driverName = "com.mysql.jdbc.Driver"
  Class.forName(driverName)
  url = "jdbc:mysql://%s/%s?user=%s&password=%s" % (host,database,user,password)
  con = DriverManager.getConnection(url)
  return con

def getPostgresqlConnection(host,user,password,database):
  driverName = "org.postgresql.Driver"
  Class.forName(driverName)
  url = "jdbc:postgresql://%s/%s?user=%s&password=%s" % (host,database,user,password)
  con = DriverManager.getConnection(url)
  return con
