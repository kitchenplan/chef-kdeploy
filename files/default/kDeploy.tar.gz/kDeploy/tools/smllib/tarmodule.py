from smllib.shell import *

def tarProject(project, destdir, excludes):
    	"""
    		tars the project's local data to a safe place, called destdir
 	"""
	#make sure our destination dir exists
	CMD("mkdir -p %s" % destdir)
	excludeparam = ""
	for exclude in excludes:
	    n = exclude
	    if (exclude.startswith("/")):
	        n = project['project.dir'] + exclude
	    if (exclude.endswith("/")):
	        n = n + '*'
	    excludeparam = excludeparam + "--exclude='" + n + "' " 
	D("Tarring project to %s%s, excluding %s" % (destdir, project['project.name'], excludes))
	D("--> nice -n 19 tar --create --absolute-names %s --file %s%s.tar.gz --totals --gzip %s/ 2>&1" % (excludeparam, destdir, project['project.name'], project['project.dir']))
	tarstats = CMDGET("nice -n 19 tar --create --absolute-names %s --file %s%s.tar.gz --totals --gzip %s/ 2>&1" % (excludeparam, destdir, project['project.name'], project['project.dir']))
	D(" --> Success [ %s ]" % tarstats.rstrip())
	D(" --> to restore the project do: # tar xzPf %s%s.tar.gz" % (destdir, project['project.name']))