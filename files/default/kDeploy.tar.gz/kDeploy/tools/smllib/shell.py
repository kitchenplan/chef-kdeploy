import os
import smllib.postman
import sys
import subprocess
import select
useJava = True
try:
  import java.io.File
except ImportError:
  useJava = False

# ANSI-fun
whitebold = "\033[37;1m"
greenbold = "\033[32;1m"
redbold = "\033[31;1m"
red = "\033[31;1m"
bluebold =  "\033[34;1m"
yellowbold =  "\033[33;1m"
normal = "\033[00;0m"
savecursor = "\033[s"
restorecursor = "\033[u"
moveup = "\033[1A"
cleartoend = "\033[K"

class CMDError:
	def __init__(self, cmd, message):
		self.cmd = cmd
		self.message = message
	def __str__(self):
		return self.cmd + " " + self.message

def JavaCMD(cmd):
    """ trimmed down java CMD"""
    ret = os.system("%s" % cmd)
    if (ret != 0):
        showerror(cmd + " failed with exit code %i\n" % (ret))
    smllib.postman.getThePostman().collect("I executed: " + cmd)	

def CMD(cmd):
	"""
		executes a given command on the system and raises a CMDError if execution failed		
	"""
	
	try:	
	    retcode = subprocess.call(cmd, shell=True)
	    if retcode < 0:
		print >>sys.stderr, "Child was terminated by signal", -retcode
	except OSError, e:
	    print >>sys.stderr, "Execution failed:", e

	smllib.postman.getThePostman().collect("I executed: " + cmd)	

if (useJava):
  CMD = JavaCMD

def CMDX(cmd):
	"""
		executes a given command on the system and returns the exit code
	"""
	try:
		smllib.postman.getThePostman().collect("I executed: " + cmd)
		return subprocess.call(cmd, shell=True)
	except OSError, e:
	    print >>sys.stderr, "Execution failed:", e
	
def CMDGET(cmd):
	"""
		executes a give command on the system and returns its output
	"""
	smllib.postman.getThePostman().collect("I executed: " + cmd)	
	return subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE).communicate()[0].strip()
	
def D(msg, indent=1):
    """
    	informs the user about what's happening (msg)
    	prints the information at a given indent (default 1)
    """
    print indent * "\t",
#    print "%s>%s %s %s<%s" % (yellowbold, normal, msg, yellowbold, normal)
    print "%s>%s %s" % (yellowbold, normal, msg)
    smllib.postman.getThePostman().collect(indent * "  " + msg)
 
def ask(question):
    """
    	asks a the user a question and returns the answer
    """
    smllib.postman.getThePostman().collect("I asked: " + question)
    print "---",
    return raw_input(question)
    
def warn(warning):
    """
	prints a warning to stdout
    """
    print "*%sWARNING%s* %s" % (whitebold, normal, warning)
    poster = smllib.postman.getThePostman()
    poster.collect("WARNING: " + warning)
    poster.setErrorlevel(1)
    
def showerror(errormsg):
    """
	informs the user of an error
    """
    import traceback
    stackframe = str(traceback.extract_stack()[-2][0:3])
    print " - %sE R R O R%s - %s" % (redbold, normal, errormsg)
    print "   %sstackframe:%s %s" % (red, normal, stackframe)
    poster = smllib.postman.getThePostman()
    poster.collect("ERROR: " + errormsg)
    poster.collect("STACK: " + stackframe)
    poster.setErrorlevel(2)
    
def action(message):
    """
	informs the user of the beginning of a group of commands
    """
    print " %s*%s %s\t%s" % (greenbold, normal, message, savecursor)
    smllib.postman.getThePostman().collect("START: " + message)
    
def actionok():
    """
	used to note the user a group of commands were succefully executed
    """
    print "%s[%s %sok%s %s]%s\n" % (bluebold, normal, greenbold, normal, bluebold, normal)
    #print "%s%s%s[%s %sOK%s %s]%s" % (restorecursor, cleartoend, bluebold, normal, greenbold, normal, bluebold, normal)
    smllib.postman.getThePostman().collect("END\n")
