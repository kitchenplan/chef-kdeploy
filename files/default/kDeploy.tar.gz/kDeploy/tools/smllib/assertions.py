class AssertionError:
    def __init__(self,msg):
	self.msg = msg
    def __str__(self):
	return "AssertionError: "+self.msg


def assertNotEmpty(x):
    if (x == None):
	raise AssertionError("null value found")
    if (type(x) == str):
	if (x == ""):
            raise AssertionError("empty string found")
	else:
            return True
    if (type(x) == list):
	if (len(x) == 0):
	    raise AssertionError("empty list found")
    raise AssertionError("unknown type: "+type(x))
    