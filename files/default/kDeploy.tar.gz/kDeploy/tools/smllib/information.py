from smllib.xmldictionary import *
from smllib.query import query
import smllib.assertions
import re

class Information:
	def __init__(self, name):
		self.name = name
		self.dict = {}

	def get(self, key):
		if (key in self.dict.keys()):
			return self.dict[key]
		return None

	def bindXML(self, file):
		"""
			loads the content of file (XML format) into self.dict
			keys existing in the old dict but not in the xmlfile stay untouched
			keys existing in the old dict and in the xmlfile stay untouched
			keys existing in the xmlfile but not in the old dict are added
		"""
		oldDict = self.dict
		self.dict = XMLDictionary(file)
		for key in oldDict.keys():
			self.dict[key] = oldDict[key]

	def mergeWith(self, dict):
		for key in dict.keys():
			self.dict[key] = dict[key]

	def getReplacer(self):
		return SearchReplacer(self)

	def queryArrayUser(self, key):
	    """
	    	queries user for an array of values
	    	which will be stored under the same key as a list
    	    """
	    self.dict[key] = []
	    #we keep on asking for more entries until user inserts an empty value
	    stop = False
	    exitcode = "just press enter to exit"
	    while (not stop):
		item = query(key, self.getReplacer(), exitcode)
		if (item == exitcode):
		    stop = True
		else:
		    self.dict[key].append(item)
	    return self.dict[key]


	def queryUser(self, key, default=None):
		"""
			queries user for a value 'key'
			proposes 'default' as default-value
			stores the value in self.dict
			and returns the user-entered value
		"""
		xdef = default
		if (xdef == None):
			if (key in self.dict.keys()):
				xdef = self.dict[key]

		self.dict[key] = query(key, self.getReplacer(), xdef)
		if (key == 'project.name'):
			self.name = self.dict[key]
		return self.dict[key]

	def __getitem__(self, key):
		return self.get(key)

	def __setitem__(self, key, value):
		self.set(key,value)

	def keys(self):
		return self.dict.keys()

	def getDict(self):
		return self.dict

	def set(self,key, value):
		self.dict[key] = value

	def require(self, key):
	    smllib.assertions.assertNotEmpty(key)

	def save(self):
		self.dict.save()

class SearchReplacer:
	def __init__(self, info):
		self.info = info
		self.dict = info.getDict()

	# searches a given string for occurances of @foo.bar@
	# and string.replaces them with with a dict[key] value
	# for all keys in self.dict
	# if it can't find a value, it queries the user for one
        #
	# returns the new string
	def replace(self, strv):
		x = strv
#		for key in re.findall("@(.*?)@", x):
                for key in re.findall("@(\w*?\.\w*?)@", x):
		    if (self.dict.__contains__(key)):
			x = x.replace("@%s@" % key , self.dict[key])
		    else:
			print ("*WARNING* no value for %s found in config file" % key)
			x = x.replace("@%s@" % key , self.info.queryUser(key))
			self.info.save()
		return x
