import re
import sys
import os
import smllib.shell

class Loader:
	"""
		Class to load and actually import plugin files
	"""
	def __init__(self,plugindir):
		"""
			constructor. plugindir is the directory to look for strings in
			Loader will not look into subdirectories of plugindir
		"""
		self.plugindir = plugindir

	def listPlugins(self):
		"""
			generates a list of plugins found in plugindir. actually
			these are only the files found in the dir with the .py extension
		"""
		return [ x for x in os.listdir(self.plugindir) if x.endswith(".py")]

	def loadPlugin(self,filename):
		"""
			actually imports the plugins and returns the module
		"""
		rx = re.compile(r"\.py$")
		moduleName = rx.sub("",filename)
		smllib.shell.action("Loading plugin file " + moduleName + ".py")
		oldPath = sys.path[:]
		sys.path = [os.path.realpath(os.path.curdir), self.plugindir]
		sys.path = sys.path + oldPath
		mod =  __import__(moduleName)
		sys.path = oldPath
		smllib.shell.actionok()
		return mod

	def loadPluginModules(self):
		"""
			loads all the plugins found in plugindir and returns them in an array
		"""
		return [self.loadPlugin(x) for x in self.listPlugins()]

	def loadPlugins(self):
		"""
			invokes the getPlugin() method on all loaded plugins
			and returns their return value (i.e. the plugin objects)
			in an array
		"""
		
		return [x.getPlugin() for x in self.loadPluginModules()]