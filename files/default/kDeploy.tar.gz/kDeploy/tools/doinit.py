#this script runs through all project's init.d scripts

import smllib.projectinformation
import smllib.shell
import smllib.postman
import os
import sys

if len(sys.argv) == 0:
    smllib.shell.showerror("Don't know what to do. Please provide 'start', 'stop' or 'restart' as argument")
    sys.exit(0)
else:
    action = sys.argv[1]
    
#load global configuration
globalConfig = smllib.projectinformation.getBaseInformation()

#get a list of projects on the machine
projects = os.listdir(globalConfig['config.projectsdir'])

for project in projects:
	smllib.shell.D("PROJECT: %s" % project)
	if not 'init.d' in os.listdir("%s/%s" % (globalConfig['config.projectsdir'], project)):
	    continue
	initscripts = os.listdir("%s/%s/init.d/" % (globalConfig['config.projectsdir'], project))
    	for script in initscripts:
	    smllib.shell.D("Executing %s %s" % (script, action), 2)
	    output = smllib.shell.CMDGET("%s/%s/init.d/%s %s 2>&1" % (globalConfig['config.projectsdir'], project, script, action))    
	    smllib.shell.D("%s output: %s" % (script, output), 3)

smllib.shell.action("Sending log to admin")
smllib.postman.getThePostman().send("Ran Project Initers")
smllib.shell.actionok()