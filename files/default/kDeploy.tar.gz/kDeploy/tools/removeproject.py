# once invoked ensures a clean deinstall of a project
# this means the projectdir is tarred and stored
# and the config files on other places are removed

import sys

from smllib.query import query
from smllib.shell import *
from smllib.information import Information
from smllib.tarmodule import tarProject
import smllib.postman
import smllib.projectinformation
import smllib.backup
import smllib.remove
import smllib.aspn
import os

smllib.aspn.lock()

def getSkeletons():
    	"""
    		returns a list af available skeletons
    	"""
	#goes and looks for them wherever is configured in globalConfig
	skeletons = os.listdir(smllib.projectinformation.getBaseInformation()['config.skeletonsdir'])
	#if 'CVS' in skeletons:
	#    skeletons.remove("CVS")
	return skeletons


#load global configuration
globalConfig = smllib.projectinformation.getBaseInformation()
p = Information(None)

projectName = None

if len(sys.argv) > 1:
    projectName = sys.argv[1]
    p.queryUser('tmp.areyousure')
    if (p['tmp.areyousure'] == 'n' or p['tmp.areyousure'] == 'no'):
        smllib.shell.D("Did not remove %s" % projectName)
        sys.exit()
    while (p['tmp.areyousure'] not in ['yes','YES','y','Y','no','NO','n','N'] ):
            p.queryUser('tmp.areyousure')
            if (p['tmp.areyousure'] == 'n' or p['tmp.areyousure'] == 'no'):
                smllib.shell.D("Did not remove %s" % projectName)
                sys.exit()

quickMode = False
if len(sys.argv) > 2 :
    quickMode = True



#asks for a project to remove. keeps on going until a valid project is inputted
#no input quits (cancels)

if (projectName == None):
    D("Which project do you want to remove? (no entry cancels)", 0)
    p.queryUser("project.name")
    projects = smllib.projectinformation.getProjects()
    while not projects.__contains__(p['project.name']):
        if p['project.name'] == "":
            sys.exit()
        warn("Could not find project %s" % p['project.name'])
        p.queryUser("project.name")
else:
    p['project.name'] = projectName
    projects = smllib.projectinformation.getProjects()
    if not projects.__contains__(p['project.name']):
        warn("could not find project %s"% p['project.name'])    
	sys.exit()
	    
	    
#load the project's configuration
p.bindXML("%s/%s/conf/config.xml" % (globalConfig['config.projectsdir'], p["project.name"]))
p.mergeWith(globalConfig)
#remove the project
action("Removing project %s" % p['project.name'])
smllib.backup.doBackup(p, quickMode)
if (smllib.postman.getThePostman().getErrorlevel() > 0):
    smllib.shell.D("not removing project, please correct errors first")
    sys.exit(0)
smllib.remove.doRemove(p)
actionok()

D("Make sure to run maintenance.py again to complete the removal of the project", 0)
smllib.aspn.unlock()

os.system("python maintenance.py quick")