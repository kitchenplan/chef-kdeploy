#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/wait.h>   



int main(int argc, char *argv[]) {
	if( argc == 2 ){
//		printf("Logrotating project: %s\n", argv[1]);
		char *projectdir=(char *)malloc(256);
		char *buffer1=(char *)malloc(2048);
		char *buffer2=(char *)malloc(2048);
		struct stat whatisit;
		int mystatus;
		sprintf(projectdir,"/home/projects/%s" , argv[1]);
		if (stat(projectdir,&whatisit) == 0) {
			if (whatisit.st_mode & S_IFDIR) {
			} else {
				printf("not a directory \n");
				exit(1);
			}
			
		} else {
			printf("does not exist\n");
			exit(1);
		}
		int result = fork();
		if (result == 0) {
			sprintf(buffer1,"/home/projects/%s/cron/logrotate_state",argv[1]);
			sprintf(buffer2,"/home/projects/%s/conf/logrotate.conf",argv[1]);
			execl("/usr/sbin/logrotate","/usr/sbin/logrotate","--state",buffer1,buffer2,NULL);
			return 0;
		} else {
			wait(&mystatus);
		}
  		return 0;
	} else if( argc > 2 ) {
		printf("Too many arguments supplied.\n");
		return 1;
	} else {
		printf("One argument expected.\n");
		return 1;
	}
}

