#!/usr/bin/env python

import smtplib
import smllib.projectinformation
import smllib.shell
from smllib.information import Information

globalConfig = smllib.projectinformation.getBaseInformation()
p = Information(None)
p.mergeWith(globalConfig)

smllib.shell.D("For which project do you want to generate passwords?", 0)
p.queryUser("project.name")
while not p['project.name'] in smllib.projectinformation.getProjects():
    smllib.shell.warn("A project with name %s doesnt exists!" % p['project.name'])
    p.queryUser("project.name")

p.bindXML("%s/%s/conf/config.xml" % (globalConfig['config.projectsdir'], p['project.name']))
skeletons = p['project.skeletons']

#here comes the ugly part
#we hardcode which skeleton is responsible for which passwords
if "base" in skeletons:
     #UNIX password for project.user
     smllib.shell.action("Setting up UNIX password")
     userpass = smllib.shell.CMDGET('pwgen --num-passwords=1').rstrip()
     smllib.shell.D("Setting ssh/ftp password for user %s to %s (no expiration date)" % (p['project.user'], userpass))
     smllib.shell.CMDGET("expect %s/passwdnonint %s %s 2>&1" % (globalConfig['config.scriptsdir'], p['project.user'], userpass))
     
     smllib.shell.D("Mailing password to %s" % p['project.admin'])
     header = ("From: kdeploy@kunstmaan.be\r\nTo: %s\r\nSubject:[passwd] SSH/FTP password for %s\r\n\r\n" % (",".join((p['project.admin'], globalConfig['config.adminmail'])), p['project.name']))
     message = """Dear admin of project %s,
     
Please note we created a new FTP/SSH password for user %s on our systems. Your new password is 

	%s

Regards,
kunstmaan.be
""" % (p['project.name'], p['project.user'], userpass)
     server = smtplib.SMTP(globalConfig['config.mailserver'])
     server.sendmail("support@om01.kunstmaan.be", (p['project.admin'], globalConfig['config.adminmail']), header + message)
     server.quit()
     smllib.shell.actionok()
     
if "awstats" in skeletons:
    #htpasswd password for project.user
    smllib.shell.action("Setting up .htpasswd password")
    statspass = smllib.shell.CMDGET('pwgen --num-passwords=1').rstrip()
    smllib.shell.D("Setting awstats password for user %s to %s" % (p['project.user'], statspass))
    smllib.shell.CMDGET("htpasswd2 -b -c %s/stats/.htpasswd %s %s 2>&1" % (p['project.dir'], p['project.user'], statspass))
    smllib.shell.D("Mailing password to %s" % p['project.admin'])
    header = ("From: kdeploy@kunstmaan.be\r\nTo: %s\r\nSubject:[passwd] awstats password for %s\r\n\r\n" % (",".join((p['project.admin'], globalConfig['config.adminmail'])), p['project.name']))
    message = """Dear admin of project %s,
     
Please note we created a new awstats (http://%s/stats) password for user %s on our systems. Your new password is 

	%s

Regards,
kunstmaan.be
""" % (p['project.name'], p['project.url'], p['project.user'], statspass)
    server = smtplib.SMTP(globalConfig['config.mailserver'])
    server.sendmail("support@om01.kunstmaan.be", (p['project.admin'], globalConfig['config.adminmail']), header + message)
    server.quit()
    smllib.shell.actionok()
    
if "tomcat" in skeletons:
    #tomcat password for tomcat manager
    smllib.shell.action("Setting up tomcat password")
    tomcatpass = smllib.shell.CMDGET('pwgen --num-passwords=1').rstrip()
    smllib.shell.D("Setting tomcat password for tomcat manager to %s" % tomcatpass)
    
    import xml.dom.minidom
    
    tomcatusersxml = smllib.shell.CMDGET("find %s/tomcat/default/ -name '*tomcat-users.xml'" % p['project.dir']).rstrip()
    conffile = xml.dom.minidom.parse(tomcatusersxml)
    users = conffile.getElementsByTagName("user")
    for user in users:
	if user.getAttribute("username") == 'manager':
	    user.setAttribute("password", tomcatpass)
	    break
    
    savefile = open(tomcatusersxml, 'w')
    savefile.write(smllib.improvexml.makeXMLReadable(conffile))
    savefile.close()
    smllib.shell.actionok()
