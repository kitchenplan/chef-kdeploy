#!/usr/bin/env python

import sys

import smllib.projectinformation
from smllib.information import Information
from smllib.plugins import Loader
import smllib.shell
import os
import smllib.postman

globalConfig = smllib.projectinformation.getBaseInformation()

if (len(sys.argv) < 2):
    print "project name ?";
    sys.exit(1)

projectname = sys.argv[1]

projectInformation = Information(None)
projectInformation.mergeWith(globalConfig)
projectInformation.bindXML("%s/%s/conf/config.xml" % (globalConfig['config.projectsdir'], projectname))
if (projectInformation["project.name"] == None):
    smllib.shell.showerror("project not found")
    sys.exit(1)

if (len(sys.argv) == 3 ):
    projectInformation["tmp.dir"] = sys.argv[2]

baseskel = globalConfig['config.skeletonsdir'] + "/base/plugins/maintenance"
pluginloader = Loader(baseskel)
plugins = pluginloader.loadPlugins()



for p in plugins:
    if (p.getPluginName() == "permissions fixer"):
        p.checkPreconditions(projectInformation)
        p.doOnProject(projectInformation)

smllib.shell.action("sending logs to admin")
smllib.postman.getThePostman().send("Fix permissions")
smllib.shell.actionok()
