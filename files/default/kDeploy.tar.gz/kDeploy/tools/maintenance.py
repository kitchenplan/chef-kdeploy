#!/usr/bin/env python

import sys

import smllib.projectinformation
from smllib.information import Information
from smllib.plugins import Loader
import smllib.shell
import os
import smllib.postman
import smllib.aspn

smllib.aspn.lock()


quickMode = False
if ("quick" in sys.argv):
    quickMode = True

globalConfig = smllib.projectinformation.getBaseInformation()
projectdirs = smllib.projectinformation.getProjectDirs()
projects = []

def _skeletonfilter(skel):
    try:
        open("%s/%s/config.xml" % (globalConfig['config.skeletonsdir'], skel))
    except IOError as e:
        return False
    return True    

#comparisonfunction to define which of two skeletons is to be applied first
#if they are direct circular dependent, we only detect the dependency of ske1 on skel2
#if skel1 depends on skel2 we return -1
#if skel2 depends on skel1 we return +1
#if there is no dependency, we return 0 --> this can't handle trasitive dependencies!
def _skeletonorder(skel1, skel2):
    skel2conf = Information('skeletonconfig')
    skel2conf.bindXML("%s/%s/config.xml" % (globalConfig['config.skeletonsdir'], skel2))
    skel2confdeps = skel2conf['skeleton.deps']
    if skel1 in skel2confdeps:
        return -1

    skel1conf = Information('skeletonconfig')
    skel1conf.bindXML("%s/%s/config.xml" % (globalConfig['config.skeletonsdir'], skel1))
    skel1confdeps = skel1conf['skeleton.deps']
    if skel2 in skel1confdeps:
        return 1

    return 0

# generate instances for every plugin in the system
# each plugin is now referencable from the plugin hash
# with its corresponding skeleton as key
skeletons = os.listdir(globalConfig['config.skeletonsdir'])
#skeletons.remove("CVS")
plugins = {}
for skeleton in skeletons:
    skeletondir = globalConfig["config.skeletonsdir"] + "/" + skeleton
    plugindir = skeletondir + "/plugins/maintenance"
    pluginloader = Loader(plugindir)
    plugins[skeleton] = pluginloader.loadPlugins()

# invokes checkPreconditions on every plugin and passes
# the information stored in projectdir/conf/config.xml with it
smllib.shell.action("STEP 1: checking preconditions")
for projectdir in projectdirs:
    smllib.shell.D("PROJECTDIR %s" % projectdir)
    projectInformation = Information(None)
    projectInformation.mergeWith(globalConfig)
    projectInformation.bindXML(projectdir + "/conf/config.xml")
    projects.append(projectInformation)
    smllib.shell.D("PROJECT %s" % projectInformation["project.name"])
    skeletons = projectInformation["project.skeletons"]
    skeletons = filter(_skeletonfilter, skeletons)
    skeletons.sort(_skeletonorder)
    for skeleton in skeletons:
	for plugin in plugins[skeleton]:
		smllib.shell.D("PLUGIN %s (%s)" % (plugin.getPluginName(), plugin.getAbout()),2)
		plugin.checkPreconditions(projectInformation)
    projectInformation.save()
smllib.shell.actionok()

smllib.shell.action("STEP 2: running plugins pre step")
skeletons = plugins.keys()
skeletons.sort(_skeletonorder)
for skeleton in skeletons:
    for plugin in plugins[skeleton]:
	smllib.shell.D("PLUGIN %s" % plugin.getPluginName(), 1)
	if (not (quickMode and plugin.canSkip())): plugin.doPreProjects()
smllib.shell.actionok()

#iterates over the projects in random order and invokes all their plugin's main routine
#in random order, but respecting their skeleton's dependencies
smllib.shell.action("STEP 3: running plugins main step")
for project in projects:
    smllib.shell.D("PROJECT %s" % project["project.name"])
    skeletons = project["project.skeletons"]
    skeletons = filter(_skeletonfilter, skeletons)
    skeletons.sort(_skeletonorder)
    for skeleton in skeletons:
	for plugin in plugins[skeleton]:
		smllib.shell.D("PLUGIN %s" % plugin.getPluginName(), 2)
		if (not (quickMode and plugin.canSkip())): plugin.doOnProject(project)
smllib.shell.actionok()

smllib.shell.action("STEP 4: running plugins post step")
skeletons = plugins.keys()
skeletons.sort(_skeletonorder)
for skeleton in skeletons:
    for plugin in plugins[skeleton]:
	smllib.shell.D("PLUGIN %s" % plugin.getPluginName(), 1)
	if (not (quickMode and plugin.canSkip())): plugin.doPostProjects()
smllib.shell.actionok()

smllib.shell.action("STEP 5: sending log to admin")
smllib.postman.getThePostman().send("Overall Project Maintenance")
smllib.shell.actionok()
smllib.aspn.unlock()
