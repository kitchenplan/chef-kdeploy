#!/usr/bin/python
import smllib.projectinformation
from smllib.information import Information
import os,sys

projectdirs = smllib.projectinformation.getProjectDirs()
globalConfig = smllib.projectinformation.getBaseInformation()



class Stats:
    def __init__(self,filename):
        self.filename = filename
        self._process()
        self._parseFileName()

    def _process(self):
        total_bytes = 0
        total_pages = 0
        total_hits = 0
        total_visits = 0
        f = open(self.filename,'r')
        line = f.readline()
        while len(line) > 0:
            if (line.startswith("BEGIN_DAY")):
                break
            line = f.readline()
        line = f.readline()
        while len(line) > 0:
            if (line.startswith("END_DAY")):
                break
            tokens = line.split(" ")
            total_pages = total_pages + int(tokens[1])
            total_hits = total_hits + int(tokens[2])
            total_bytes = total_bytes + int(tokens[3])
            total_visits = total_visits + int(tokens[4])
            line = f.readline()
        f.close()
        
        self.pages = total_pages
        self.hits = total_hits
        self.bytes = total_bytes
        self.visits = total_visits
        
    def _parseFileName(self):
        import re
        rx = re.compile(r"(.*)awstats")
        x = rx.split(self.filename)[2]
        x = x.replace(".txt","")
        self.month = int(x[0:2])
        self.year = int(x[2:])
        
    def __repr__(self):
        return "<STATS: %i/%i pages=%i hits=%i bytes=%i visits=%i >" % (
                self.month,
                self.year,
                self.pages,
                self.hits,
                self.bytes,
                self.visits,
            )

    def __cmp__(self,other):
        if (self.year < other.year):
            return -1
        if (self.year > other.year):
            return 1
        if (self.month < other.month):
            return -1
        if (self.month > other.month):
            return 1
        return 0
    
    



for projectdir in projectdirs:
    projectInformation = Information(None)
    projectInformation.mergeWith(globalConfig)
    projectInformation.bindXML(projectdir + "/conf/config.xml")
    print(projectInformation["project.name"])
    if "awstats" in projectInformation["project.skeletons"]:
        print("    stats")
        statsdir = projectdir + "/stats/data/"
        statsfiles = os.listdir(statsdir)
        statslist = []
        for statsfile in statsfiles:
            if (statsfile.endswith(".txt")):
                s = Stats(statsdir + "/" + statsfile)
                statslist.append(s)
        statslist.sort()
        for s in statslist:
            ds = "%i/%i" % (s.month,s.year)
            unit = "bytes"
            val = (1.0 * s.bytes)
            if ((val / 1024.0) > 1):
                val = val / 1024.0
                unit = "Kb"
            if ((val / 1024.0) > 1):
                val = val / 1024.0
                unit = "Mb"
            if ((val / 1024.0) > 1):
                val = val / 1024.0
                unit = "Gb"
            
            print "        %s: %f %s" % (ds,val,unit)
            
                
    else:
         print("    no stats")

    print("    disk usage")
    f = os.popen("du -chs %s | grep total | awk '{print $1}'" % projectdir)
    result = f.read()
    f.close()
    print("        %s" % result)

    print ""

    
