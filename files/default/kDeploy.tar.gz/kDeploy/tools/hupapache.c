#include <stdlib.h>

int main() {
  system("killall -HUP apache2");
  return 0;
}
