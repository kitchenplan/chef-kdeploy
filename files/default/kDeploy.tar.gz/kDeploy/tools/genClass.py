from smllib.information import Information
from smllib.shell import *

typeinfo = {
    "default":
        {
          "extrainfo": [],
          "extraconstructor": "",
          "valuetype": "String",
          "getter": "getStringValue",
          "setter": "setStringValue",
          "extramethods": "",
        },


    "BooleanField":
        {
          "extrainfo": [],
          "extraconstructor": "",
          "valuetype": "boolean",
          "getter": "getBooleanValue",
          "setter": "setValue",
          "extramethods": "",
        },
    "IntField":
        {
          "extrainfo": [],
          "extraconstructor": "",
          "valuetype": "Integer",
          "getter": "getIntValue",
          "setter": "setValue",
          "extramethods": "",
        },
        
    "FloatField":
        {
          "extrainfo": [],
          "extraconstructor": "",
          "valuetype": "float",
          "getter": "getFloatValue",
          "setter": "setValue",
          "extramethods": "",
        },
        

    "DoubleField":
        {
          "extrainfo": [],
          "extraconstructor": "",
          "valuetype": "double",
          "getter": "getDoubleValue",
          "setter": "setValue",
          "extramethods": "",
        },
        

    "DateTimeField":
        {
          "extrainfo": [],
          "extraconstructor": "",
          "valuetype": "Date",
          "getter": "getDateValue",
          "setter": "setObjectValue",
          "extramethods": "\tpublic void set@v.fieldname@Now() {\n\t\t((@v.classname@)getFieldAt(@v.fieldconstant@)).setNow();\n\t}\n",
        },
    "MultiLineTextField":
        {
          "extrainfo": ["v.editrows"],
          "extraconstructor": "\t\t@t.fieldvar@.setEditRows(@v.editrows@);\n",
          "valuetype": "String",
          "getter": "getStringValue",
          "setter": "setStringValue",
          "extramethods": "",
        },
    "ReferenceField": 
        {
          "extrainfo": ["v.refclass"], 
          "extraconstructor": "\t\t@t.fieldvar@.setRefClass(@v.refclass@.class);\n",
          "valuetype": "@v.refclass@",
          "getter": "getObject",
          "setter": "setObject",
          "extramethods": "",
        },
    "InverseOneToManyField": 
        {
          "extrainfo": ["v.refclass","v.reffield"], 
          "extraconstructor": "\t\t@t.fieldvar@.setRefClass(@v.refclass@.class);\n\t\t@t.fieldvar@.setRefField(@v.refclass@.@v.reffield@);\n",
          "valuetype": "Vector",
          "getter": "getEntities",
          "setter": "",
          "extramethods": "",
        }
}

typeinfo["RichTextField"] = typeinfo["MultiLineTextField"]


class Field:
  def __init__(self):
      self.info = Information(None)

  def getClassName(self):
      return self.info["v.classname"]
      
  def getTypeInfo(self):
      if (self.info["v.classname"] in typeinfo):
        return typeinfo[self.info["v.classname"]]
      return typeinfo["default"]
  
  def setClass(self, clazz):
      self.info["v.parentclassname"] = clazz.info["classname"]
      
  def makeFirstUpper(self,value):
      return value[0].upper() + value[1:].lower()

  def query(self):
      self.info.queryUser("v.fieldname")
      self.info["v.fieldconstant"] = "FIELD_%s" % self.info["v.fieldname"].upper()
      self.info.queryUser("v.classname")
      self.info.queryUser("v.langdependent", "false")
      self.info.queryUser("v.createlookup", "n")
      for x in self.getTypeInfo()["extrainfo"]:
        self.info.queryUser(x)

      
  def outConstructor(self,num):
      self.info["t.fieldvar"] = "field%i" % (num)
      result = ""
      result +="\t\t{\n"
      result +="\t\t%s field%i = new %s(this, %s);\n" % (self.info["v.classname"], num, self.info["v.classname"], self.info["v.fieldconstant"]);
      result += self.info.getReplacer().replace(self.getTypeInfo()["extraconstructor"])
      result += "\t\taddField(field%i, %s);\n" % (num, self.info["v.langdependent"])
      result += "\t\t}\n"
      return result
      
  def outConstant(self):
      result = "\tpublic static final String %s = \"%s\";\n" % (self.info["v.fieldconstant"], self.info["v.fieldname"])
      return result
      
  def outExtraMethods(self):
      return self.info.getReplacer().replace(self.getTypeInfo()["extramethods"])
      
  def outGetterSetter(self):
      i = self.info
      valuetype = i.getReplacer().replace(self.getTypeInfo()["valuetype"])
      getter = i.getReplacer().replace(self.getTypeInfo()["getter"])
      setter = i.getReplacer().replace(self.getTypeInfo()["setter"])
      result = ""
      result += "\tpublic %s get%s() {\n" % (valuetype,self.makeFirstUpper(i["v.fieldname"]))
      result += "\t\treturn (%s)(getFieldAt(%s,%s.class).%s());\n" % (valuetype,  i["v.fieldconstant"],i["v.classname"], getter)
      result += "\t}\n\n";
      if (setter != ""):
        result += "\tpublic void set%s(%s value) {\n" % (self.makeFirstUpper(i["v.fieldname"]), valuetype)
        result += "\t\tgetFieldAt(%s,%s.class).%s(value);\n" % (i["v.fieldconstant"], i["v.classname"], setter)
        result += "\t}\n\n";
      
      if (i["v.createlookup"] != "n"):
        result += "\t public static %s by%s(%s val, Transaction t, Locale l) {\n" % (i["v.parentclassname"], self.makeFirstUpper(i["v.fieldname"]), valuetype)
        result += "\t\t%s example = new %s();\n" % (i["v.parentclassname"],i["v.parentclassname"])
        result += "\t\texample.setCurrentLocale(l);\n"
        result += "\t\texample.set%s(val);\n" % (self.makeFirstUpper(i["v.fieldname"]))
        result += "\t\treturn t.loadEntity(example);\n"
        result += "\t}\n\n";
        result += "\t public static List<%s> multiBy%s(%s val, Transaction t, Locale l) {\n" % (valuetype, self.makeFirstUpper(i["v.fieldname"]), valuetype)
        result += "\t\t%s example = new %s();\n" % (i["v.parentclassname"], i["v.parentclassname"])
        result += "\t\texample.setCurrentLocale(l);\n"
        result += "\t\texample.set%s(val);\n" % (self.makeFirstUpper(i["v.fieldname"]))
        result += "\t\treturn t.loadEntities(example);\n"
        result += "\t}\n\n";
      
      return result
      

class JavaClass:
  def __init__(self):
      self.info = Information(None)
      self.fielden = []
  

  def newField(self):
      field = Field()
      field.setClass(self)
      field.query()
      self.addField(field)
      
  def addField(self,field):
      self.fielden.append(field)
      
  def queryFields(self):
      self.info.queryUser("addField","y")
      while (self.info["addField"] == "y"):
        self.newField()
        self.info.queryUser("addField")
      
  def query(self):
      self.info.queryUser("classname")
      self.info["tablename"] = self.info["classname"].lower()
      self.info["displayname"] = self.info["tablename"]
      
  def out(self):
      result = "public class %s extends Entity {\n" % self.info["classname"]
      for field in self.fielden:
        result += field.outConstant()
      result += "\tpublic %s() {\n" % self.info["classname"]
      result += "\t\tsuper();\n"
      result += "\t\tsetTableName(\"%s\");\n" % self.info["tablename"]
      result += "\t\tsetDisplayName(\"%s\");\n\n" % self.info["displayname"]
      i=0
      for field in self.fielden:
        result += field.outConstructor(i)
        result += "\n"
        i = i + 1
      result += "\t}\n"
      
      for field in self.fielden:
         result += field.outGetterSetter()
         result += field.outExtraMethods()
         result += "\n"
      
      result += "}\n"
      
      return result


jc = JavaClass()
jc.query()
jc.queryFields()

print(jc.out())
