from smllib.creationplugin import CreationPlugin
import smllib.shell
from smllib.information import Information
import os
import tarfile
from smllib.xmldictionary import XMLDictionary


class SymfonyCreationPlugin (CreationPlugin):
	def __init__(self):
            #load the skeletonconfiguration
	    self.skelinfo = Information(None)
	    self.skelinfo.bindXML(smllib.projectinformation.getBaseInformation()['config.skeletonsdir'] + "/symfony/config.xml")
		
	def getAbout(self):
		"""
			returns a string containing the reason for this plugins existance
		"""
		return "deploys a symfony installation"

	def getPluginName(self):
		"""
			returns the name of this plugin (string)
		"""
		return "symfony init"
		
	def performAction(self, information):
		"""
			does what this plugin is made for, once per project	
		"""
		smllib.shell.D("Downloading symfony from http://symfony.com/download?v=Symfony_Standard_%s.tgz" % self.skelinfo['symfony.version'], 2)
		smllib.shell.CMD("wget -P /tmp http://symfony.com/download?v=Symfony_Standard_%s.tgz -O /tmp/Symfony_Standard_%s.tgz" % (self.skelinfo['symfony.version'],self.skelinfo['symfony.version']))
		smllib.shell.D("Untarring symfony version %s in %s/data/%s/Symfony (this may take a while)" % (self.skelinfo['symfony.version'], information['project.dir'],information['project.name']), 2)
		if not os.access("/tmp/Symfony_Standard_%s.tgz" % (self.skelinfo['symfony.version']), os.F_OK):
			smllib.shell.showerror("no symfony version %s archive found" % self.skelinfo['symfony.version'])
		
		symfonytar = tarfile.open("/tmp/Symfony_Standard_%s.tgz" % (self.skelinfo['symfony.version']), 'r:gz')
		for file in symfonytar.getmembers():
			symfonytar.extract(file, path=information['project.dir'] + "/data/" + information['project.name'] + "/")

		smllib.shell.CMD("mv %s/data/%s/Symfony/* %s/data/%s" % (information['project.dir'], information['project.name'],information['project.dir'] ,information['project.name']))
		smllib.shell.CMD("rm -Rf %s/data/%s/Symfony" % (information['project.dir'] ,information['project.name']))
		#smllib.shell.CMD("php %s/data/%s/bin/vendors install" % (information['project.dir'] ,information['project.name']))
		
		permdict = XMLDictionary("%s/conf/permissions.xml" % information["project.dir"])
		permdict.toSave=[""]
		permdict["/php5-fpm"] = ["-R -m user::rwx", "-R -m group::r-x", "-R -m other::r-x"]
		permdict["/tmp"] = ["-R -m user::rwx", "-R -m group::r-x", "-R -m other::r-x"]
		permdict["/data"] = ["-R -m user::rwx", "-R -m group::r-x", "-R -m other::---", "-R -m u:@config.wwwuser@:r-x"]
		permdict["/data/%s/app/cache"%information["project.name"]] = ["-R -m user::rwx", "-R -m group::r-x", "-R -m other::---", "-R -m u:@config.wwwuser@:rwx"]
		permdict["/data/%s/app/logs"%information["project.name"]] = ["-R -m user::rwx", "-R -m group::r-x", "-R -m other::---", "-R -m u:@config.wwwuser@:rwx"]
		permdict["/data/%s/web/media"%information["project.name"]] = ["-R -m user::rwx", "-R -m group::r-x", "-R -m other::---", "-R -m u:@config.wwwuser@:rwx"]
		permdict["/data/current/app/cache"] = ["-R -m user::rwx", "-R -m group::r-x", "-R -m other::---", "-R -m u:@config.wwwuser@:rwx"]
		permdict["/data/current/app/logs"] = ["-R -m user::rwx", "-R -m group::r-x", "-R -m other::---", "-R -m u:@config.wwwuser@:rwx"]
		permdict["/data/current/web/media"] = ["-R -m user::rwx", "-R -m group::r-x", "-R -m other::---", "-R -m u:@config.wwwuser@:rwx"]		
		permdict["/data/current"] = ["-m user::rwx", "-R -m group::rwx", "-R -m other::rwX", "-R -m u:@config.wwwuser@:rwx"]		
		permdict["/data/%s/paramEncode"%information["project.name"]] = ["-R -m user::rwx", "-R -m group::r-x", "-R -m other::---", "-R -m u:@config.wwwuser@:rwx"]
		permdict["/data/%s/paramDecode"%information["project.name"]] = ["-R -m user::rwx", "-R -m group::r-x", "-R -m other::---", "-R -m u:@config.wwwuser@:rwx"]	
		permdict.save()		
		
def getPlugin():
    return SymfonyCreationPlugin()

