from smllib.maintenanceplugin import MaintenancePlugin
import smllib.shell
import os
import re
from datetime import datetime, timedelta
import smllib.skeleton
import smllib.platform

class SymfonyMaintenancePlugin (MaintenancePlugin):
	def __init__(self):
		globalConfig = smllib.projectinformation.getBaseInformation()
	
	### begin * MaintenancePlugin implementation ###
	def getAbout(self):
		"""
			returns a string containing the reason for this plugins existance
		"""
		return "setup symfony 2 configs"
	
	def getPluginName(self):
		"""
			returns the name of this plugin (string)
		"""
		return "symfony maintainer"
	
	def checkPreconditions(self, information):
		"""
			runs before the plugin is really executed
			the plugin will only have effect if the project passes this test
			
			checks for a valid IP, url and statsurl in the config file
			asks for one if none is found
		"""
	
	def doPreProjects(self):
		"""
			does dome pre processing before the doOnProject
			happens only once (not once per project!)
			
			removes all previously generated apache config files
		"""
	
	def doOnProject(self, information):
		"""
			generates a partial apache.conf file for this project to be
			included in the general apache config fo the server
		"""
	
	def doPostProjects(self):
		"""
			does dome post processing after the doOnProject
			happens only once (not once per project!)
		"""


def getPlugin():
	return SymfonyMaintenancePlugin()
