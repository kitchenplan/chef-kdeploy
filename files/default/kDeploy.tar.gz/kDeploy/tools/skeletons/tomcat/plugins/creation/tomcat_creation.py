from smllib.creationplugin import CreationPlugin
import smllib.shell
from smllib.information import Information
import smllib.projectinformation
import os
import xml.dom.minidom
import smllib.improvexml
import tarfile

class TomcatCreationPlugin (CreationPlugin):

	def __init__(self):
		#load the skeletonconfiguration
		self.skelinfo = Information(None)
		self.skelinfo.bindXML(smllib.projectinformation.getBaseInformation()['config.skeletonsdir'] + "/tomcat/config.xml")
		globalConfig = smllib.projectinformation.getBaseInformation()	
		self.ips = []
		# clearing the iplist
		[self.ips.remove(x) for x in self.ips] 
		# we collect the machine's IP addresses at init
		if (globalConfig['config.options'] and ("localhost-only" in globalConfig['config.options'])):
			ipaddr = "127.0.0.1\n"
		else:
			ipaddr = smllib.shell.CMDGET("ifconfig  | grep 'inet '  | awk '{sub(/addr:/, \"\", $2); print $2}'")
			if (globalConfig['config.fixedip'] and (globalConfig['config.fixedip'] in ipaddr)):
				ipaddr = globalConfig['config.fixedip'] + "\n"
			
		# ipaddr now contains all IP's with global scope assigned to this machine they are separated by \n and end with an empty line
		[self.ips.append(x) for x in ipaddr.split("\n")[0:-1]]
	    	
	def getPluginName(self):
	    return "tomcat initer"
	    
	def getAbout(self):
	    return "puts a working tomcat installation in place"
	
        def disableListings(self,projinfo):
	    tomcatconf = projinfo["project.tomcatconf"]
	    if (not "server.xml" in tomcatconf):
                smllib.shell.D("tomcatconf is not server.xml, not disabling listings")
            webxmlpath = tomcatconf.replace("server.xml","web.xml")
	    webxml = xml.dom.minidom.parse(webxmlpath)
	    initparams = webxml.getElementsByTagName('init-param')
	    for param in initparams:
		paramname = str(param.getElementsByTagName('param-name')[0].firstChild.data)
		if (paramname == 'listings'):
                    param.getElementsByTagName('param-value')[0].firstChild.data = u'false'
            savefile = open(webxmlpath,'w')
            savefile.write(smllib.improvexml.makeXMLReadable(webxml))
	    savefile.close()
                
        
	def performAction(self, projinfo):
		tomcatversion = self.skelinfo['tomcat.version']
		smllib.shell.D("Downloading tomcat from http://apache.cu.be/tomcat/tomcat-7/v%s/bin/apache-tomcat-%s.tar.gz" % (tomcatversion, tomcatversion), 2)
		smllib.shell.CMD("wget -P /tmp http://apache.cu.be/tomcat/tomcat-7/v%s/bin/apache-tomcat-%s.tar.gz" % (tomcatversion, tomcatversion))
		smllib.shell.D("Untarring tomcat version %s in %s/tomcat/ (this may take a while)" % (tomcatversion, projinfo['project.dir']), 2)
		if not os.access("/tmp/apache-tomcat-%s.tar.gz" % tomcatversion, os.F_OK):
			smllib.shell.showerror("no tomcat version %s archive found" % tomcatversion)
		tomcattar = tarfile.open("/tmp/apache-tomcat-%s.tar.gz" % (tomcatversion), 'r:gz')
		for file in tomcattar.getmembers():
			tomcattar.extract(file, path=projinfo['project.dir']+"/tomcat")
		# we need to add a setenv.sh file to the binary dir of the installation
		# in order to find the correct dir, we look insinde the tar-file
		bindir = ''
		for member in tomcattar.getnames():
			if member.endswith('startup.sh'):
				bindir = member.rstrip('startup.sh')
				break
		if bindir == '':
			smllib.shell.showerror("tomcat tar is not in expected format (cannot find startup.sh)!")
		smllib.shell.D("Adding a setenv.sh to the installation in %s/tomcat/%s" % (projinfo['project.dir'], bindir), 2)
		envfile = open("%s/tomcat/%s/setenv.sh" % (projinfo['project.dir'], bindir), 'w')
		envfile.write('export JAVA_HOME="%s"' % self.skelinfo['java.home'])
		envfile.write("\nexport TOMCAT_VERSION=\"%s\"" % tomcatversion)
		envfile.write("\nexport PATH=$PATH:$JAVA_HOME/bin\n")
		envfile.write("if [ -f /etc/tomcat/setenv.sh ]; then\n")
		envfile.write("      . /etc/tomcat/setenv.sh\n")
		envfile.write("fi\n")
		envfile.close()
	    
	    #remove confusing shell startup en shutdown scripts for FDK
	    #smllib.shell.CMD("rm %s/tomcat/%s/startup.*" % (projinfo['project.dir'], bindir))
    	 #   smllib.shell.CMD("rm %s/tomcat/%s/shutdown.*" % (projinfo['project.dir'], bindir))

	    # we need to create a useful user/pass for the tomcat admin/manager
	    # this is done via an XML file in the tomcat installation
	    # doing this will overwrite the tomcat-users.xml file provided by tomcat (!)
		pwd = smllib.shell.CMDGET('pwgen --num-passwords=1 --secure').rstrip()
		smllib.shell.D("Creating admin/manager roles and superuser in tomcat-users.xml (manager/%s)" % pwd , 2)
	    
		usersxml = ''
		for membername in tomcattar.getnames():
			if membername.endswith('tomcat-users.xml'):
				usersxml = membername
				break
		if usersxml == '':
			smllib.shell.warning("tomcat tar is not in expected format (cannot find tomcat-users.xml)!")
		
		conffile = xml.dom.minidom.Document()
		conffile.appendChild(conffile.createElement('tomcat-users'))		 
		
		adminrole = conffile.createElement('role')
		adminrole.setAttribute("rolename", "manager")
		conffile.documentElement.appendChild(adminrole)
	    
		managerrole = conffile.createElement('role')
		managerrole.setAttribute("rolename", "admin")
		conffile.documentElement.appendChild(managerrole)
	    
		superuser = conffile.createElement('user')
		superuser.setAttribute("password", pwd)
		superuser.setAttribute("name", "manager")
		superuser.setAttribute("roles", "manager,admin")
		conffile.documentElement.appendChild(superuser)
		
		savefile = open("%s/tomcat/%s" % (projinfo['project.dir'], usersxml), 'w')
		savefile.write(smllib.improvexml.makeXMLReadable(conffile))
		savefile.close()
	    
		#to avoid unnecessary deployments we remove the webapps we don't need
		smllib.shell.D("Removing unnecessary webapps", 2)
		webappdir = ''
		for membername in tomcattar.getnames():
			if membername.rfind('webapps/ROOT') > -1:
				webappdir = membername.rstrip('ROOT/')
				break
		if webappdir == '':
			smllib.shell.warning("no webapps found.. (this is strange??)")
		else:
			webapps = os.listdir("%s/tomcat/%s" % (projinfo['project.dir'], webappdir))
			webapps.remove('ROOT')
			webapps.remove('manager')
			for webapp in webapps:
				smllib.shell.D("bye bye %s" % webapp, 3)	
				smllib.shell.CMD("rm -Rf %s/tomcat/%s/%s" % (projinfo['project.dir'], webappdir, webapp))
		
		#now we create a useful server.xml by editing the provided one
		smllib.shell.D("Creating a useful server.xml", 2)
		serverxml = ''
		for membername in tomcattar.getnames():
			if membername.rfind('server.xml') > -1:
				serverxml = projinfo['project.dir'] + "/tomcat/" + membername
				break
		if serverxml == '':
			smllib.shell.showerror("tomcat tar is not in expected format (cannot find server.xml)!")
		else:
			serverfile = xml.dom.minidom.parse(serverxml)
			
			#we need to get rid of the connector at port 8080
			connectors = serverfile.getElementsByTagName('Connector')
			for connector in connectors:
				if connector.getAttribute('port') == '8080':
					connector.parentNode.removeChild(connector)
		
		serverfh = open(serverxml, 'w')
		serverfh.write(smllib.improvexml.makeXMLReadable(serverfile))
		serverfh.close()
		
		#finally we store some useful information in the project config file
		projinfo.set('project.tomcatconf', serverxml)
	
	    
		#to make this tomcat installation easily available, we make a default symlink. Delete the old one if available.
		tomcatbase = tomcattar.getnames()[0].split("/")[0]
		smllib.shell.D("Symlinking %s to default" % tomcatbase, 2)
		smllib.shell.CMD("rm -f %s/tomcat/default" % (projinfo['project.dir']))
		smllib.shell.CMD("ln -fs %s/tomcat/%s %s/tomcat/default" % (projinfo['project.dir'], tomcatbase, projinfo['project.dir']))

		self.disableListings(projinfo)
	      	    
def getPlugin():
    return TomcatCreationPlugin()
