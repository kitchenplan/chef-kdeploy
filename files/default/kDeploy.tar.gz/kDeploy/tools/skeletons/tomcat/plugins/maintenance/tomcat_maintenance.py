import smllib.shell
import xml.dom.minidom
from smllib.maintenanceplugin import MaintenancePlugin
import smllib.improvexml
import os
useJava=True
try:
  import java.lang
except ImportError:
  useJava=False

class TomcatMaintenancePlugin ( MaintenancePlugin ):
    def __init__( self ):
        #this hash will contain all ports and age from the different tomcats
        #on this machine. key: projectname, value: [serverport, connectorport, ctime of conffile]
        #their range is 8000-8999: servers < 8500, connectors >= 8500
        self.tomcatports = {}
        self.MIN_SPORT = 8000
        self.MAX_SPORT = 8499
        self.MIN_CPORT = 8500
        self.MAX_CPORT = 9000
        #lists containing all connector/server ports used by the projects
        self.cports = []
        self.sports = []
        
        #this list containts projects whose connector/server port need to change
        self.connectorintruders = []
        self.serverintruders = []
        self.tomcatprojects = []
        
        self.jkversion = 2

    def getAbout( self ):
		"""
			returns a string containing the reason for this plugins existance
		"""
		return "makes sure different server.xml configs can coexist in peace"

    def getPluginName( self ):
		"""
			returns the name of this plugin (string)
		"""
		return "tomcat maintainer"

    def checkPreconditions( self, information ):
		"""
			runs before the plugin is really executed
			the plugin will only have effect if it passes this test
		"""
		#we do this here and not in doPreProjects, cause this might cause an error
		#if a server- or connectorport is not found
		self.jkversion = information["config.jkversion"]
	        tcconf = information['project.tomcatconf']
		if "config.projectsdirprefix" in information.keys():
			tcconf = information["config.projectsdirprefix"] + tcconf
		tomcatxml = xml.dom.minidom.parse( tcconf )
		age = os.stat( tcconf ).st_ctime #returns the creation time
		connectors = tomcatxml.getElementsByTagName( 'Connector' )
		self.tomcatprojects.append( information['project.name'] )
		for connector in connectors:
			self.tomcatports[information['project.name']] = ( str( tomcatxml.documentElement.getAttribute( 'port' ) ), str( connector.getAttribute( 'port' ) ), age )
			self.cports.append( str( connector.getAttribute( 'port' ) ) )
			self.sports.append( str( tomcatxml.documentElement.getAttribute( 'port' ) ) )

    def doPreProjects( self ):
		"""
			does dome pre processing before the doOnProject
			happens only once (not once per project!)

			here we mark which projects are due to a portchange
			(this shouldn't be too many projects)
			if two ports on different projects collide, the youngest
			project is marked
		"""
		#just temporary dicts containing the oldest project as a value to their ports
		self.serverports = {}
		self.connectorports = {}

		for project in self.tomcatports.keys():
			serverport = self.tomcatports[project][0]
			connectorport = self.tomcatports[project][1]

			if int( serverport ) < self.MIN_SPORT or int( serverport ) > self.MAX_SPORT:
			    self.serverintruders.append( project )
			if int( connectorport ) < self.MIN_CPORT or int( connectorport ) > self.MAX_CPORT:
			    self.connectorintruders.append( project )

			if not serverport in self.serverports.keys():
			    self.serverports[serverport] = project
			else: #servercollision!
			    #first we look for the oldest project (they can't be of exactly the same age)
			    project1 = self.serverports[serverport]
			    project2 = project
			    age1 = self.tomcatports[project1][2]
			    age2 = self.tomcatports[project2][2]
			    #the youngest will have to move (respect the older)
			    if age2 > age1: #the new project is the youngest, so we mark it
			    	self.serverintruders.append( project2 )
			    else: #the new project is older and gets a seat in the bus, the other one is kicked out and marked
			        self.serverintruders.append( project1 )
				self.serverports[serverport] = project2

			if not connectorport in self.connectorports.keys():
			    self.connectorports[connectorport] = project
			else: #connectorcollision!
			    #first we look for the oldest project (they can't be of exactly the same age)
			    project1 = self.connectorports[connectorport]
			    project2 = project
			    age1 = self.tomcatports[project1][2]
			    age2 = self.tomcatports[project2][2]
			    #the youngest will have to move (respect the older)
			    if age2 > age1: #the new project is the youngest, so we mark it
			    	self.connectorintruders.append( project2 )
			    else: #the new project is older and gets a seat in the bus, the other one is kicked out and marked
			        self.connectorintruders.append( project1 )
				self.connectorports[connectorport] = project2

		#register the used ports
		self.cports = self.connectorports.keys()
		self.sports = self.serverports.keys()

		if ( True ):
			#creation of workers2.properties header (complete file will be regenerated)
			workprop = open( "/etc/apache2/workers2.properties", "w" )
			workprop.write( """[logger.apache2]
level=ERROR

[shm:]
info=Scoreboard. Required for reconfiguration and status with multiprocess servers
file=${serverRoot}/logs/jk2.shm
size=1048576
debug=0
disabled=0
		""" + "\n" )
			try:
				orig = open( "/etc/apache2/workers2.properties.pre", "r" )
				workprop.write( orig.read() )
				orig.close()
			except IOError:
				pass
			workprop.close()

			#creation of workers.properties header (complete file will be regenerated)
			workprop = open( "/etc/apache2/workers.properties", "w" )
			workprop.write( """worker.list=%s""" % ( ",".join( self.tomcatprojects ) ) )
			try:
				orig = open( "/etc/apache2/workers.properties.pre", "r" )
				workprop.write( orig.read() )
				orig.close()
			except IOError:
				pass
			workprop.close()


    def doOnProject( self, information ):
		"""
			actually does what this plugin is made for, once per project

			sets new conncector and server ports to projects due to a portchange
			adds project to workers2.properties file
		"""

		tcconf = information['project.tomcatconf']
		if "config.projectsdirprefix" in information.keys():
			tcconf = information["config.projectsdirprefix"] + tcconf
		tomcatxml = xml.dom.minidom.parse( tcconf )
		connectors = tomcatxml.getElementsByTagName( 'Connector' )
		for connector in connectors:
			connector.setAttribute( 'URIEncoding', "UTF-8" )
		for connector in connectors:
			if ("AJP" in connector.getAttribute('protocol')):
				if (not connector.getAttribute("tomcatAuthentication")):
					connector.setAttribute('tomcatAuthentication','false')

		savefile = open( tcconf, 'w' )
		savefile.write( smllib.improvexml.makeXMLReadable( tomcatxml ) )
		savefile.close()

		conport = self.tomcatports[information['project.name']][1]

		if information['project.name'] in self.serverintruders:
		    self.setNewPort( information, 'server' )
		if information['project.name'] in self.connectorintruders:
		    conport = self.setNewPort( information, 'connector' )




		if ( True ):
			workprop = open( "/etc/apache2/workers2.properties", "a" )
			workprop.write( "\n\n" )
			workprop.write( "# channel/worker config for %s\n" % information['project.name'] )
			workprop.write( "[channel.socket:%s]\n" % information['project.name'] )
			workprop.write( "port=%s\n" % conport )
			workprop.write( "host=127.0.0.1\n" )
			workprop.write( "\n" )
			workprop.write( "[ajp13:%s]\n" % information['project.name'] )
			workprop.write( "channel=channel.socket:%s]\n" % information['project.name'] )
			workprop.write( "\n\n" )
			workprop.close()
			workprop = open( "/etc/apache2/workers.properties", "a" )
	    	workprop.write( "\n" )
	    	workprop.write( "worker.%s.type=ajp13\n" % information['project.name'] )
	    	workprop.write( "worker.%s.host=localhost\n" % information['project.name'] )
	    	workprop.write( "worker.%s.port=" % information['project.name'] )
	    	workprop.write( "%s\n" % conport )
	    	workprop.close()
		self.changeLoggingConfiguration(information)


    def doPostProjects( self ):
		"""
			does dome post processing after the doOnProject
			happens only once (not once per project!)
		"""
		pass

    def isValidPort( self, portnumber, porttype ):
	    """
	    	returns true if the given port lies between the boundaries of the
	    	porttype and is not user by any other tomcat instance yet
	    """
	    if porttype == "server":
	    	if portnumber not in self.sports and portnumber >= self.MIN_SPORT and portnumber <= self.MAX_SPORT:
		    return True
	    elif porttype == "connector":
		if portnumber not in self.cports and portnumber >= self.MIN_CPORT and portnumber <= self.MAX_CPORT:
		    return True
	    else:
		smllib.showerror( "Unknown porttype: %s" % porttype )
	    return False

    def setNewPort( self, information, porttype ):
		"""
			assigns a new tomcat port of type porttype to project projectname
			by choosing a random one between certain boundaries and checking
			it for validity

			returns the new port
		"""
		projectname = information['project.name']
		smllib.shell.D( "Assigning new %sport to %s" % ( porttype, projectname ), 3 )

		#generate new portnumbers and store them in the project's server.xml
		import random
		random.seed
		tcconf = information['project.tomcatconf']
                if "config.projectsdirprefix" in information.keys():
                        tcconf = information["config.projectsdirprefix"] + tcconf
		tomcatxml = xml.dom.minidom.parse( tcconf )

		newport = -1
		if porttype == 'server':
		    while not self.isValidPort( newport, porttype ):
		    	newport = random.randint( self.MIN_SPORT, self.MAX_SPORT )
		    tomcatxml.documentElement.setAttribute( 'port', str( newport ) )
		    self.sports.append( newport )
		elif porttype == 'connector':
		    connectors = tomcatxml.getElementsByTagName( 'Connector' )
		    for connector in connectors:
			while not self.isValidPort( newport, porttype ):
				newport = random.randint( self.MIN_CPORT, self.MAX_CPORT )
		    	connector.setAttribute( 'port', str( newport ) )
		    	self.cports.append( newport )
		else:
		    smllib.showerror( "Unknown porttype %s:" % porttype )

		savefile = open( tcconf, 'w' )
	    	savefile.write( smllib.improvexml.makeXMLReadable( tomcatxml ) )
	    	savefile.close()

		smllib.shell.warn( "Please restart tomcat for %s!" % information['project.name'] )

		return newport

    def changeLoggingConfiguration( self, information ):
		"""
		changes configuration of the standard log-directories in:
            - tomcat/default/conf/logging.properties
            - tomcat/default/bin/catalina.sh
            moves the tomcat logfiles to nobackup/tomcat/logs
		"""
		smllib.shell.D( "Maintaining nobackup folders", 3 )
		exit = smllib.shell.CMDX( "id %s >/dev/null 2>&1  || exit 1" % (information['project.user']) )
		if exit == 0:
			logproperties = information["project.dir"]+"/tomcat/default/conf/logging.properties"
			catalina = information["project.dir"]+"/tomcat/default/bin/catalina.sh"
			olddir = information["project.dir"]+"/tomcat/default"
			newdir = information["project.dir"]+"/nobackup/tomcat"
			if not self.hasCorrectLoggingProperties( logproperties ):
				self.changeLoggingProperties( logproperties, newdir )
			if not self.hasCorrectCatalina( catalina ):
				self.changeCatalina( catalina, newdir )
			smllib.shell.CMD('su - %s -c \'mkdir -p %s/temp \'' % (information['project.user'],newdir)) 
			smllib.shell.CMD('su - %s -c \'mkdir -p %s/logs \'' % (information['project.user'],newdir)) 
			if os.path.exists( olddir+"/logs" ) and not os.path.islink( olddir+"/logs" ):
				self.moveDirectory( olddir+"/logs", newdir+"/logs", information )
				self.createSymLink( olddir+"/logs", newdir+"/logs", information )
			elif not os.path.exists( olddir+"/logs" ):
				self.createSymLink( olddir+"/logs", newdir+"/logs" , information)
			if os.path.exists(olddir+"/temp" ) and not os.path.islink( olddir+"/temp" ):
				self.moveDirectory( olddir+"/temp", newdir+"/temp", information )
				self.createSymLink( olddir+"/temp", newdir+"/temp", information )
			elif not os.path.exists( olddir+"/temp" ):
				self.createSymLink( olddir+"/temp", newdir+"/temp", information )
		else:
			smllib.shell.warn( "Please run fixperms.py %s first!" % information['project.name'] )

    def hasCorrectLoggingProperties( self, properties ):
        """
            checks if the log-directories in the file 'logging.properties' are directed to the /nobackup-directories

            @param properties: path of the logging.properties file
            @return: if (properties-file contains no catalina.base )? true : false
        """
        if os.path.isfile(properties):
			f = open(properties,'r')
			lines = f.readlines()
			f.close()
			if "".join(lines).__contains__('catalina.base'):
				return False
			else:
				return True
        else:
			smllib.shell.warn("The file %s does not exist. Please correct this and run maintenance again." % properties)
			# returns true to prevent changeLoggingProperties will be called ( see changeLoggingConfiguration )
			return True


    def changeLoggingProperties( self, properties, dir ):
		"""
			changes the log-directories in the file 'logging.properties' to the new log-directories

			@param properties: path of the logging.properties file
			@param dir: path of the tomcat nobackup-directory
		"""
		smllib.shell.D( "Configuring logging.properties", 4 )
		f = open(properties,'r')
		lines = f.readlines()
		f.close()
		for i in range(len(lines)):
			if lines[i].find('1catalina.org.apache.juli.FileHandler.directory') > -1:
				lines[i] = "1catalina.org.apache.juli.FileHandler.directory = %s/logs\n" % dir
			if lines[i].find('2localhost.org.apache.juli.FileHandler.directory') > -1:
				lines[i] = "2localhost.org.apache.juli.FileHandler.directory = %s/logs\n" % dir
			if lines[i].find('3manager.org.apache.juli.FileHandler.directory') > -1:
				lines[i] = "3manager.org.apache.juli.FileHandler.directory = %s/logs\n" % dir
			if lines[i].find('4admin.org.apache.juli.FileHandler.directory') > -1:
				lines[i] = "4admin.org.apache.juli.FileHandler.directory = %s/logs\n" % dir
			if lines[i].find('5host-manager.org.apache.juli.FileHandler.directory') > -1:
				lines[i] = "5host-manager.org.apache.juli.FileHandler.directory = %s/logs\n" % dir
		newf = open(properties,'w')
		newf.writelines(lines)
		newf.close()
    def hasCorrectCatalina( self, catalina ):
		"""
			checks if the log-directories and temp-directory in the file 'catalina.sh' are directed to the /nobackup-directory

			@param catalina: path of the catalina.sh file
			@return: if (catalina.sh contains no 'CATALINA_TMPDIR="$CATALINA_BASE"/temp' )? true : false
		"""
		if os.path.isfile(catalina):
			f = open(catalina,'r')
			lines = f.readlines()
			f.close()
			if "".join(lines).__contains__('CATALINA_TMPDIR="$CATALINA_BASE"/temp'):
				return False
			else:
				return True
		else:
			smllib.shell.warn("The file %s does not exist. Please correct this and run maintenance again." % catalina )
			# returns true to prevent changeCatalina will be called ( see changeLoggingConfiguration )
			return False

    def changeCatalina( self, catalina, dir ):
		"""
			changes the path of catalina.out in the file 'catalina.sh'

			@param catalina: path of the catalina.sh file
			@param logdir: path of the tomcat logging-directory
		"""
		smllib.shell.D( "Configuring catalina.sh", 4 )
		f = open(catalina,'r')
		lines = f.readlines()
		f.close()
		for i in range(len(lines)):
			if lines[i].find('CATALINA_TMPDIR="') > -1:
				lines[i] = "CATALINA_TMPDIR=%s/temp\n" % dir
			if lines[i].find('touch "$CATALINA_BASE"/logs/catalina.out') > -1:
				lines[i] = "  touch %s/logs/catalina.out\n" % dir
			if lines[i].find('>> "$CATALINA_BASE"/logs/catalina.out 2>&1 &') > -1:
				lines[i] = "      >> %s/logs/catalina.out 2>&1 &\n" % dir
		newf = open(catalina,'w')
		newf.writelines(lines)
		newf.close()
		
    def createSymLink( self, olddir, newdir, information ):
		exit = smllib.shell.CMDX( "ln -s %s %s" % (newdir, olddir) )
		if exit != 0:
			smllib.shell.warn( "Something went wrong with creating a symlink from %s to %s for %s" % (newdir, olddir, information['project.name'] ))

    def moveDirectory( self, olddir, newdir, information ):
		exit = smllib.shell.CMDX( "su - %s -c 'mkdir -p %s';[\"$(ls -A %s)\"] && mv -uf %s/* %s; rm -r %s" % (information['project.user'],newdir, olddir, olddir, newdir, olddir) )
		if exit != 0:
			smllib.shell.warn( "Something went wrong with (re)moving %s to %s for %s" % (olddir, newdir, information['project.name'] ))


def getPlugin():
    return TomcatMaintenancePlugin()
