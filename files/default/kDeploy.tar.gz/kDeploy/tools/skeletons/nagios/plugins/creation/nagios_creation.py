from smllib.creationplugin import CreationPlugin
import smllib.shell

class NagiosCreationPlugin (CreationPlugin):
	def __init__(self):
		pass
		
	def getAbout(self):
		"""
			returns a string containing the reason for this plugins existance
		"""
		return "fetches the required information to generate a correct nagios.xml file"
	    	
	def getPluginName(self):
		"""
			returns the name of this plugin (string)
		"""
		return "nagios creator"
	    			
	def performAction(self, information):
		"""
			does what this plugin is made for, once per project
		"""
		information.queryUser('project.nagiosuri', '/')
		#information.queryUser('project.nagiosregexp')
		smllib.shell.CMD('cp %s/nagios/files/conf/nagios.xml %s%s/conf/' % (information['config.skeletonsdir'], information['config.projectsdir'], information['project.name']))
	    			
def getPlugin():
    return NagiosCreationPlugin()
