from smllib.maintenanceplugin import MaintenancePlugin
import smllib.shell
import smllib.projectinformation

class MonMaintenancePlugin (MaintenancePlugin):
	def __init__(self):
		#lists that contain all projects' mon.cf files
		self.mons = []
		
		#list of monitortypes
		
	def getAbout(self):
		"""
			returns a string containing the reason for this plugins existance
		"""
		return "makes sure the default nagios.xml files are adapted to suit the project needs"
		
	def getPluginName(self):
		"""
			returns the name of this plugin (string)
		"""
		return "nagios maintainer"
	
	def checkPreconditions(self, information):
		"""
			runs before the plugin is really executed
			the plugin will only have effect if it passes this test
		"""
		pass
	
	def doPreProjects(self):
		"""
			does dome pre processing before the doOnProject
			happens only once (not once per project!)
			opens and empties the general bigmon conf file
			for either types mail and sms
		"""
		globalConfig = smllib.projectinformation.getBaseInformation()
		if not globalConfig['config.nagios']:
			smllib.shell.showerror('Could not find config.nagios entry in global config.xml file :-(')
		nagios = globalConfig['config.nagios']
		nagiosfile = open(nagios, 'w')
		nagiosfile.write("<projects>")
		nagiosfile.close()
				
		
	def doOnProject(self, information):
		"""
			actually does what this plugin is made for, once per project
			replaces monitor lines in the mon.cf files of a project with correct statements
			and adds those lines to the general big mon.cf file
		"""
		globalConfig = smllib.projectinformation.getBaseInformation()
		if not globalConfig['config.nagios']:
			smllib.shell.showerror('Could not find config.nagios entry in global config.xml file :-(')
		nagios = globalConfig['config.nagios']
		smllib.shell.D("Generating nice and clean nagios configuration in %s" % (nagios), 2)
		nagiosfile = open(nagios, 'a')
		nagiosconf = open("%s/conf/nagios.xml" % (information['project.dir']), 'r')
		replacer = information.getReplacer()
		for line in nagiosconf:
			nagiosfile.write(replacer.replace(line))
		nagiosfile.close()
		nagiosconf.close()
			
	def doPostProjects(self):
		"""
			does dome post processing after the doOnProject
			happens only once (not once per project!)
			
			collects all mon.cf files and creates a big one out of them
			this big one is placed in config.bigmon
		"""
		globalConfig = smllib.projectinformation.getBaseInformation()
		if not globalConfig['config.nagios']:
			smllib.shell.showerror('Could not find config.nagios entry in global config.xml file :-(')
		nagios = globalConfig['config.nagios']
		nagiosfile = open(nagios, 'a')
		nagiosfile.write("</projects>")
		nagiosfile.close()
		
		
def getPlugin():
    return MonMaintenancePlugin()
