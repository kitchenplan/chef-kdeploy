from smllib.removalplugin import RemovalPlugin
import smllib.shell
import smllib.platform


def removeUserGroup(project):
    	"""
    		removes the user and group of a given project
    	"""
	smllib.shell.D("Removing user %s and group %s" % (project['project.user'], project['project.group']))
	if (smllib.platform.getPlatform()[0] == "Darwin"):
		smllib.shell.CMD("dscl . delete /Users/%s" % project['project.user'])
		smllib.shell.CMD("dscl . delete /groups/%s" % project['project.group'])
	else:
		smllib.shell.CMD("userdel %s" % project['project.user'])


class BaseRemovalPlugin (RemovalPlugin):
	def __init__(self):
		pass
		
	def getAbout(self):
		"""
			returns a string containing the reason for this plugins existance
		"""
		return "base removal plugin"
	    	
	def getPluginName(self):
		"""
			returns the name of this plugin (string)
		"""
		return "base removal plugin"
	    			
	def doPreRemove(self, information):
		"""
			does what this plugin is made for, once per project
		"""
		smllib.shell.D("Testing pre plugin for project %s" % (information['project.name']))

	def doPostRemove(self, information):
		"""
			does what this plugin is made for, once per project
		"""
		removeUserGroup(information)
		
def getPlugin():
    return BaseRemovalPlugin()