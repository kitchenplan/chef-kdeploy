from smllib.backupplugin import BackupPlugin
import smllib.shell

class BaseBackupPlugin (BackupPlugin):
	def __init__(self):
		pass
		
	def getAbout(self):
		"""
			returns a string containing the reason for this plugins existance
		"""
		return "tests the backup plugin system"
	    	
	def getPluginName(self):
		"""
			returns the name of this plugin (string)
		"""
		return "backup plugin tester"
	    			
	def doPreTar(self, information):
		"""
			does what this plugin is made for, once per project
		"""
		smllib.shell.D("Testing pre plugin for project %s" % (information['project.name']))

	def doPostTar(self, information):
		"""
			does what this plugin is made for, once per project
		"""
		smllib.shell.D("Testing post plugin for project %s" % (information['project.name']))
		
def getPlugin():
    return BaseBackupPlugin()