from smllib.creationplugin import CreationPlugin
import smllib.shell

class CleanPlugin (CreationPlugin):
	def __init__(self):
		pass
		
	def getAbout(self):
		"""
			returns a string containing the reason for this plugins existance
		"""
		return "cleans a new project dir"
	    	
	def getPluginName(self):
		"""
			returns the name of this plugin (string)
		"""
		return "dir cleaner"
	    			
	def performAction(self, information):
		"""
			does what this plugin is made for, once per project
		"""
		smllib.shell.D("Removing .emptyDir leftovers")
		smllib.shell.CMD("find %s -type f -name '.emptyDir' -exec rm {} \;" % information['project.dir'])
			
def getPlugin():
    return CleanPlugin()