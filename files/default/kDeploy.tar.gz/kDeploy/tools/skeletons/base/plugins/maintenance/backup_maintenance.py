import sys
sys.path.append('/opt/kDeploy/tools')
import os.path
from smllib.maintenanceplugin import MaintenancePlugin
from smllib.xmldictionary import XMLDictionary
from smllib.information import Information
import smllib.shell

class BackupPlugin(MaintenancePlugin):
	def __init__(self):
		pass

	### begin * MaintenancePlugin implementation ###
	def getAbout(self):
		return "Defines which directories should be excluded in backup.xml"
	
	def canSkip(self):
		return False
	
	def getPluginName(self):
		return "backup configuration fixer"
	
	def doOnProject(self, information):		
		backupConfig = XMLDictionary("%s%s/conf/backup.xml" % (information['config.projectsdir'], information['project.name']))
		excludes = ['/nobackup/', '/resizedcache/','/data/%s/vendor/'%information['project.name'],'/data/%s/app/log'%information['project.name'],'/data/%s/app/cache'%information['project.name']]
		if [ skel for skel in information["project.skeletons"] if skel == 'tomcat'] :
			excludes.append('/tomcat/default/webapps/')
		if [ skel for skel in information["project.skeletons"] if skel == 'coldfusionmx'] :
			excludes.remove('/tomcat/default/webapps/')
		for exclude in excludes:
			if not exclude in backupConfig['backup.excludes']:
				if not isinstance(backupConfig['backup.excludes'], type([]) ):
					backupConfig['backup.excludes'] = []
				backupConfig['backup.excludes'].append(exclude)
				if not os.path.exists('%s%s%s' %  (information['config.projectsdir'],information['project.name'],exclude)): 
			    		exit = smllib.shell.CMDX('su - %s -c \'mkdir -p %s%s%s\'' % (information['project.user'],information['config.projectsdir'],information['project.name'],exclude))
			    		if exit!=0:
			    			smllib.shell.warn( "Please run fixperms.py %s first!" % information['project.name'] )
		backupConfig.toSave.append('backup.excludes')
		backupConfig.save()
		
	def doPostProjects(self):
		pass
	
	def doPreProjects(self):
		pass

	def checkPreconditions(self, information):
		pass

def getPlugin():
	return BackupPlugin()
