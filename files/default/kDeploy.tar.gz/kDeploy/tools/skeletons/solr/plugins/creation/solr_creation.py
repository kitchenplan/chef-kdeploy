from smllib.creationplugin import CreationPlugin
from smllib.shell import *
from smllib.information import Information
import smllib.projectinformation
import os
import xml.dom.minidom
import smllib.improvexml
import re
import shutil

class SolrCreationPlugin (CreationPlugin):

	def __init__(self):
		#load the skeletonconfiguration
		self.skelinfo = Information(None)
		self.skelinfo.bindXML(smllib.projectinformation.getBaseInformation()['config.skeletonsdir'] + "/solr/config.xml")
		globalConfig = smllib.projectinformation.getBaseInformation()	
		self.ips = []
		# clearing the iplist
		[self.ips.remove(x) for x in self.ips] 
		# we collect the machine's IP addresses at init
		if (globalConfig['config.options'] and ("localhost-only" in globalConfig['config.options'])):
			ipaddr = "127.0.0.1\n"
		else:
			ipaddr = smllib.shell.CMDGET("ifconfig  | grep 'inet '  | awk '{sub(/addr:/, \"\", $2); print $2}'")
			if (globalConfig['config.fixedip'] and (globalConfig['config.fixedip'] in ipaddr)):
				ipaddr = globalConfig['config.fixedip'] + "\n"
			
		# ipaddr now contains all IP's with global scope assigned to this machine they are separated by \n and end with an empty line
		[self.ips.append(x) for x in ipaddr.split("\n")[0:-1]]
	    	
	def getPluginName(self):
		return "solr initer"
	    
	def getAbout(self):
		return "puts a working solr installation in place"
	
	def disableListings(self,projinfo):
		return "Not implemented"
		
	def getText(nodelist):
	    rc = []
	    for node in nodelist:
		   if node.nodeType == node.TEXT_NODE:
		       rc.append(node.data)
	    return ''.join(rc)
        
	def performAction(self, projinfo):
		import tarfile

		D("Please provide a solr instance name. This is the url suffix to which this solr instance will be accessible. For example [http://%s/solr-%s]" % (projinfo["project.url"], projinfo['project.name']))
		
		self.skelinfo.queryUser("solr.instance", "solr-%s" % projinfo['project.name'])
		self.skelinfo['solr.war'] = "apache-solr-%s.war" % self.skelinfo['solr.version']
		self.skelinfo['solr.instance.dir'] = "%s/solr/%s" % (projinfo['project.dir'], self.skelinfo['solr.instance'])
		
		if not os.access(self.skelinfo['solr.instance.dir'], os.F_OK):
			os.makedirs(self.skelinfo['solr.instance.dir'])

		solrversion = self.skelinfo['solr.version']
		smllib.shell.D("Downloading tomcat from http://archive.apache.org/dist/lucene/solr/%s/apache-solr-%s.tgz" % (solrversion, solrversion), 2)
		smllib.shell.CMD("wget -P /tmp http://archive.apache.org/dist/lucene/solr/%s/apache-solr-%s.tgz" % (solrversion, solrversion))
		# First we untar the solr installation into the project dir/solr
		# we expect the archive to be in @project.skeletondir@/solr/data/solr-@solr.version@
		D("Untarring solr version %s in %s/solr/ (this may take a while)" % (solrversion, projinfo['project.dir']))
		if not os.access("/tmp/apache-solr-%s.tgz" % solrversion, os.F_OK):
			smllib.shell.showerror("no solr version %s archive found" % solrversion)

		# Search for the Solr war file in the tar and extract if found
		solrtar = tarfile.open("/tmp/apache-solr-%s.tgz" % solrversion, 'r:gz')
		tempdir = "%s/solr/tmp/" % projinfo['project.dir']
		for file in solrtar.getmembers():
			if file.name.endswith(self.skelinfo['solr.war']):
				D("extracting file [%s] tmp dir" % file.name, 2)
				solrtar.extract(file, path=tempdir)
				self.skelinfo['solr.war.path'] = "%s/solr/%s" % (projinfo['project.dir'], self.skelinfo['solr.war'])
				shutil.copy("%s%s" % (tempdir, file.name), self.skelinfo['solr.war.path'])

		# CollectiveAccess comes with automated solr configuration scripts. Look for these files and propose to run them.
		if ('php5' in projinfo['project.skeletons']) | ('php4' in projinfo['project.skeletons']) | ('php3' in projinfo['project.skeletons']):
			D("This is a php project")
			# check if collective access config files exist
			hasAppConf = os.path.exists("%s/data/app/conf/app.conf" % (projinfo['project.dir']))
			hasSearchConf = os.path.exists("%s/data/app/conf/search.conf" % (projinfo['project.dir']))
			hasConfScript = os.path.exists("%s/data/support/utils/createSolrConfiguration.php" % (projinfo['project.dir']))
			if (hasAppConf & hasSearchConf & hasConfScript):
				D("There is a very big chance this is a Collective Access project.")
				autoconfig = ask("Would you like me to do the solr configurations 4 you? [Y/n]")
				if (autoconfig == 'Y') | (autoconfig == 'y'):
					# change configurations
					self.replaceLineInFile("%s/data/app/conf/app.conf" % projinfo['project.dir'], "search_engine_plugin.*", "search_engine_plugin = Solr")
					self.replaceLineInFile("%s/data/app/conf/search.conf" % projinfo['project.dir'], "search_solr_home_dir.*", "search_solr_home_dir = %s" % self.skelinfo['solr.instance.dir'])
					self.replaceLineInFile("%s/data/app/conf/search.conf" % projinfo['project.dir'], "search_solr_url.*", "search_solr_url = http://%s/%s" % (projinfo["project.url"], self.skelinfo['solr.instance']))
					# execute php configuration script
					os.chdir("%s/data/support/utils" % projinfo['project.dir'])
					D("php -f %s/data/support/utils/createSolrConfiguration.php" % projinfo['project.dir'], 2)
					CMD("php -f %s/data/support/utils/createSolrConfiguration.php" % projinfo['project.dir'])
					#TODO rund reindex.php script also?
		else:
			D("Copying example configuration files")
			for file in solrtar.getmembers():
				if file.name.endswith('example/solr/conf/solrconfig.xml'):
					D("extracting file [%s] tmp dir" % file.name, 2)
					solrtar.extract(file, path=tempdir)
					self.skelinfo['solr.config.example'] = "%s/%s" % (self.skelinfo['solr.instance.dir'], 'solrconfig.xml')
					shutil.copy("%s%s" % (tempdir, file.name), self.skelinfo['solr.config.example'])
					# configure the data dir
					self.replaceXmlElementInFile(self.skelinfo['solr.config.example'], "dataDir", self.skelinfo['solr.instance.dir'])
			
				if file.name.endswith('example/solr/conf/schema.xml'):
					D("extracting file [%s] tmp dir" % file.name, 2)
					solrtar.extract(file, path=tempdir)
					self.skelinfo['solr.schema.example'] = "%s/%s" % (self.skelinfo['solr.instance.dir'], 'schema.xml')
					shutil.copy("%s%s" % (tempdir, file.name), self.skelinfo['solr.schema.example'])
	
		# We create a Tomcat Context fragment for the solr instance
		self.createTomcatConfFragment(projinfo)

		D("All Done. You should probably run fixperms and restart apache & tomcat")
		D("Solr instance url: [http://%s/%s]" % (projinfo["project.url"], self.skelinfo['solr.instance']))

		self.disableListings(projinfo)

	def createTomcatConfFragment(self, projinfo):
	
		D("Creating Tomcat Configuration Fragment")
		conffragment = xml.dom.minidom.Document()
		context = conffragment.createElement('Context')
		context.setAttribute("docBase", "%s" % (self.skelinfo['solr.war.path']))
		context.setAttribute("debug", "0")
		context.setAttribute("crossContext", "true")
		conffragment.appendChild(context)

		environment = conffragment.createElement('Environment')
		environment.setAttribute("name", "solr/home")
		environment.setAttribute("type", "java.lang.String")
		environment.setAttribute("value", self.skelinfo['solr.instance.dir'])
		environment.setAttribute("override", "true")
		context.appendChild(environment)

		if not os.access("%s/tomcat/default/conf/Catalina/localhost" % (projinfo['project.dir']), os.F_OK):
			os.makedirs("%s/tomcat/default/conf/Catalina/localhost" % (projinfo['project.dir']))

		D("Saving tomcat solr config to %s/tomcat/default/conf/Catalina/localhost/%s.xml" % (projinfo['project.dir'], self.skelinfo['solr.instance']), 2)
		savefconffile = open("%s/tomcat/default/conf/Catalina/localhost/%s.xml" % (projinfo['project.dir'], self.skelinfo['solr.instance']), 'w')
		savefconffile.write(smllib.improvexml.makeXMLReadable(conffragment))
		savefconffile.close()

	def replaceLineInFile(self, fileName, sourceText, replaceText):
		file = open(fileName, "r")
		text = file.read()
		file.close()
		file = open(fileName, "w")
		#file.write(text.replace(sourceText, replaceText))
		file.write(re.sub(sourceText, replaceText, text))
		# write the whole output when done, wiping over the old contents of the file
		file.close()
		D("Replaced [%s] with [%s] in file %s" % (sourceText, replaceText, fileName), 2)
	
	def replaceXmlElementInFile(self, fileName, element, newElementValue):
		file = open(fileName, "r")
		dom = xml.dom.minidom.parse(fileName)
		file.close()
		domElement = dom.getElementsByTagName(element)
		domElement[0].firstChild.nodeValue = newElementValue
		file = open(fileName, "w")
		file.write(smllib.improvexml.makeXMLReadable(dom))
		# write the whole output when done, wiping over the old contents of the file
		file.close()
		D("Set xml element [%s] to [%s] in file %s" % (element, newElementValue, fileName), 2)


def getPlugin():
	return SolrCreationPlugin()
