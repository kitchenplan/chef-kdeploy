from smllib.backupplugin import BackupPlugin
import smllib.shell

class MysqlBackupPlugin (BackupPlugin):
	def __init__(self):
		pass

	def getAbout(self):
		"""
			returns a string containing the reason for this plugins existance
		"""
		return "mysql backup plugin"

	def getPluginName(self):
		"""
			returns the name of this plugin (string)
		"""
		return "mysql backup plugin"

	def doPreTar(self, information):
		"""
			does what this plugin is made for, once per project
		"""
		smllib.shell.D("Dumping MySQL database to mysql.dmp")
		smllib.shell.CMD("rm -f %s/backup/mysql.dmp" %(information["project.dir"]))

		smllib.shell.CMD("echo 'SET autocommit=0;' > %s/backup/mysql.dmp" %(information["project.dir"]));
		smllib.shell.CMD("echo 'SET unique_checks=0;' >> %s/backup/mysql.dmp" %(information["project.dir"]));
		smllib.shell.CMD("echo 'SET foreign_key_checks=0;' >> %s/backup/mysql.dmp" %(information["project.dir"]));

		smllib.shell.CMD("mysqldump --skip-opt --add-drop-table --add-locks --create-options --disable-keys --single-transaction --skip-extended-insert --quick --set-charset -u %s -p%s %s >> %s/backup/mysql.dmp" %(information["project.mysqluser"], information["project.mysqlpass"], information["project.mysqldbname"] ,information["project.dir"]))

		smllib.shell.CMD("echo 'COMMIT;' >> %s/backup/mysql.dmp" %(information["project.dir"]));
		smllib.shell.CMD("echo 'SET autocommit=1;' >> %s/backup/mysql.dmp" %(information["project.dir"]));
		smllib.shell.CMD("echo 'SET unique_checks=1;' >> %s/backup/mysql.dmp" %(information["project.dir"]));
		smllib.shell.CMD("echo 'SET foreign_key_checks=1;' >> %s/backup/mysql.dmp" %(information["project.dir"]));


		smllib.shell.CMD("gzip %s/backup/mysql.dmp -f" %(information["project.dir"]));

	def doPostTar(self, information):
		"""
			does what this plugin is made for, once per project
		"""
		pass

def getPlugin():
	return MysqlBackupPlugin()
