from smllib.removalplugin import RemovalPlugin
import warnings
warnings.filterwarnings("ignore", message="the sets module is deprecated")
import smllib.shell
import MySQLdb
import _mysql_exceptions


class MysqlRemovalPlugin (RemovalPlugin):
	def __init__(self):
		pass
        
            
        def getRootConnection(self,information):
                return MySQLdb.connect(host='localhost',db='mysql',user=information['config.mysqladminuser'], passwd=information['config.mysqladminpassword'])

	def getAbout(self):
		"""
			returns a string containing the reason for this plugins existance
		"""
		return "base removal plugin"
	    	
	def getPluginName(self):
		"""
			returns the name of this plugin (string)
		"""
		return "base removal plugin"
	    			
	def doPreRemove(self, information):
		"""
			does what this plugin is made for, once per project
		"""
		smllib.shell.D("Testing pre plugin for project %s" % (information['project.name']))

	def doPostRemove(self, information):
		"""
			does what this plugin is made for, once per project
		"""
		smllib.shell.D("removing mysql database")
                conn = self.getRootConnection(information)
                cr = conn.cursor()
                cr.execute("DROP DATABASE %s" % (information["project.mysqldbname"]))

		
def getPlugin():
    return MysqlRemovalPlugin()