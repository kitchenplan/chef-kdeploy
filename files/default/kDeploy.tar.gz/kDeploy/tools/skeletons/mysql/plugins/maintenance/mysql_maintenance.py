from smllib.maintenanceplugin import MaintenancePlugin

import warnings
warnings.filterwarnings("ignore", message="the sets module is deprecated")
import os
from smllib.shell import *
import smllib.assertions
from smllib.xmldictionary import XMLDictionary

useJava=False
try:
  import MySQLdb
  import _mysql_exceptions
except ImportError:
  useJava=True
  import smllib.smljdbc

class MysqlPlugin (MaintenancePlugin):
    def __init__(self):
		pass

    ### begin * MaintenancePlugin implementation ###
    def getAbout(self):
		return "creates user and database (possibly from backup) if needed"

    def getPluginName(self):
		return "mysql plugin"

    def doOnProject(self, information):
	if self.loginTest(information["project.mysqlserver"],information["project.mysqldbname"],information["project.mysqluser"],information["project.mysqlpass"]):
	    smllib.shell.D("Mysql Database setup OK", 3)
	else: ### db setup was not OK
	    if (information["project.mysqlserver"] != "localhost"):
		    message = "Database setup not OK. Please fix this on the remote server."
		    smllib.shell.D(message)
		    smllib.postman.getThePostman().collect(message)
		    smllib.postman.getThePostman().setErrorlevel(2)
	    else: ### db setup will have to be fixed locally
		    if not(self.dbTest(information)):
		        self.createDB(information)
		        smllib.shell.D("I created a fresh mysql database for project %s" % information["project.name"])
		        smllib.postman.getThePostman().setErrorlevel(1)
		        if os.listdir(information["project.dir"]+"/backup").__contains__("mysql.dmp") or os.listdir(information["project.dir"]+"/backup").__contains__("mysql.dmp.gz"):
			        self.restoreBackup(information)
			        smllib.shell.D("I restored the mysql database for project %s from backup" % information["project.name"])
			        smllib.postman.getThePostman().setErrorlevel(1)

		    if not(self.userTest(information)):
		        self.createUser(information)
		        smllib.postman.getThePostman().setErrorlevel(1)

		    if not(self.passwordTest(information)):
		        smllib.shell.showerror("password for mysql database appears to be wrong. please fix")

    def getRootConnection(self,information):
	if (useJava):
		return smllib.smljdbc.getMysqlConnection("localhost",information["config.mysqladminuser"],information["config.mysqladminpassword"],"mysql")
	else:
		return MySQLdb.connect(host='localhost',db='mysql',user=information['config.mysqladminuser'], passwd=information['config.mysqladminpassword'])

    def doPostProjects(self):
	pass

    def doPreProjects(self):
	pass

    def checkPreconditions(self, information):
		if not information['project.mysqluser']:
                    smllib.shell.warn("No database configuration found. I will generate a new one...")
                    information.queryUser("project.mysqluser", information["project.name"])
                    information.queryUser("project.mysqlpass", smllib.shell.CMDGET('pwgen --num-passwords=1').rstrip())
                    information.queryUser("project.mysqldbname", information["project.name"])
                    information.queryUser("project.mysqlserver", "localhost")
                    information.require("project.mysqluser")
                    information.require("project.mysqlpass")
                    information.require("project.mysqldbname")
                    information.require("project.mysqlserver")

    ### end * MaintenancePlugin implementation ###
    def loginTest(self,p_host,p_dbname,p_user,p_password):
        if (useJava):
          conn = smllib.smljdbc.getMysqlConnection(p_host, p_user, p_password, p_dbname)
          conn.close()
          return True
          #except _mysql_exceptions.OperationalError, detail:
          #    smllib.shell.D("Database connection error: %s" % detail)
          #    return False
          #return False
        else:
          try :
	      conn = MySQLdb.connect(host=p_host, db=p_dbname, user=p_user, passwd=p_password)
	      conn.close()
	      return True
          except _mysql_exceptions.OperationalError, detail:
              smllib.shell.D("Database connection error: %s" % detail)
              return False
          return False

    def userTest(self,information):
        return self.sqlHasRows(information,"SELECT User,Host FROM user WHERE User='%s'" % information["project.mysqluser"])

    def passwordTest(self,information):
        return self.sqlHasRows(information,"SELECT User FROM user WHERE User='%s' AND Password=PASSWORD('%s')" % (information["project.mysqluser"], information["project.mysqlpass"]))

    def sqlHasRows(self,information,sql):
       conn = self.getRootConnection(information)
       if (useJava):
          stmt = conn.createStatement()
          rs = stmt.executeQuery(sql)
          if (rs.next()):
            b= True
          else:
            b= False
            raise "h"
          rs.close()
          stmt.close()
          conn.close()
          return b
       else:
          cr = conn.cursor()
          cr.execute(sql)
          conn.commit()
          conn.close()
          if cr.rowcount > 0:
              return True
          else:
              return False



    def dbTest(self,information):
	return self.loginTest(information["project.mysqlserver"],information["project.mysqldbname"],information["config.mysqladminuser"],information["config.mysqladminpassword"])

    def doQuery(self,information,sql):
	conn = self.getRootConnection(information)
	if useJava:
	  stmt = conn.createStatement()
	  stmt.executeUpdate(sql)
	  stmt.close()
        else:
          cr = conn.cursor()
          cr.execute(sql)
          cr.close()
        conn.close()


    def createUser(self,information):
            self.doQuery(information,"GRANT ALL PRIVILEGES ON %s.* TO %s@localhost IDENTIFIED BY '%s'" % (information["project.mysqldbname"], information["project.mysqluser"], information["project.mysqlpass"]))
	    self.doQuery(information,"GRANT ALL PRIVILEGES ON %s.* TO %s@'%%' IDENTIFIED BY '%s'" % (information["project.mysqldbname"], information["project.mysqluser"], information["project.mysqlpass"]))

    def createDB(self,information):
	    self.doQuery(information,"create database %s DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci" % (information["project.mysqldbname"]))

    def restoreBackup(self,information):
        if os.listdir(information["project.dir"]+"/backup").__contains__("mysql.dmp.gz"):
	        smllib.shell.CMD("gzip -dc %s/backup/mysql.dmp.gz | mysql -u %s -p%s %s" % (information["project.dir"], information["config.mysqladminuser"], information["config.mysqladminpassword"], information["project.mysqldbname"]))
        else:
            smllib.shell.CMD("cat %s/backup/mysql.dmp | mysql -u %s -p%s %s" % (information["project.dir"], information["config.mysqladminuser"], information["config.mysqladminpassword"], information["project.mysqldbname"]))


def getPlugin():
    return MysqlPlugin()

