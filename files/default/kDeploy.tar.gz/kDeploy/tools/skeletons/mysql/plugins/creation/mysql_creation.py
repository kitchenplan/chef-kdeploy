from smllib.creationplugin import CreationPlugin
import smllib.shell
from smllib.xmldictionary import XMLDictionary

class MysqlCreationPlugin (CreationPlugin):
	def __init__(self):
		pass
		
	def getAbout(self):
		"""
			returns a string containing the reason for this plugins existance
		"""
		return "mysql skel /backup"
	    	
	def getPluginName(self):
		"""
			returns the name of this plugin (string)
		"""
		return "mysql creator"
	    			
	def performAction(self, information):
		"""
			does what this plugin is made for, once per project
		"""
		
		pass
		#permdict = XMLDictionary("%s/conf/permissions.xml" % information["project.dir"])
		#permdict.toSave=[""]
		#permdict["/backup"] = ["-R -m user:postgres:rwX"]
		#permdict.save()
	    			
def getPlugin():
    return MysqlCreationPlugin()

