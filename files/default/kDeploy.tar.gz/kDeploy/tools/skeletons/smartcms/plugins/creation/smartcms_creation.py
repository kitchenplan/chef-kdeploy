from smllib.creationplugin import CreationPlugin
import smllib.shell
from smllib.xmldictionary import XMLDictionary

class SmartcmsCreationPlugin (CreationPlugin):
	def __init__(self):
		pass
		
	def getAbout(self):
		"""
			returns a string containing the reason for this plugins existance
		"""
		return "smartcms skel"
	    	
	def getPluginName(self):
		"""
			returns the name of this plugin (string)
		"""
		return "smartcms creator"
	    			
	def performAction(self, information):
		"""
			does what this plugin is made for, once per project
		"""
		ownershipdict = XMLDictionary("%s/conf/ownership.xml" % information["project.dir"])
		ownershipdict.toSave=[""]
		ownershipdict["/files"] = "-R @project.user@.@project.group@"
		ownershipdict["/resizedcache"] = "-R @project.user@.@project.group@"
		ownershipdict["/uploadcache"] = "-R @project.user@.@project.group@"
		ownershipdict.save()
		
		information["project.monuri"] = "/" + information["project.name"] + "/view/nl/selftest"
		information["project.monregexp"] = "okay"
		information["project.nagiosuri"] = "/" + information["project.name"] + "/view/nl/selftest"
		information["project.nagiosregexp"] = "self test okay"
		
		#permdict = XMLDictionary("%s/conf/permissions.xml" % information["project.dir"])
		#permdict.toSave=[""]
		#permdict["/files"] = ["-R "]

		
	    			
def getPlugin():
    return SmartcmsCreationPlugin()