from smllib.maintenanceplugin import MaintenancePlugin

import os
useJava=False
try:
    import psycopg
    #print "using psycopg"
except ImportError:
    try:
      import psycopg2
      #print "using psycopg2"
      psycopg = psycopg2
    except ImportError:
      useJava=True
      import smllib.smljdbc

from smllib.shell import *
import smllib.assertions
from smllib.xmldictionary import XMLDictionary

class SmartcmsPlugin (MaintenancePlugin):
    def __init__(self):
	pass

    ### begin * MaintenancePlugin implementation ###
    def getAbout(self):
		return "auto-sets the catchall server of a smartcms project to the global setting"

    def getPluginName(self):
	return "smartcms maintenance plugin"

    def doOnProject(self, information):
        if not ("postgres" in information["project.skeletons"]):
          smllib.shell.D("only postgres supported",3)
          return
        if self.loginTest(information["project.dbserver"],information["project.dbname"],information["project.dbuser"],information["project.dbpass"]):
            smllib.shell.D("Database setup OK", 3)
            self.checkDevelmodeColumn(information)
            catchall = "invalid.server.fix.your.kdeploy.config.xml"
            if information["config.catchallserver"]:
              catchall = information["config.catchallserver"]
            if information["config.develmode"] == "true":
              query = "update cmsconfig set mailserver='" + catchall + "'"
              smllib.shell.D("Setting mailserver to "+catchall+ ".",3)
              self.doQuery(information,query)
              self.doQuery(information,"update cmsconfig set developermachine='t'")
              self.doQuery(information,"update cmsconfig set developer_project_url='http://" + information['project.name']+"."+information["config.hostmachine"] + "'")
            else:
              self.doQuery(information,"update cmsconfig set developermachine='f'")

        else:
          smllib.shell.D("Database setup not OK, skipping this step",3)

    def doPostProjects(self):
	pass

    def doPreProjects(self):
	pass

    def checkPreconditions(self, information):
        pass

    ### end * MaintenancePlugin implementation ###
    def loginTest(self,host,dbname,user,password):
        if (useJava):
          try:
	  	con = smllib.smljdbc.getPostgresqlConnection(host,user,password,dbname)
          	con.close()
		return True
          except:
		return False
        else:
           DSN = "host="+host+" dbname="+dbname+" user="+user+" password="+password+" host=/var/run/postgresql/"
           try :
             conn = psycopg.connect(DSN)
             conn.close()
             return True
           except psycopg.OperationalError, detail:
             smllib.shell.D("Database connection error: %s" % detail)
             return False

    def checkDevelmodeColumn(self,information):
         try:
             self.doQuery(information,"alter table cmsconfig add column developermachine boolean");
         except:
             pass

    def doQuery(self,information,sql):
       if (useJava):
          con = smllib.smljdbc.getPostgresqlConnection(information["project.dbserver"],information["project.dbuser"],information["project.dbpass"],information["project.dbname"])
          stmt = con.createStatement()
          rs = stmt.executeQuery(sql)
          if (rs.next()):
            b= True
          else:
            b= False
          rs.close()
          stmt.close()
          con.close()
          return b
       else:
          DSN = "dbname="+information["project.dbname"]+" user="+information["project.dbuser"]+" password="+information["project.dbpass"]+" host=/var/run/postgresql/"
          conn = psycopg.connect(DSN)
          cr = conn.cursor()
          try:
            cr.execute(sql)
          except psycopg.ProgrammingError, detail:
            smllib.shell.D("Query error: %s" % detail)
          conn.commit()
          conn.close()
          if cr.rowcount > 0:
              return True
          else:
              return False



def getPlugin():
    return SmartcmsPlugin()

