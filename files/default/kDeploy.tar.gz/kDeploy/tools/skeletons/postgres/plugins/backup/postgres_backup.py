from smllib.backupplugin import BackupPlugin
import smllib.shell
import smllib.platform
import sys


useJava=False
try:
    import psycopg
    print "using psycopg"
except ImportError:
    try:
      import psycopg2
      print "using psycopg2"
      psycopg = psycopg2
    except ImportError:
      useJava=True
      import smllib.smljdbc


class PostgresBackupPlugin (BackupPlugin):
	def __init__(self):
		pass

	def getAbout(self):
		"""
			returns a string containing the reason for this plugins existance
		"""
		return "postgresql backup plugin"

	def getPluginName(self):
		"""
			returns the name of this plugin (string)
		"""
		return "postgresql backup plugin"

	def doPreTar(self, information):
		"""
			does what this plugin is made for, once per project
		"""
		smllib.shell.CMD("rm -f %s/backup/postgres*" % information['project.dir'])
		if not self.loginTest(information["project.dbserver"],information["project.dbname"],information["project.dbuser"],information["project.dbpass"]):
		   smllib.shell.showerror("DATABASE SETUP NOT OKAY UNABLE TO BACKUP !!!!")
		   return
		backupformat = "plain"
		if ("config.psqlbackupformat" in information.keys()):
			backupformat = information["config.psqlbackupformat"]
		if ("plain" in sys.argv):
			backupformat = "plain"
			smllib.shell.D("Override backup format, using PLAIN")
		if (backupformat == "custom"):
			smllib.shell.D("Dumping postgres database CUSTOM to postgres.sql.gz")
			if (smllib.platform.getPlatform()[0] == "Darwin"):
				smllib.shell.CMD("su - %s -c 'export PATH=\"/opt/local/bin:/opt/local/lib/mysql5/bin:/opt/local/lib/postgresql84/bin:/opt/local/apache2/bin:/usr/local/bin:/usr/local/sbin:$PATH\"; pg_dump -Fc -f %s/backup/postgres-custom.dump %s; '" % (information["config.postgresuser"],information['project.dir'],information["project.dbname"]))
			else:
				smllib.shell.CMD("cd /tmp; su postgres -c 'pg_dump -Fc -f %s/backup/postgres-custom.dump %s;'" % (information['project.dir'],information["project.dbname"]))
		elif (backupformat == "plain"):
			smllib.shell.D("Dumping postgres database PLAIN to postgres.sql.gz")
			if (smllib.platform.getPlatform()[0] == "Darwin"):
				smllib.shell.CMD("su - %s -c 'export PATH=\"/opt/local/bin:/opt/local/lib/mysql5/bin:/opt/local/lib/postgresql84/bin:/opt/local/apache2/bin:/usr/local/bin:/usr/local/sbin:$PATH\"; pg_dump -Fp -f %s/backup/postgres.sql %s; rm -f \"%s/backup/postgres.sql.gz\"; gzip --fast \"%s/backup/postgres.sql\"'" % (information["config.postgresuser"],information['project.dir'],information["project.dbname"],information['project.dir'],information['project.dir']))
			else:
				smllib.shell.CMD("su %s -c 'pg_dump -Fp -f %s/backup/postgres.sql %s; rm -f \"%s/backup/postgres.sql.gz\"; gzip --fast \"%s/backup/postgres.sql\"'" % (information["config.postgresuser"],information['project.dir'],information["project.dbname"],information['project.dir'],information['project.dir']))
		else:
			raise "NOT VALID BACKUP FORMAT"

	def doPostTar(self, information):
		"""
			does what this plugin is made for, once per project
		"""
		pass


        def loginTest(self,host,dbname,user,password):
           if (useJava):
             try:
                 con = smllib.smljdbc.getPostgresqlConnection(host,user,password,dbname)
                 con.close()
                 return True
             except:
                 return False
           else:
             DSN = "host="+host+" dbname="+dbname+" user="+user+" password="+password+" host=/var/run/postgresql/"
             try :
                conn = psycopg.connect(DSN)
                conn.close()
                return True
             except psycopg.OperationalError, detail:
                smllib.shell.D("Database connection error: %s" % detail)
                return False



def getPlugin():
	return PostgresBackupPlugin()
