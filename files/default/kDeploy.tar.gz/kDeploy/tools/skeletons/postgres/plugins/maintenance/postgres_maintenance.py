from smllib.maintenanceplugin import MaintenancePlugin

import os
useJava=False
try:
    import psycopg
    #print "using psycopg"
except ImportError:
    try:
      import psycopg2
      #print "using psycopg2"
      psycopg = psycopg2
    except ImportError:
      useJava=True
      import smllib.smljdbc

from smllib.shell import *
import smllib.assertions
from smllib.xmldictionary import XMLDictionary

class PostgresPlugin (MaintenancePlugin):
    def __init__(self):
	pass

    ### begin * MaintenancePlugin implementation ###
    def getAbout(self):
		return "creates user and database (possibly from backup) if needed"

    def getPluginName(self):
	return "postgres plugin"

    def doOnProject(self, information):
	if self.loginTest(information["project.dbserver"],information["project.dbname"],information["project.dbuser"],information["project.dbpass"]):
	    smllib.shell.D("Database setup OK", 3)
	else: ### db setup was not OK
	    if (information["project.dbserver"] != "localhost"):
		message = "Database setup not OK. Please fix this on the remote server."
		smllib.shell.D(message)
		smllib.postman.getThePostman().collect(message)
		smllib.postman.getThePostman().setErrorlevel(2)
	    else: ### db setup will have to be fixed locally
		if not(self.userTest(information["project.dbuser"])):
		    self.createUser(information["project.dbuser"],information["project.dbpass"],information)
		    smllib.postman.getThePostman().setErrorlevel(1)
		if not(self.passwordTest(information["project.dbuser"],information["project.dbpass"])):
		    self.setPass(information["project.dbuser"],information["project.dbpass"],information)
		    smllib.shell.D("I changed the password for database user %s to %s" % (information["project.dbuser"],information["project.dbpass"]))
		    smllib.postman.getThePostman().setErrorlevel(1)
		if not(self.dbTest(information["project.dbname"])):
		    self.createDB(information["project.dbuser"],information["project.dbname"],information)
		    smllib.shell.D("I created a fresh database for project %s" % information["project.name"])
		    smllib.postman.getThePostman().setErrorlevel(1)
                if os.listdir(information["project.dir"]+"/backup").__contains__("postgres.sql.gz") or os.listdir(information["project.dir"]+"/backup").__contains__("postgres.dump"):
                    self.restoreGzippedBackup(information, "postgres.sql.gz")
                    smllib.shell.D("I restored the database for project %s from GZIP ASCII backup" % information["project.name"])
                    smllib.postman.getThePostman().setErrorlevel(1)
                else:
                    if os.listdir(information["project.dir"]+"/backup").__contains__("postgres.sql"):
                        self.restorePlainBackup(information, "postgres.sql")
                        smllib.shell.D("I restored the database for project %s from ASCII backup" % information["project.name"])
                        smllib.postman.getThePostman().setErrorlevel(1)
                    else:
                        if os.listdir(information["project.dir"]+"/backup").__contains__("postgres.dmp"):
                            self.restoreBinaryBackup(information, "postgres.dmp")
                            smllib.shell.D("I restored the database for project %s from BINARY backup" % information["project.name"])
                            smllib.postman.getThePostman().setErrorlevel(1)
                        else:
                            if os.listdir(information["project.dir"]+"/backup").__contains__("postgres-custom.dump"):
                                self.restoreCustomBackup(information, "postgres-custom.dump")
                                smllib.shell.D("I restored the database for project %s from CUSTOM backup" % information["project.name"])
                                smllib.postman.getThePostman().setErrorlevel(1)

    def doPostProjects(self):
	pass

    def doPreProjects(self):
	pass

    def checkPreconditions(self, information):
	if not information['project.dbuser']:
	    smllib.shell.warn("No database configuration found. I will generate a new one...")
	    information.queryUser("project.dbuser", information["project.name"])
	    information.queryUser("project.dbpass", information["project.name"])
	    information.queryUser("project.dbname", information["project.name"])
	    information.queryUser("project.dbserver", "localhost")
	information.require("project.dbuser")
	information.require("project.dbpass")
	information.require("project.dbname")
	information.require("project.dbserver")

    ### end * MaintenancePlugin implementation ###
    def loginTest(self,host,dbname,user,password):
        if (useJava):
          try:
	  	con = smllib.smljdbc.getPostgresqlConnection(host,user,password,dbname)
          	con.close()
		return True
          except:
		return False
        else:
           DSN = "host="+host+" dbname="+dbname+" user="+user+" password="+password+" host=/var/run/postgresql/"
           try :
             conn = psycopg.connect(DSN)
             conn.close()
             return True
           except psycopg.OperationalError, detail:
             smllib.shell.D("Database connection error: %s" % detail)
             return False

    def userTest(self,user):
       sql = "SELECT usename FROM pg_user WHERE usename='%s'" % user
       return self.sqlHasRows(sql)

    def sqlHasRows(self,sql):
       if (useJava):
          con = smllib.smljdbc.getPostgresqlConnection("localhost","smlscript","sml","template1")
          stmt = con.createStatement()
          rs = stmt.executeQuery(sql)
          if (rs.next()):
            b= True
          else:
            b= False
          rs.close()
          stmt.close()
          con.close()
          return b
       else:
          DSN = "dbname=template1 user=smlscript password=sml host=/var/run/postgresql/"
          conn = psycopg.connect(DSN)
          cr = conn.cursor()
          cr.execute(sql)
          conn.commit()
          conn.close()
          if cr.rowcount > 0:
              return True
          else:
              return False


    def passwordTest(self,user,password):
	return self.sqlHasRows("SELECT usename FROM pg_shadow WHERE usename='%s' AND passwd='md5'||md5('%s')" % (user, password + user))


    def dbTest(self,dbname):
	return self.sqlHasRows("SELECT datname FROM pg_database WHERE datname='%s'" % dbname)

    def restoreBinaryBackup(self,information, file):
        if (smllib.platform.getPlatform()[0] == "Darwin"):
	      smllib.shell.CMD("su - %s -c \"export PATH=\"/opt/local/bin:/opt/local/lib/mysql5/bin:/opt/local/lib/postgresql84/bin:/opt/local/apache2/bin:/usr/local/bin:/usr/local/sbin:$PATH\"; pg_restore -Ft %s/backup/%s -d %s\"" % (information["config.postgresuser"], information["project.dir"],file,information["project.dbname"]))
        else:
	      smllib.shell.CMD("su - %s -c \"pg_restore -Ft %s/backup/%s -d %s\"" % (information["config.postgresuser"], information["project.dir"],file,information["project.dbname"]))

    def restoreCustomBackup(self,information, file):
        multithread = ""
        if ("config.psqlrestorefast" in information.keys()):
          smllib.shell.D("-- AGGRESSIVE - disabling triggers during restore!")
          multithread="--single-transaction --disable-triggers"
        if ("config.restorethreads" in information.keys()):
          multithread = "-j %s" % (information["config.restorethreads"])
          if ("config.psqlrestorefast" in information.keys()):
            multithread = multithread + " --disable-triggers"
          smllib.shell.D("-- MULTITHREADED: using %s threads" % information["config.restorethreads"])
        if (smllib.platform.getPlatform()[0] == "Darwin"):
	      smllib.shell.CMD("su - %s -c \"export PATH=\"/opt/local/bin:/opt/local/lib/mysql5/bin:/opt/local/lib/postgresql84/bin:/opt/local/apache2/bin:/usr/local/bin:/usr/local/sbin:$PATH\"; PGOPTIONS='-c maintenance_work_mem=64MB' pg_restore %s -Fc %s/backup/%s -d %s\"" % (information["config.postgresuser"], multithread, information["project.dir"],file,information["project.dbname"]))
        else:
	      smllib.shell.CMD("su - %s -c \"PGOPTIONS='-c maintenance_work_mem=64MB' pg_restore %s -Fc %s/backup/%s -d %s\"" % (information["config.postgresuser"], multithread, information["project.dir"],file,information["project.dbname"]))

    def createUser(self,user,password,information):
	smllib.shell.CMD("su - %s -c \"export PATH=\\\"/opt/local/bin:/opt/local/lib/mysql5/bin:/opt/local/lib/postgresql84/bin:/opt/local/apache2/bin:/usr/local/bin:/usr/local/sbin:$PATH\\\";psql template1 -c \\\"CREATE USER %s\\\"\"" % (information["config.postgresuser"],user))
	smllib.shell.CMD("su - %s -c \"export PATH=\\\"/opt/local/bin:/opt/local/lib/mysql5/bin:/opt/local/lib/postgresql84/bin:/opt/local/apache2/bin:/usr/local/bin:/usr/local/sbin:$PATH\\\";psql template1 -c \\\"ALTER USER %s WITH PASSWORD '%s'\\\"\"" % (information["config.postgresuser"],user,password))

    def setPass(self,user,password,information):
	smllib.shell.CMD("su - %s -c \"export PATH=\\\"/opt/local/bin:/opt/local/lib/mysql5/bin:/opt/local/lib/postgresql84/bin:/opt/local/apache2/bin:/usr/local/bin:/usr/local/sbin:$PATH\\\";psql template1 -c \\\"ALTER USER %s WITH PASSWORD '%s'\\\"\"" % (information["config.postgresuser"],user,password))

    def createDB(self,user,dbname,information):
	smllib.shell.CMD("su - %s -c \"export PATH=\\\"/opt/local/bin:/opt/local/lib/mysql5/bin:/opt/local/lib/postgresql84/bin:/opt/local/apache2/bin:/usr/local/bin:/usr/local/sbin:$PATH\\\";psql template1 -c \\\"CREATE DATABASE %s WITH OWNER %s ENCODING 'UNICODE'\\\" 2>> /tmp/err \"" % (information["config.postgresuser"],dbname,user))

    def restorePlainBackup(self,information, file):
	smllib.shell.CMD("su - %s -c \"export PATH=\\\"/opt/local/bin:/opt/local/lib/mysql5/bin:/opt/local/lib/postgresql84/bin:/opt/local/apache2/bin:/usr/local/bin:/usr/local/sbin:$PATH\\\";psql -f %s/backup/%s -d %s -q\"" % (information["config.postgresuser"],information["project.dir"],file,information["project.dbname"]))

    def restoreGzippedBackup(self,information, file):
	smllib.shell.CMD("su - %s -c \"export PATH=\\\"/opt/local/bin:/opt/local/lib/mysql5/bin:/opt/local/lib/postgresql84/bin:/opt/local/apache2/bin:/usr/local/bin:/usr/local/sbin:$PATH\\\";gunzip -c %s/backup/%s | psql -d %s -q\"" % (information["config.postgresuser"],information["project.dir"],file,information["project.dbname"]))

def getPlugin():
    return PostgresPlugin()

