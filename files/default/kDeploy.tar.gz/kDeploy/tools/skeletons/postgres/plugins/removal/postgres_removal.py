from smllib.removalplugin import RemovalPlugin
import smllib.shell
import _mysql_exceptions

class PostgresRemovalPlugin (RemovalPlugin):
	def __init__(self):
		pass
        
	def getAbout(self):
		"""
			returns a string containing the reason for this plugins existance
		"""
		return "base removal plugin"

        def dropUser(self,user):
            smllib.shell.CMD("su - postgres -c 'psql -c \"DROP USER %s\"'" % user)

        def dropDatabase(self,database):
            smllib.shell.CMD("su - postgres -c 'psql -c \"DROP DATABASE %s\"'" % database)
            	    	
	def getPluginName(self):
		"""
			returns the name of this plugin (string)
		"""
		return "base removal plugin"
	    			
	def doPreRemove(self, information):
		"""
			does what this plugin is made for, once per project
		"""
		smllib.shell.D("Testing pre plugin for project %s" % (information['project.name']))

	def doPostRemove(self, information):
		"""
			does what this plugin is made for, once per project
		"""
		smllib.shell.D("removing postgres database")
		self.dropDatabase(information["project.dbname"])
		self.dropUser(information["project.dbuser"])

		
def getPlugin():
    return PostgresRemovalPlugin()
