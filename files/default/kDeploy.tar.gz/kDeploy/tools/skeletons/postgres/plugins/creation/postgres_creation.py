from smllib.creationplugin import CreationPlugin
import smllib.shell
from smllib.xmldictionary import XMLDictionary

class PostgresCreationPlugin (CreationPlugin):
	def __init__(self):
		pass
		
	def getAbout(self):
		"""
			returns a string containing the reason for this plugins existance
		"""
		return "postgres skel /backup"
	    	
	def getPluginName(self):
		"""
			returns the name of this plugin (string)
		"""
		return "postgres creator"
	    			
	def performAction(self, information):
		"""
			does what this plugin is made for, once per project
		"""
		
		permdict = XMLDictionary("%s/conf/permissions.xml" % information["project.dir"])
		permdict.toSave=[""]
		permdict["/backup"] = ["-R -m user:postgres:rwX"]
		permdict.save()
	    			
def getPlugin():
    return PostgresCreationPlugin()