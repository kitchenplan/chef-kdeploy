from smllib.maintenanceplugin import MaintenancePlugin
import smllib.shell
import smllib.skeleton
import smllib.platform
from smllib.pingdom import Pingdom
from pprint import pprint
from urllib2 import HTTPError

class PingdomMaintenancePlugin (MaintenancePlugin):
    def __init__(self):
        globalConfig = smllib.projectinformation.getBaseInformation()

    def getAbout(self):
        return "checks and creates the pingdom monitoring check"

    def getPluginName(self):
        return "pingdom maintainer"

    def checkPreconditions(self, information):
        """
            runs before the plugin is really executed
            the plugin will only have effect if the project passes this test
        """

    def doPreProjects(self):
        """
            does dome pre processing before the doOnProject
            happens only once (not once per project!)
        """

    def doOnProject(self, information):
        globalConfig = smllib.projectinformation.getBaseInformation()
        if globalConfig['config.develmode'] != 'true' and globalConfig['config.monitor'] != 'false':
            p = Pingdom(username="support@kunstmaan.be", password="xhJp3xBDE2kech", appkey='2t5elfd6x3u6hj3n9g1j99hnvt8pxkln')
            checkswithname = p.check_by_name(information['project.name'])
            if information['project.monitor'] != 'false':
                nagiosuri = "/"
                if information['project.nagiosuri']:
                    nagiosuri = information['project.nagiosuri']
                if not checkswithname:
                    result = p.method(url='checks', method="POST", parameters={'name': information['project.name'],
                                                                               'host': information['project.url'],
                                                                               'type': 'http',
                                                                               'url': nagiosuri,
                                                                               'sendtoemail': "true",
                                                                               'sendtoiphone': "true",
                                                                               'sendtoandroid': "true",
                                                                               'contactids': "249053,426046"
                                                                               })
                else:
                    id = checkswithname[0]['id']
                    result = p.method(url=('checks/%s' % id), method="PUT", parameters={'host': information['project.url'],
                                                                                        'url': nagiosuri,
                                                                                        'sendtoemail': "true",
                                                                                        'sendtoiphone': "true",
                                                                                        'sendtoandroid': "true",
                                                                                        'contactids': "249053,426046"
                                                                                        })
            else:
                if checkswithname:
                    id = checkswithname[0]['id']
                    result = p.method(url=('checks/%s' % id), method="DELETE")


    def doPostProjects(self):
        """
            does dome post processing after the doOnProject
            happens only once (not once per project!)
        """

def getPlugin():
    return PingdomMaintenancePlugin()
