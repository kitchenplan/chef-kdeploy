from smllib.removalplugin import RemovalPlugin
import smllib.shell
import smllib.skeleton
import smllib.platform
from smllib.pingdom import Pingdom
from pprint import pprint
from urllib2 import HTTPError


class PingdomRemovalPlugin (RemovalPlugin):
    def __init__(self):
        pass

    def getAbout(self):
        """
            returns a string containing the reason for this plugins existance
        """
        return "pingdom removal plugin"

    def getPluginName(self):
        """
            returns the name of this plugin (string)
        """
        return "pingdom removal plugin"

    def doPreRemove(self, information):
        """
            does what this plugin is made for, once per project
        """

    def doPostRemove(self, information):
        """
            does what this plugin is made for, once per project
        """
        p = Pingdom(username="support@kunstmaan.be", password="xhJp3xBDE2kech", appkey='2t5elfd6x3u6hj3n9g1j99hnvt8pxkln')
        checkswithname = p.check_by_name(information['project.name'])
        if checkswithname:
            id = checkswithname[0]['id']
            result = p.method(url=('checks/%s' % id), method="DELETE")


def getPlugin():
    return PingdomRemovalPlugin()
