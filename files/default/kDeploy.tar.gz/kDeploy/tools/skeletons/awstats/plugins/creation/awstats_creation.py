from smllib.creationplugin import CreationPlugin
import smllib.shell
from smllib.information import Information
import os

class AwstatsCreationPlugin (CreationPlugin):
	def __init__(self):
            #load the skeletonconfiguration
	    self.skelinfo = Information(None)
	    self.skelinfo.bindXML(smllib.projectinformation.getBaseInformation()['config.skeletonsdir'] + "/awstats/config.xml")
		
	def getAbout(self):
		"""
			returns a string containing the reason for this plugins existance
		"""
		return "makes awstats available for the project"

	def getPluginName(self):
		"""
			returns the name of this plugin (string)
		"""
		return "awstats init"
		
	def performAction(self, information):
		"""
			does what this plugin is made for, once per project
			
			puts the awstats update script in the fcrontab of this project
			makes sure the DirData exists (see awstats.conf)
			secures the statsdir with htaccess/htpasswd			
		"""
        	smllib.shell.D("Downloading awstats from http://prdownloads.sourceforge.net/awstats/awstats-%s.tar.gz" % self.skelinfo['awstats.version'], 2)
         	smllib.shell.CMD("wget -P /tmp http://prdownloads.sourceforge.net/awstats/awstats-%s.tar.gz" % self.skelinfo['awstats.version'])
		import tarfile
        	smllib.shell.D("Untarring awstats version %s in %s/stats/ (this may take a while)" % (self.skelinfo['awstats.version'], information['project.dir']), 2)
         	if not os.access("/tmp/awstats-%s.tar.gz" % (self.skelinfo['awstats.version']), os.F_OK):
        	    smllib.shell.showerror("no awstats version %s archive found" % self.skelinfo['awstats.version'])
                awstatstar = tarfile.open("/tmp/awstats-%s.tar.gz" % (self.skelinfo['awstats.version']), 'r:gz')
                for file in awstatstar.getmembers():
                    awstatstar.extract(file, path=information['project.dir'] + "/stats")
    		
                #to avoid unnecessary deployments we remove the webapps we don't need
                smllib.shell.D("Cleaning up awstats dir", 2)
                awstatsdir = ''
                for membername in awstatstar.getmembers():
                    if membername.name.find('wwwroot') > -1:
                        awstatsdir = membername.name # now awstatsdir should be something like 'awstats-6.4/wwwroot/'
                        break
                
                smllib.shell.CMD("rsync -a --cvs-exclude --exclude 'awstats.conf' %s/stats/%s/* %s/stats/" % (information['project.dir'], awstatsdir, information['project.dir']))
                #smllib.shell.CMD("cp -r %s/stats/%s/* %s/stats/" % (information['project.dir'], awstatsdir, information['project.dir']))
#                smllib.shell.CMD("cp -r %s/stats/cgi-bin/* %s/stats/" % (information['project.dir'], information['project.dir']))
                smllib.shell.CMD("rm -Rf %s/stats/%s" % (information['project.dir'], awstatsdir.rstrip("wwwroot/")))
#                smllib.shell.CMD("rm -Rf %s/stats/cgi-bin" % information['project.dir'])
		
                #the the url to reach the statistics. (they can always be reached through [project.url]/stats as well)
		if not information['tmp.reapply'] == "yes":
			information.queryUser("project.statsurl", "stats." + information['project.url'])
		
		#ensure the DirData for the statsdatabase exists
		smllib.shell.CMD("mkdir -p %s/stats/data" % information['project.dir'])
			
def getPlugin():
    return AwstatsCreationPlugin()

