from smllib.maintenanceplugin import MaintenancePlugin
from os import path, access, W_OK
import smllib.shell

class AwstatsMaintenancePlugin (MaintenancePlugin):
    def __init__(self):
        pass

    def getAbout(self):
        """
            returns a string containing the reason for this plugins existance
        """
        return "generates a fresh apache2 include"

    def getPluginName(self):
        """
            returns the name of this plugin (string)
        """
        return "awstats maintainer"

    def checkPreconditions(self, information):
        """
            runs before the plugin is really executed
            the plugin will only have effect if it passes this test
        """
        if not information['project.statsurl'] or information['pojects.statsurl'] == "stats.":
            information.queryUser("project.statsurl", "stats." + information['project.url'])

    def doPreProjects(self):
        """
            does dome pre processing before the doOnProject
            happens only once (not once per project!)
        """
        pass

    def doOnProject(self, information):
        """
            actually does what this plugin is made for, once per project

            update the project's awstats database
        """
        smllib.shell.D("Populating hostaliases file", 3)
        hostaliasesfile = open("%s/stats/hostaliases" % information['project.dir'], 'w')
        if (information['project.aliases']):
            hostaliasesfile.writelines([alias+"\n" for alias in information['project.aliases']])
        hostaliasesfile.close()

        smllib.shell.D("Making sure the passwd file has a user for our statistics.", 3)
        if path.exists("%s/stats/.htpasswd"%information['project.dir']) and path.isfile("%s/stats/.htpasswd"%information['project.dir']) and access("%s/stats/.htpasswd"%information['project.dir'], W_OK):
            smllib.shell.D("File exists, updating", 4)
            smllib.shell.CMD("htpasswd -b %s/stats/.htpasswd kunstmaan davnvvawstats" % information['project.dir'])
        else:
            smllib.shell.D("File does not extist, creating", 4)
            smllib.shell.CMD("htpasswd -cb %s/stats/.htpasswd kunstmaan davnvvawstats" % information['project.dir'])

    def doPostProjects(self):
        """
            does dome post processing after the doOnProject
            happens only once (not once per project!)

            runs the update script for the stats as project.user
        """
        pass

def getPlugin():
    return AwstatsMaintenancePlugin()
