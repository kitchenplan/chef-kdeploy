from smllib.creationplugin import CreationPlugin
import smllib.shell

class LogrotateCreationPlugin (CreationPlugin):
	def __init__(self):
		pass
		
	def getAbout(self):
		"""
			returns a string containing the reason for this plugins existance
		"""
		return "Creates a logrotate configuration file for this project's apache logs"
		
	def getPluginName(self):
		"""
			returns the name of this plugin (string)
		"""
		return "logrotate init"
		
	def performAction(self, information):
		"""
			create a default logrotate configuration file
		"""
		pass
		
def getPlugin():
    return LogrotateCreationPlugin()