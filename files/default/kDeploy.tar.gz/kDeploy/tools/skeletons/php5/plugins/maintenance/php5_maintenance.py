from smllib.maintenanceplugin import MaintenancePlugin
import smllib.shell
import smllib.skeleton
import smllib.platform

class PHP5MaintenancePlugin (MaintenancePlugin):
	def __init__(self):
		globalConfig = smllib.projectinformation.getBaseInformation()	
	
	### begin * MaintenancePlugin implementation ###
	def getAbout(self):
		"""
			returns a string containing the reason for this plugins existance
		"""
		return "symlinks the php5-fpm config files"
	
	def getPluginName(self):
		"""
			returns the name of this plugin (string)
		"""
		return "php5 maintainer"
	
	def checkPreconditions(self, information):
		"""
			runs before the plugin is really executed
			the plugin will only have effect if the project passes this test
			
			checks for a valid IP, url and statsurl in the config file
			asks for one if none is found
		"""
	
	def doPreProjects(self):
		"""
			does dome pre processing before the doOnProject
			happens only once (not once per project!)
			
			removes all previously generated apache config files
		"""
		smllib.shell.D("Clearing all previous php5-fpm configurations", 2)
		smllib.shell.CMD("rm -Rf /etc/php5/fpm/pool.d/*")
	
	def doOnProject(self, information):
		"""
			generates a partial apache.conf file for this project to be
			included in the general apache config fo the server
		"""
		smllib.shell.CMD("ln -sf %s/conf/php5-fpm.conf /etc/php5/fpm/pool.d/%s.conf" % (information['project.dir'],information['project.name']))
		globalConfig = smllib.projectinformation.getBaseInformation()
		# Create the current symlink if this is a developer machine.
		if globalConfig['config.develmode'] == 'true':
			smllib.shell.D("Creating the current symlink", 3)
			smllib.shell.CMD("rm %s/data/current" % (information['project.dir']))
			smllib.shell.CMD("ln -sf %s/data/%s/ %s/data/current" % (information['project.dir'],information['project.name'],information['project.dir']))

		
	def doPostProjects(self):
		"""
			does dome post processing after the doOnProject
			happens only once (not once per project!)
		"""


def getPlugin():
	return PHP5MaintenancePlugin()