from smllib.creationplugin import CreationPlugin
import smllib.shell
from smllib.xmldictionary import XMLDictionary

class PHP5CreationPlugin (CreationPlugin):
	def __init__(self):
		pass
		
	def getAbout(self):
		"""
			returns a string containing the reason for this plugins existance
		"""
		return "php5 skel"
	    	
	def getPluginName(self):
		"""
			returns the name of this plugin (string)
		"""
		return "php5 creator"
	    			
	def performAction(self, information):
		"""
			does what this plugin is made for, once per project
		"""
		ownershipdict = XMLDictionary("%s/conf/ownership.xml" % information["project.dir"])
		ownershipdict.toSave=[""]
		ownershipdict["/data"] = "-R @project.user@.@project.group@"
		ownershipdict["/php5-fpm"] = "-R @project.user@.@project.group@"
		ownershipdict["/tmp"] = "-R @project.user@.@project.group@"
		ownershipdict.save()
		
		permdict = XMLDictionary("%s/conf/permissions.xml" % information["project.dir"])
		permdict.toSave=[""]
		permdict["/data"] = ["-R -m user::rwx", "-R -m group::r-x", "-R -m other::---", "-R -m u:@config.wwwuser@:r-x"]	
		permdict["/data/current"] = ["-m user::rwx", "-R -m group::rwx", "-R -m other::rwX", "-R -m u:@config.wwwuser@:rwx"]		
		permdict["/php5-fpm"] = ["-R -m user::rwx", "-R -m group::r-x", "-R -m other::r-x"]
		permdict["/tmp"] = ["-R -m user::rwx", "-R -m group::r-x", "-R -m other::r-x"]
		permdict.save()
		
		smllib.shell.CMD("mkdir -p %s/data/%s" % (information['project.dir'] ,information['project.name']))

		pass


def getPlugin():
    return PHP5CreationPlugin()
