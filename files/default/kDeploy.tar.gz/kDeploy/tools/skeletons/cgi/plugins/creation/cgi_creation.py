from smllib.creationplugin import CreationPlugin
import smllib.shell
from smllib.xmldictionary import XMLDictionary

class CgiCreationPlugin (CreationPlugin):
	def __init__(self):
		pass
		
	def getAbout(self):
		"""
			returns a string containing the reason for this plugins existance
		"""
		return "cgi skel"
	    	
	def getPluginName(self):
		"""
			returns the name of this plugin (string)
		"""
		return "cgi creator"
	    			
	def performAction(self, information):
		"""
			does what this plugin is made for, once per project
		"""
		ownershipdict = XMLDictionary("%s/conf/ownership.xml" % information["project.dir"])
		ownershipdict.toSave=[""]
		ownershipdict["/cgi-bin"] = "-R @project.user@.@project.group@"
		ownershipdict.save()
		
		permdict = XMLDictionary("%s/conf/permissions.xml" % information["project.dir"])
		permdict.toSave=[""]
		permdict["/cgi-bin"] = ["-R -m user::rwx", "-R -m group::r-x", "-R -m other::r-x"]
		permdict.save()
		
		pass


def getPlugin():
    return CgiCreationPlugin()