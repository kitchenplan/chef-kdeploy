from smllib.maintenanceplugin import MaintenancePlugin
import smllib.shell
import os
import re
from datetime import datetime, timedelta
import smllib.skeleton
import smllib.platform
ips = []


class ApacheMaintenancePlugin (MaintenancePlugin):
    def __init__(self):
        globalConfig = smllib.projectinformation.getBaseInformation()   
        if (globalConfig['config.apacheconfpath']):
            self.apacheconfpath = globalConfig['config.apacheconfpath']
        else:
            self.apacheconfpath = "/etc/apache2/conf/projects.d/"
        # to store the used ip addresses (for NameVirtualHosts)
        self.usedips = []
        # clearing the iplist
        #[ips.remove(x) for x in ips]

        ipaddr = "*\n"

        # we collect the machine's IP addresses at init
        #if (globalConfig['config.options'] and ("localhost-only" in globalConfig['config.options'])):
            # ipaddr = "127.0.0.1\n"
        #    ipaddr = "*\n"
        #else:
        #    ipaddr = smllib.shell.CMDGET("ifconfig  | grep 'inet '  | awk '{sub(/addr:/, \"\", $2); print $2}' | grep -v '127.0.0.1'")
        #    ipaddr = ipaddr + "\n"
        #    if (globalConfig['config.fixedip'] and (globalConfig['config.fixedip'] in ipaddr)):
        #        ipaddr = globalConfig['config.fixedip'] + "\n"
            
        # ipaddr now contains all IP's with global scope assigned to this machine they are separated by \n and end with an empty line
        [ips.append(x) for x in ipaddr.split("\n")[0:-1]]
        self.hostfile_entries={}
    
    ### begin * MaintenancePlugin implementation ###
    def getAbout(self):
        """
            returns a string containing the reason for this plugins existance
        """
        return "generates virtual hosts apache configs"
    
    def getPluginName(self):
        """
            returns the name of this plugin (string)
        """
        return "apache maintainer"
    
    def checkPreconditions(self, information):
        """
            runs before the plugin is really executed
            the plugin will only have effect if the project passes this test
            
            checks for a valid IP, url and statsurl in the config file
            asks for one if none is found
        """
        while information['project.ip'] not in ips:
            if(ips and len(ips) == 1):
                information['project.ip'] = ips[0]
            else:
                smllib.shell.warn("No or no valid IP (" + str(information['project.ip']) + ") found, please choose one of the following: " + ", ".join(ips))
                information.queryUser("project.ip", ips[0])
        if not information['project.url']:
            information.queryUser("project.url")
    
    def doPreProjects(self):
        """
            does dome pre processing before the doOnProject
            happens only once (not once per project!)
            
            removes all previously generated apache config files
        """
        #start with a cleane lei ;-)
        smllib.shell.D("Clearing all previous virtual host configurations", 2)
        smllib.shell.CMD("rm -Rf %s*" % self.apacheconfpath)
        #create projects.xml
        globalConfig = smllib.projectinformation.getBaseInformation()
        if globalConfig['config.devel'] == 'false':
            if not globalConfig['config.hostingdir']:
                smllib.shell.D('Could not find config.hostingdir entry in global config.xml file :-(')
            else:
                deployments = globalConfig['config.hostingdir'] + "projects.xml"
                deploymentsfile = open(deployments, 'w')
                deploymentsfile.write("<projects>\n")
                deploymentsfile.close()
    
    def doOnProject(self, information):
        """
            generates a partial apache.conf file for this project to be
            included in the general apache config fo the server
        """
        
        globalConfig = smllib.projectinformation.getBaseInformation()
        
        smllib.shell.D("(Re-)generating project's virtual host configuration", 3)
        
        if not globalConfig['config.hostmachine']:
            smllib.shell.showerror('Could not find config.hostmachine entry in global config.xml file :-(')
        
        hostmachine = globalConfig['config.hostmachine']
        
        aliasconffile = open(information['project.dir'] + "/conf/apache.d/05aliases", 'w')
        aliasconffile.write("ServerAlias ")
        aliasconffile.write(information['project.name']+"."+hostmachine)
        aliasconffile.write(" www." + information['project.name']+"."+hostmachine)
        if (information['project.aliases']):
            aliasconffile.writelines([" "+alias for alias in information['project.aliases']])
            
        if (information['project.subroots']):
            aliasconffile.writelines([" "+alias+"."+information['project.name']+"."+hostmachine for alias in information['project.subroots']])          
            aliasconffile.writelines([" www."+alias+"."+information['project.name']+"."+hostmachine for alias in information['project.subroots']])          
            
        aliasconffile.write("\n")
        aliasconffile.close()
        
        #where to store the configfile we're about to generate
        apacheconffile = open(self.apacheconfpath + information['project.name'] + ".conf", 'w')
        
        #get the configtemplates
        templates = os.listdir(information['project.dir'] + "/conf/apache.d/")
        if templates.__contains__("CVS"):
            templates.remove("CVS")
        #we have to process them in order!
        templates.sort()
        
        #the template contains some @key@ entries, we want them replaced with useful information
        replacer = information.getReplacer()
        for template in templates:
            if (template.endswith("~")):
                continue
            if (template.startswith(".")):
                continue                
            if (template.endswith(".swp")):
                continue
            if (template.endswith(".bak")):
                continue
            if (template.endswith("-")):
                continue
            apacheconffile.write("\n#BEGIN %s\n" % template)
            configtemp = open(information['project.dir'] + "/conf/apache.d/" + template)
            for line in configtemp:
                newline = replacer.replace(line)
                if ("config.develmode" in information.keys() and information["config.develmode"] == "true"):
                    newline = newline.replace("-Indexes", "Indexes")
                apacheconffile.write(newline)
            configtemp.close()
            apacheconffile.write("\n# END  %s\n\n" % template)
            if not self.usedips.__contains__(information['project.ip']):
                self.usedips.append(information['project.ip'])
        
        apacheconffile.close()
        
        smllib.shell.D("Creating all the needed host entries", 3)
        projecthost = information['project.name']+"."+hostmachine
        self.addHostEntry(information['project.ip'],projecthost)
        self.addHostEntry(information['project.ip']," www." + projecthost)
        if (information['project.subroots']):
            for alias in information['project.subroots']:
                self.addHostEntry(information['project.ip'],alias+"."+information['project.name']+"."+hostmachine)
                self.addHostEntry(information['project.ip'],"www."+alias+"."+information['project.name']+"."+hostmachine)

        # add the user to the www-data group, fixes a whole lot of permission issues.
        #if (smllib.platform.getPlatform()[0] == "Darwin"):
        #    smllib.shell.CMD("dscl . append /Groups/_www GroupMembership %s" % information['project.name'])
        #else:
        #    smllib.shell.CMD("adduser %s www-data" % information['project.name'])

    
    def addHostEntry(self,ip,hostname):
        x = []
        if (ip in self.hostfile_entries):
            x = self.hostfile_entries[ip]
        if (not (hostname in x)):
            x.append(hostname)
        self.hostfile_entries[ip] = x
    
    def writeHostFile(self):
        lines = []
        f = file("/etc/hosts","r")
        line = f.readline()
        while (line):
            lines.append(line[:-1])
            line = f.readline()
        f.close()
        resultlines = []
        found_section = False
        in_section = False
        for l in lines:
            if (not in_section):
                if (l.startswith("#KDEPLOY_start")):
                    in_section = True
                    found_section = True
                    resultlines.append(l)
                    resultlines = resultlines + self.getHostLines()
                else:
                    resultlines.append(l)
            else:
                if (l.startswith("#KDEPLOY_end")):
                    in_section = False
                    resultlines.append(l)
        if (not found_section):
            resultlines.append("#KDEPLOY_start autogenerated section. do not edit below this line. do not remove this line.")
            resultlines = resultlines + self.getHostLines()
            resultlines.append("#KDEPLOY_end autogenerated section. do not edit above this line. do not remove this line.")
        f = file("/etc/hosts","w")
        for l in resultlines:
            f.write("%s\n" % l)
        f.close()
                
    
    def getHostLines(self):
        result = []
        for k in self.hostfile_entries.keys():
            vals = self.hostfile_entries[k]
            for v in vals:
                if (k == "*"):
                    line = "127.0.0.1" + "\t"
                else:
                    line = k + "\t"
                line = line + v + " "
                line = line[:-1]
                result.append(line)
        return result
    
    def doPostProjects(self):
        """
            does dome post processing after the doOnProject
            happens only once (not once per project!)
        """
        smllib.shell.D("Creating a new namevirtualhosts file", 2)
        globalConfig = smllib.projectinformation.getBaseInformation()
        apacheport = globalConfig['config.apacheport']
        if not globalConfig['config.apacheport']:
            smllib.shell.D('Could not find config.apacheport entry in global config.xml file :-(. defaulting to 80')
            apacheport = 80         
        apacheconffile = open(self.apacheconfpath + "namevirtualhosts", 'w')
        for ip in self.usedips:
            apacheconffile.write("NameVirtualHost %s:%s\n" % (ip, apacheport))
            apacheconffile.write("NameVirtualHost %s:443\n" % (ip))
        apacheconffile.close()
        smllib.shell.D("You will have to restart apache2 to apply these changes!", 2)
        if (globalConfig["config.options"] and ("apache-no-default-vhost" in globalConfig["config.options"])):
            return
        smllib.shell.D("Creating a default vhost for every ip", 2)
        apacheconffile = open(self.apacheconfpath + "000firsthost.conf", 'w')
        for ip in self.usedips:
            apacheconffile.write("<VirtualHost %s:%s>\n" % (ip, globalConfig['config.apacheport']))
            apacheconffile.write("ServerName no_website_configured_at_this_address\n")
            apacheconffile.write("ServerAdmin support@kunstmaan.be\n")
            apacheconffile.write("DocumentRoot /opt/nowebsite/\n")
            apacheconffile.write("<Directory /opt/nowebsite >\n")
            apacheconffile.write("   Options None\n")
            apacheconffile.write("   Order allow,deny\n")
            apacheconffile.write("   Allow from all\n")
            apacheconffile.write("</Directory>\n")
            apacheconffile.write("LogFormat \"%h %l %u %t \\\"%r\\\" %>s %b \\\"%{Referer}i\\\" \\\"%{User-Agent}i\\\" %A \\\"%{Host}i\\\" \\\"%q\\\"  \" nositelog\n")
            apacheconffile.write("ErrorLog /dev/null\n")
            apacheconffile.write("CustomLog /var/log/nowebsite.log nositelog\n")
            apacheconffile.write("</VirtualHost>\n")
        apacheconffile.close()
        if globalConfig['config.localhost'] == "true" or (globalConfig['config.options'] and ("auto-hosts-file" in globalConfig['config.options'])):
            smllib.shell.D("writing /etc/hosts",2)
            self.writeHostFile()
        
        if globalConfig['config.devel']== "false" :
            smllib.shell.D("Closing projects.xml", 2)
            if not globalConfig['config.hostingdir']:
                smllib.shell.D('Could not find config.hostingdir entry in global config.xml file :-(')
            else:
                deployments = globalConfig['config.hostingdir'] + "projects.xml"
                deploymentsfile = open(deployments, 'a')
                deploymentsfile.write("</projects>")
                deploymentsfile.close()
    
    ### end * MaintenancePlugin implementation ###

def getPlugin():
    return ApacheMaintenancePlugin()
