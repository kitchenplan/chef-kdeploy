from smllib.creationplugin import CreationPlugin
import smllib.shell

class ApacheCreationPlugin (CreationPlugin):

	def __init__(self):
		CreationPlugin.__init__(self)
		globalConfig = smllib.projectinformation.getBaseInformation()	
		if (globalConfig['config.apacheconfpath']):
			self.apacheconfpath = globalConfig['config.apacheconfpath']
		else:
			self.apacheconfpath = "/etc/apache2/conf/projects.d/"		
		smllib.shell.CMD("mkdir -p %s" % self.apacheconfpath)
		self.ips = []
		[self.ips.remove(x) for x in self.ips]	    
		if (globalConfig['config.options'] and ("localhost-only" in globalConfig['config.options'])):
			ipaddr = "127.0.0.1\n"
		else:
			ipaddr = smllib.shell.CMDGET("ifconfig  | grep 'inet '  | awk '{sub(/addr:/, \"\", $2); print $2}'")
			if (globalConfig['config.fixedip'] and (globalConfig['config.fixedip'] in ipaddr)):
				ipaddr = globalConfig['config.fixedip'] + "\n"
		self.ips = ipaddr.splitlines()
	    	
	def getPluginName(self):
	    return "apache init"
	    
	def getAbout(self):
	    return "fetches some basic information about the apache config for the project"
	
	def performAction(self, information):
		#ensure our project's virtual host configuration files have a place to stay
		smllib.shell.CMD("mkdir -p /etc/apache2/conf/projects.d/")
		
		#fetch the required information from the user
		smllib.shell.D("Found following IPs on this machine: " + ", ".join(self.ips), 2)
		information.queryUser("project.ip", self.ips[0])
		while not information['project.ip'] in self.ips:
	    		information.queryUser("project.ip", self.ips[0])
	    	information.queryUser("project.url")
		information.queryArrayUser("project.aliases")
		
def getPlugin():
    return ApacheCreationPlugin()