# this script assumes projects are located in /home/projects/project.name !!

import sys
sys.path.append('/usr/lib/python%s/site-packages/oldxml' % sys.version[:3])


from smllib.query import query
from smllib.information import Information
from smllib.shell import *
from smllib.skeleton import SkeletonCopier
import smllib.projectinformation
import smllib.postman
import smllib.aspn
import os

smllib.aspn.lock()


def unique(s):
     """
	     (From the Python Cookbook)
	     
	     Return a list of the elements in s, but without duplicates.
	
	     For example, unique([1,2,3,1,2,3]) is some permutation of [1,2,3],
	     unique("abcabc") some permutation of ["a", "b", "c"], and
	     unique(([1, 2], [2, 3], [1, 2])) some permutation of
	     [[2, 3], [1, 2]].
	
	     For best speed, all sequence elements should be hashable.  Then
	     unique() will usually work in linear time.
	
	     If not possible, the sequence elements should enjoy a total
	     ordering, and if list(s).sort() doesn't raise TypeError it's
	     assumed that they do enjoy a total ordering.  Then unique() will
	     usually work in O(N*log2(N)) time.
	
	     If that's not possible either, the sequence elements must support
	     equality-testing.  Then unique() will usually work in quadratic
	     time.
     """

     n = len(s)
     if n == 0:
         return []

     # Try using a dict first, as that's the fastest and will usually
     # work.  If it doesn't work, it will usually fail quickly, so it
     # usually doesn't cost much to *try* it.  It requires that all the
     # sequence elements be hashable, and support equality comparison.
     u = {}
     try:
         for x in s:
             u[x] = 1
     except TypeError:
         del u  # move on to the next method
     else:
         return u.keys()

     # We can't hash all the elements.  Second fastest is to sort,
     # which brings the equal elements together; then duplicates are
     # easy to weed out in a single pass.
     # NOTE:  Python's list.sort() was designed to be efficient in the
     # presence of many duplicate elements.  This isn't true of all
     # sort functions in all languages or libraries, so this approach
     # is more effective in Python than it may be elsewhere.
     try:
         t = list(s)
         t.sort()
     except TypeError:
         del t  # move on to the next method
     else:
         assert n > 0
         last = t[0]
         lasti = i = 1
         while i < n:
             if t[i] != last:
                 t[lasti] = last = t[i]
                 lasti += 1
             i += 1
         return t[:lasti]

     # Brute force is all that's left.
     u = []
     for x in s:
         if x not in u:
             u.append(x)
     return u

#generate a list of known projects and skeletons from the corresponding locations on the
#filesystem as configured in the global config.xml
globalConfig = smllib.projectinformation.getBaseInformation()
projects = os.listdir(globalConfig['config.projectsdir'])
skeletons = os.listdir(globalConfig['config.skeletonsdir'])
#skeletons.remove("CVS")
skeletonName = ''
p = Information(None)
p.mergeWith(globalConfig)

#if the commandline is nog python applyskel.py projectname skeleton
if (len(sys.argv) < 3):
    #ask on which project we want to apply a skeleton
    #keep on asking until a valid project name is given
    #load the projects configuration
    D("Which project do you want to apply a skeleton to?", 0)
    p.queryUser("project.name")
    while not projects.__contains__(p['project.name']):
        warn("Could not find project %s" % p['project.name'])
        p.queryUser("project.name")
    p.bindXML("%s/%s/conf/config.xml" % (globalConfig['config.projectsdir'], p['project.name']))
    
    #ask which project we want to apply on the given project
    #keep on asking until a valid skeleton name is provided
    D("Which skeleton do you want to apply to project %s?" % p['project.name'], 0)
    p.queryUser("tmp.skeleton")
    skeletonName = p["tmp.skeleton"]
    while not skeletons.__contains__(p['tmp.skeleton']):
        warn("Could not find skeleton %s" % p['tmp.skeleton'])
        p.queryUser("tmp.skeleton")
        skeletonName = p["tmp.skeleton"]

else:
    p['project.name'] = sys.argv[1]
    p.bindXML("%s/%s/conf/config.xml" % (globalConfig['config.projectsdir'], p['project.name']))
    p["tmp.skeleton"] = sys.argv[2]
    skeletonName = p["tmp.skeleton"]

#function to apply a skeleton given by its name on a project given by its Information
#the third argument is a list of dependencies that are scheduled already
#recursively callable to resolve skeletondependencies
def applyskel(skeletonName, projectinfo, deplist=[]):
	#maybe this skeleton was already applied on this project before.
	#in that case ask the user what to do
	yesno = 'y'
	reapply = "no"
	if skeletonName in projectinfo['project.skeletons']:
	    warn ("skeleton %s was already applied to project %s" % (skeletonName, projectinfo['project.name']))
	#    yesno = ask("Do you want to apply it again (this is an unsupported feature, use at your own risk)? [Y/n]")
        #if yesno == 'n':
        #    raise "okay then"
        #else:
        reapply = "yes"


	#ok, the user really wants the skeleton applied on the project. let's do it
	if not skeletonName in deplist:
		deplist.append(skeletonName)
		#check if skeleton dependencies are met
		action("checking dependencies of " + skeletonName)
		skeletonconf = Information('skeletonconfig')
		skeletonconf.bindXML("%s/%s/config.xml" % (globalConfig['config.skeletonsdir'], skeletonName))
		for dep in skeletonconf['skeleton.deps']:
		    if not dep in projectinfo['project.skeletons'] and not dep in deplist:
			warn("skeleton %s depends on %s" % (skeletonName, dep))
			yesno = ask("You should apply %s on %s first. Do it now? [Y/n]" % (dep, projectinfo['project.name']))
			if not yesno == 'n':
			    applyskel(dep, projectinfo, deplist)
		actionok()

		#copy skeleton into place and invoke all its creationplugins on the project
		action("applying " + skeletonName + " to " + projectinfo['project.name'])
		projectinfo['tmp.reapply'] = reapply
		skc = SkeletonCopier(skeletonName, projectinfo["config.skeletonsdir"]+"/" + skeletonName, globalConfig['config.projectsdir'] + projectinfo["project.name"])
		skc.performAction(projectinfo)
		actionok()

		projectinfo['project.skeletons'] = unique(projectinfo['project.skeletons'])
		projectinfo.save()

applyskel(skeletonName, p)

smllib.shell.action("sending log to admin")
smllib.postman.getThePostman().send("Skeleton Application: %s on %s" % (skeletonName, p['project.name']))
smllib.shell.actionok()
smllib.aspn.unlock()
