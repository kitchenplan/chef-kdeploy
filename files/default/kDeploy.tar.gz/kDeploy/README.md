# Introducing [kDeploy][kdeploy]

[kDeploy][kdeploy] is the hosting platform used at [Kunstmaan][kunstmaan] to reliably host, deploy, backup and develop our projects. There are no restrictions on what type of projects are hosted and we are using it to host projects based on Java in a Tomcat container, Play! with the builtin container, PHP using mod_apache and PHP-FPM and a Ruby On Rails application.

# Installing [kDeploy][kdeploy]

As long as your platform supports Python, Apache, PHP etc you can install [kDeploy][kdeploy]. Since only work on Ubuntu servers and OSX development machines, we will cover these two platforms.

## Ubuntu

For installation on Ubuntu, checkout the kms repository https://github.com/Kunstmaan/kms, when that's installed you can install kdeploy by doing: 

```bash
cd /opt
git clone git@github.com:Kunstmaan/kDeploy.git
cd kDeploy/tools
gcc -o hupapache hupapache.c
gcc -o logrotate logrotate.c
chmod u+s logrotate
chmod u+s hupapache
cp config.xml-dist config.xml
```
	
Only a few manual edits are needed. Edit /etc/fstab and add noatime and acl to the disks

Now edit /opt/kDeploy/tools/config.xml and make sure nagios is set to /home/projects/frontX/site/nagios.xml. The configuration for develmode in /opt/kDeploy/tools/config.xml should be false and mailserver is set to "localhost". Cron should be anacron.

## OSX Lion

First off, we will need to configure some basic settings for the users we will be working with.

```bash
sudo dscl . -append /Groups/staff GroupMembership <your username here>
sudo dscl . -create /Users/root UserShell /bin/bash
```

Make sure you have the latest [XCode][xcode] installed and afterwards install [Homebrew][homebrew] using the following commands.

```bash
ruby <(curl -fsSkL raw.github.com/mxcl/homebrew/go)
brew update
```

Become root and export your own user in a variable. We will need this because [Homebrew][homebrew] runs as your own user.

```bash
sudo -i
export INSTALLUSER="<username here>"
```

Now let's get started with some compiling action. First some required applications, sit back and relax:

```bash
su - $INSTALLUSER -c "export PATH=/usr/local/bin:$PATH; brew install git optipng jpegoptim bash-completion gnu-tar mysql pwgen wget xmlstarlet"
su - $INSTALLUSER -c "export PATH=/usr/local/bin:$PATH; brew install postgresql --without-ossp-uuid"
ln -s "/usr/local/Library/Contributions/brew_bash_completion.sh" "/usr/local/etc/bash_completion.d"
env ARCHFLAGS="-arch i386 -arch x86_64" easy_install psycopg2
env ARCHFLAGS="-arch i386 -arch x86_64" easy_install MySQL-python
ln -sf /usr/local/bin/gtar /usr/bin/tar
ln -sf /usr/local/bin/xml /usr/local/bin/xmlstarlet
```

After this we will configure [mySQL][mysql] and [PostgreSQL][postgresql]. We will not make them autostart (is annoying on laptops when you are not always developing) but if you want to, check the output of the compiles above for the way how.

When securing your [mySQL][mysql] database, add a root password and remember it, you will need it later.

```bash
su - $INSTALLUSER -c "export PATH=/usr/local/bin:$PATH; unset TMPDIR"
su - $INSTALLUSER -c "export PATH=/usr/local/bin:$PATH; mysql_install_db --verbose --user=$INSTALLUSER --basedir="$(brew --prefix mysql)" --datadir=/usr/local/var/mysql --tmpdir=/tmp"
su - $INSTALLUSER -c "export PATH=/usr/local/bin:$PATH; mysql.server start"
su - $INSTALLUSER -c "export PATH=/usr/local/bin:$PATH; `brew --prefix mysql`/bin/mysql_secure_installation"
```

The [PostgreSQL][postgresql] setup is a bit more involved. If you are unsure about the configs added here, please check the gists that are used below.

```bash
su - $INSTALLUSER -c "export PATH=/usr/local/bin:$PATH; initdb --locale=en_US.UTF-8 --encoding=UTF8 /usr/local/var/postgres"
echo "$(curl -fsSL https://gist.github.com/raw/700531/pg_hba.conf)" >> /usr/local/var/postgres/pg_hba.conf
echo "$(curl -fsSL https://gist.github.com/raw/700533/postgresql.conf)" >> /usr/local/var/postgres/postgresql.conf
echo "$(curl -fsSL https://gist.github.com/raw/446919/sysctl.conf)" > /etc/sysctl.conf
```

At this point you can install some optional extra's and config files

```bash
su - $INSTALLUSER -c "export PATH=/usr/local/bin:$PATH; brew install imagemagick ffmpeg jhead"
echo "$(curl -fsSL https://gist.github.com/raw/446797/git-authorize)" > /usr/local/bin/git-authorize; chmod a+x /usr/local/bin/git-authorize
echo "$(curl -fsSL https://gist.github.com/raw/446802/git-publish)" > /usr/local/bin/git-publish; chmod a+x /usr/local/bin/git-publish
echo "$(curl -fsSL https://gist.github.com/raw/446800/git-share)" > /usr/local/bin/git-share; chmod a+x /usr/local/bin/git-share
echo "$(curl -fsSL https://gist.github.com/raw/446808/keyput)" > /usr/local/bin/keyput; chmod a+x /usr/local/bin/keyput
touch /etc/UPDATE_PROJECT_ALLOWED
```

We will need to create some folders. Our projects will be in /home/projects so they mirror our deployments on the production servers. On OSX /home is hidden and will need to be unhidden.

```bash
ln -sf /var/root/ /root
echo "$(curl -fsSL https://gist.github.com/raw/446747/auto_master)" > /etc/auto_master
automount -vc
mkdir -p /etc/tomcat
echo "$(curl -fsSL https://gist.github.com/raw/671081/tomcat.conf)" > /etc/tomcat/setenv.sh
mkdir -p /home/projects
mkdir -p /home/backupped-projects
mkdir -p /etc/apache2/conf/projects.d
mkdir -p /etc/apache2/logs
mkdir -p /opt/nowebsite
mkdir -p /etc/php5/fpm/pool.d
```
Install some system settings

```bash
mkdir -p /Users/$INSTALLUSER/Projects
chmod -r 777 /Users/$INSTALLUSER/Projects
cd /Users/$INSTALLUSER/Projects
su - $INSTALLUSER -c "export PATH=/usr/local/bin:$PATH; git clone https://github.com/roderik/dotfiles.git"
cd dotfiles
su - $INSTALLUSER -c "export PATH=/usr/local/bin:$PATH; ./bootstrap.sh --force"
./bootstrap.sh --force
```
TODO: insert update-project

```bash
brew tap josegonzalez/php
brew tap homebrew/dupes
brew install freetype
brew install php54 --with-mysql --with-pgsql
brew install php54-apc php54-memcached php54-inclued php54-http php54-oauth php54-ssh2 php54-xdebug php54-intl php54-uploadprogress php54-xhprof php54-http php54-mcrypt php54-yaml php54-imagick php54-solr
```

```ini
zend_extension="/usr/local/Cellar/php54-xdebug/2.2.0/xdebug.so"extension="/usr/local/Cellar/php54-imagick/3.1.0RC2/imagick.so"
extension="/usr/local/Cellar/php54-intl/5.4.3/intl.so"
extension="/usr/local/Cellar/php54-yaml/1.0.1/yaml.so"
extension="/usr/local/Cellar/php54-http/1.7.4/http.so"
extension="/usr/local/Cellar/php54-inclued/0.1.3/inclued.so"
extension="/usr/local/Cellar/php54-memcache/2.2.6/memcache.so"
extension="/usr/local/Cellar/php54-memcached/2.0.1/memcached.so"
extension="/usr/local/Cellar/php54-oauth/1.2.2/oauth.so"
[mongo]
extension="/usr/local/Cellar/php54-mongo/1.2.10/mongo.so"
[xhprof]
extension="/usr/local/Cellar/php54-xhprof/270b75d/xhprof.so"
[ssh2]
extension="/usr/local/Cellar/php54-ssh2/0.11.3/ssh2.so"
[apc]
extension="/usr/local/Cellar/php54-apc/3.1.10/apc.so"
apc.enabled=1
apc.shm_segments=1
apc.shm_size=64M
apc.ttl=7200
apc.user_ttl=7200
apc.num_files_hint=1024
apc.mmap_file_mask=/tmp/apc.XXXXXX
apc.enable_cli=1
```

```
LoadModule php5_module    /usr/local/Cellar/php54/5.4.4/libexec/apache2/libphp5.so
```

After this step, you will need to **reboot** your computer. 

Next up, finishing the [PostgreSQL][postgresql] install

```bash
su - $INSTALLUSER -c "export PATH=/usr/local/bin:$PATH; mysql.server start"
su - $INSTALLUSER -c "export PATH=/usr/local/bin:$PATH; psqlstart"
su - $INSTALLUSER -c "export PATH=/usr/local/bin:$PATH; psql -d template1 -c 'create user smlscript;'"
su - $INSTALLUSER -c "export PATH=/usr/local/bin:$PATH; psql -d template1 -c \"alter user smlscript with password 'sml';\""
su - $INSTALLUSER -c "export PATH=/usr/local/bin:$PATH; psql -d template1 -c \"GRANT SELECT ON pg_shadow TO smlscript;\""
```

Setup [mod_jk][modjk]

```bash
wget http://www.apache.org/dist/tomcat/tomcat-connectors/jk/tomcat-connectors-1.2.37-src.tar.gz
tar vxzf tomcat-connectors-1.2.37-src.tar.gz
cd tomcat-connectors-1.2.37-src/native
./configure --with-apxs=/usr/sbin/apxs
make
make install
/usr/sbin/apxs -a -e -n "jk" mod_jk.so
```

!! In newer apache configurations it is possible that your httpd.conf contains some **IfDefine MACOSXSERVER** statements, if this is the case the module to load mod_jk is in the wrong IfDefine statement. It will only be loaded when it's a MACOSXSERVER, in our case it isn't a MACOSXSERVER so it will never be loaded. To fix this you can copy the code to load the mod_jk module from **IfDefine MACOSXSERVER** to the **IfDefine !MACOSXSERVER** statement.

Setting up [Apache2][apache]

```bash
echo "$(curl -fsSL https://gist.github.com/raw/671099/httpd.conf)" >> /etc/apache2/httpd.conf
```

Install a custom PHP 5.4 binary from [Liip][liip] by running:

```bash
curl -s http://php-osx.liip.ch/install.sh | bash -s force 5.4
```

Edit /usr/local/php5/php.d/99-liip-developer.ini and comment out the "; Liip Zurich" section. Add the following:

```ini
; Kunstmaan
date.timezone = Europe/Brussels
date.default_latitude  = 50.877369
date.default_longitude =  4.684167
```

Next enable apc and xslcache in /usr/local/php5/php.d/50-extension-apc.ini and /usr/local/php5/php.d/50-extension-xslcache.ini.

So now we are finally ready to get the [kDeploy][kdeploy] scripts

```bash
cd /opt
git clone git@github.com:Kunstmaan/kDeploy.git
cd kDeploy/tools
gcc -o hupapache hupapache.c
gcc -o logrotate logrotate.c
chmod u+s logrotate
chmod u+s hupapache
```

Now copy the config.xml-dist to config.xml and edit it to fit your needs. An example for my OSX Lion install below

```xml
	<config>
		<var name="config.scriptsdir" value="/opt/kDeploy/tools/" />
		<var name="config.projectsdir" value="/home/projects/" />
		<var name="config.apacheconfpath" value="/etc/apache2/conf/projects.d/" />
		<var name="config.wwwuser" value="www-data" />
		<var name="config.superuser" value="root" />
		<var name="config.supergroup" value="wheel" />
		<var name="config.skeletonsdir" value="/opt/kDeploy/tools/skeletons/" />
		<var name="config.backupdir" value="/home/backupped-projects/" />
		<var name="config.adminmail" value="support@mycompany.be" />
		<var name="config.mailverbosity" value="2" />
		<var name="config.bigmon" value="/tmp/mon.cf" />
		<var name="config.nagios" value="/tmp/nagios.xml" />
		<var name="config.mysqladminuser" value="root" />
		<var name="config.mysqladminpassword" value="mysupersecretrootpassword" />
		<var name="config.develmode" value="true" />
		<var name="config.mailserver" value="localhost" />
		<var name="config.nomails" value="true" />
		<var name="config.hostmachine" value="apollo.dev" />
		<var name="config.jkversion" value="1" />
		<var name="config.tomcatversion" value="7.0.21" />
		<var name="config.cron" value="no-cron" />
		<var name="config.options">
			<item value="auto-hosts-file" />
		</var>
		<var name="config.postgresuser" value="myusername" />
		<var name="config.catchallserver" value="my.catchall.mailserver.be" />
		<var name="config.hostingdir" value="/tmp" />
	    <var name="config.restorethreads" value="4" />
	    <var name="config.psqlbackupformat" value="custom" />
		<var name="config.psqlrestorefast" value="true" />
		<var name="config.apacheport" value="80" />
	</config>
```

At this point you should be able to run the maintenance script

```bash
cd /opt/kDeploy/tools
python maintenance.py
```

Finally you have to symlink /opt/jdk/default to your Java Home, because the setenv of each java project exports /opt/jdk/default as your JAVA_HOME.

```bash
mkdir /opt/jdk
ln -s /System/Library/Java/JavaVirtualMachines/1.6.0.jdk/Contents/Home /opt/jdk/default
```

# Installing Chef

```bash
echo "deb http://apt.opscode.com/ `lsb_release -cs`-0.10 main" | sudo tee /etc/apt/sources.list.d/opscode.list
sudo mkdir -p /etc/apt/trusted.gpg.d
gpg --keyserver keys.gnupg.net --recv-keys 83EF826A
gpg --export packages@opscode.com | sudo tee /etc/apt/trusted.gpg.d/opscode-keyring.gpg > /dev/null
yes | sudo apt-get update
yes | sudo apt-get install opscode-keyring
yes | sudo apt-get dist-upgrade
yes | sudo apt-get install chef
```

```bash
echo "$(curl -fsSL https://gist.github.com/raw/c3d4107441b4c99a7245/ca3be7e8e806dd608bebf627b1c60ea7e15be375/client.rb)" > /etc/chef/client.rb 
echo "$(curl -fsSL https://gist.github.com/raw/c3d4107441b4c99a7245/c25d0d89fb05f3dc0b00faaaa8ece6990d22644d/validation.pem)" > /etc/chef/validation.pem
/etc/init.d/chef-client restart
tail -f /var/log/chef/client.log
```

Then add your client to the "nucleus" group in the webinterface
	
# Using [kDeploy][kdeploy]

All kDeploy commands should be executed as root in /opt/kDeploy/tools

## newproject.py

Creates a new project. All suggested values are good, so just accept them.

	python newproject.py <myprojectname>
	
The result is an empty project. We need to add skeletons to make it do something.

## applyskel.py

Adds skeletons to your project, that setup features and configurations. Skeletons have dependencies on eachother, so install only the ones you need, the rest will be pulled in.

	python applyskel.py <myprojectname> <skeletonname>

The current list of skeletons are:

* anacron: adds anacronjobs to your project
* apache: adds apache to your project
* awstats: adds awstats statistics to your project
* base: is the skeleton that is used to do newproject. Is not installable by hand
* cgi: adds a perl cgi-bin to your project
* dailycron: depreciated
* fcron: depreciated
* logrotate: adds apache logrotating to your project
* mysql: adds a mysql database to your project
* nagios: adds the configuration for nagios monitoring to your project
* php5: adds PHP5 to your project
* play: adds the loadbalancing setup for Play! Framework to your project
* postgres: adds a postgresql database to your project
* smartms: is a collection skeleton that adds everything you need for an OpenMercury project
* symfony: sets up a correctly configures Symfony2 projects. Downloads the latest version.
* solr: adds a solr instance to your project
* tomcat: adds a tomcat container to your project

## maintenance.py

Maintenance is the hart of kDeploy. It will, by default, generate all configurations and fix all permissions. 

```bash
python maintenance.py
```

Since a shared server, or lange dedicated server contains a large number of files, fixing permissions on all projects will take a while. So a quick option is available that skips this. If you use this, you will have to use fixperms.py to fix the permissions for your project.

```bash
python maintenance.py quick
```

## fixperms.py

Fixperms will set the ownership and permissions for one project.

```bash
python fixperms.py <projectname>
```

## fixcron.py

Fixcron will configure the cronjobs for the current project by combining the anacrontab from <projectfolder>/config/anacrontab and the anacrontab from <projectfolder>/data/<projectname>/app/conf/anacrontab (if this is available).

```bash
python fixcron.py <projectname>
```

## backups.py

Backups is the strength of the kDeploy system. It will backup everything for this project in one tar.gz file. This file can be deployed on another server or dev machine and after extracting and running maintenance, it is fully operational. 

```bash
python backups.py <projectname>
```

While installing, you might have installed the optional update-project script. This script will do a quicker sync using rsync after the first full restore. This means creating a full tar.gz is a bit overkill. A quick parameter will fix this.

```bash
python backups.py <projectname> quick
```

## removeproject.py

Removes the project from the machine, after creating a tar.gz for backup purposes.

```bash
python removeproject.py <projectname>
```

## passwordscript.py

Sets ssh, ftp, awstats and tomcat passwords

```bash
python passwordscript.py <projectname>
```

These passwords are not synced when running backup! So moving a project will invalidate most of these passwords.

## makereport.py

Reports on disk usage and used traffic to STOUT

```bash
python makereport.py <projectname>
```

## doinit.py

Starts all tomcats and other applications with a defined init.d folder in the project. This does not work reliably.

```bash
python doinit.py
```

# Important files

There are several files in a project that need some explaining.

## conf/config.xml

The base configuration for your project. This file contains database credentials, paths, ip addresses, domainnames. The first place you look when changing something.

````xml
<?xml version="1.0" ?><config>  
  <var name="project.dir" value="/home/projects/phptest"/>  
  <var name="project.url" value="phptest.kunstmaan.be"/>  
  <var name="project.aliases" value=""/>  
  <var name="project.user" value="phptest"/>  
  <var name="project.statsurl" value="stats.phptest.kunstmaan.be"/>  
  <var name="project.nagiosuri" value="/"/>  
  <var name="project.admin" value="support@kunstmaan.be"/>  
  <var name="project.ip" value="172.18.24.45"/>  
  <var name="project.name" value="phptest"/>  
  <var name="project.group" value="phptest"/>  
  <var name="project.skeletons">    
    <item value="awstats"/>    
    <item value="anacron"/>    
    <item value="fcron"/>    
    <item value="logrotate"/>    
    <item value="base"/>    
    <item value="apache"/>    
    <item value="php5"/>    
    <item value="nagios"/>    
  </var>  
</config>
```

## conf/permissions.xml

Contains entries that describe the settings facl will use to set the permissions for the folders in the project. 

```xml
  <var name="/site">    
    <item value="-R -m user::rwX"/>    
    <item value="-R -m group::r-X"/>    
    <item value="-R -m other::---"/>    
    <item value="-R -m u:@config.wwwuser@:r-X"/>    
  </var>  
```

## conf/ownership.xml

Contains entries that describe the values used with chmod to define the ownership of the files in your project.

```xml
<var name="/site" value="-R @project.user@.@project.group@"/>  
```

## conf/anacrontab

The cronjobs for this project. One default cronjob is always present, this runs one at night to logrotate, generate awstats etc. Other crons should be defined here.

```
MAILTO=cron@kunstmaan.be
0 3 * * * /bin/bash /home/projects/phptest/cron/anacronjobs
```

## conf/backup.xml

Defines the folders that should be excluded from the tar.gz generation.

```xml
<?xml version="1.0" ?><config>  
  <var name="backup.excludes">    
    <item value="/nobackup/"/>    
    <item value="/resizedcache/"/>    
  </var>  
</config>
```

## conf/nagios.xml

The configuration for our Nagios instance

```xml
<project>
	<monitor>true</monitor>
	<name>@project.name@</name>
	<url>@project.url@</url>
	<uri>/view/nl/selftest</uri>
	<regexp>self test okay</regexp>
	<notification_interval>60</notification_interval>
	<warning>90</warning>
	<critical>15</critical>
	<contact_groups>
		<!-- <group>GROUP_NAME</group> -->
	</contact_groups>
	<contacts>
		<!--<contact>CONTANT_NAME</contact>-->
	</contacts>
</project>
```

## conf/apache.d/*

These files will generate (when running maintenance) the content of the Apache vhost. 

[kdeploy]: https://github.com/Kunstmaan/kDeploy "kDeploy"
[kunstmaan]: http://www.kunstmaan.be "Kunstmaan"
[xcode]: http://developer.apple.com/xcode/ "XCode 4"
[homebrew]: http://mxcl.github.com/homebrew/ "Homebrew"
[liip]: http://php-osx.liip.ch/ "Liip"
[mysql]: http://www.mysql.com/ "mySQL"
[postgresql]: http://www.postgresql.org/ "PostgreSQL"
[modjk]: http://tomcat.apache.org/connectors-doc/ "mod_jk"
[apache]: http://httpd.apache.org/ "Apache"
