#!/bin/bash

type -P xmlstarlet &>/dev/null || { echo "I require xmlstarlet but it's not installed.  Aborting." >&2; exit 1; }
ROOT=`xmlstarlet sel -t -v "/config/var[@name='config.scriptsdir']/@value" ../src/config.xml 2>/dev/null`

PROJECT="$1"

if [ "$PROJECT" = "" ]; then
	echo "no project given"
	exit 1
fi

if [ -d "/home/projects/$PROJECT/data/$PROJECT" ]; then
	echo "OpenMercury already installed into $PROJECT"
	exit 1
fi

echo "PREPARING"
cat << END

***** HELP ********


	* MAKE SURE YOUR OPENMERCURY IS UP TO DATE
	* If you are following the development manual, just continue
	* If you are setting up a project by hand, please keep the following in mind:
		* create a project using the kdeploy tools:
			* cd /opt/kDeploy/tools
			* python newproject.py <projectname>
			* python applyskel.py <projectname> smartcms

	* THIS SCRIPT DOESN'T SUPPORT MYSQL
	* IF YOU WANT A MYSQL PROJECT, ASK FRANK

 _____________________________________________________________________
|                                                                     |
| At this point you can still abort if there are problems.            |
| Abort by pressing CTRL-C                                            |
| If everything is fine, press ENTER to continue                      |
|_____________________________________________________________________|

END
read nonsense

HOSTMACHINE="`xmlstarlet sel -t -v "/config/var[@name='config.hostmachine']/@value" ../src/config.xml`"

function runMaintenance {
	echo "running fixperms and maintenance"
	cd $ROOT
	python fixperms.py $1
	python maintenance.py quick
}

function xmlsel {
	xmlstarlet sel -t -v "$1" /home/projects/$PROJECT/conf/config.xml 2>/dev/null
}

function emit_psql {
	echo "update cmsconfig set uploadcache='/home/projects/$PROJECT/uploadcache';"
	echo "update cmsconfig set filestore='/home/projects/$PROJECT/filestore';"
	echo "update cmsconfig set resizedcache='/home/projects/$PROJECT/resizedcache';"
	echo "update cmsconfig set project_name='$PROJECT';"
	echo "update cmsconfig set rootpath=NULL;"
	echo "update cmsconfig set siterooturl='http://$PROJECT.$HOSTMACHINE';"
	echo "update mailcounter set nbmails=0;"
}

function emit_sml_database_psql {
	DBUSER="`xmlsel "/config/var[@name='project.dbuser']/@value"`"
	DBPASS="`xmlsel "/config/var[@name='project.dbpass']/@value"`"
	DBNAME="`xmlsel "/config/var[@name='project.dbname']/@value"`"
	echo  "<datasource>"
	echo  "<driver>org.postgresql.Driver</driver>"
	echo  "<hostname>localhost</hostname>"
	echo  "<username>$DBUSER</username>"
	echo  "<password>$DBPASS</password>"
	echo  "<dburl>jdbc:postgresql://localhost/$DBNAME</dburl>"
	echo  "</datasource>"
}

function emit_build_properties {
	TOMCATPWD="`xmlstarlet sel -t -v "/tomcat-users/user[@name='manager']/@password" /home/projects/$PROJECT/tomcat/default/conf/tomcat-users.xml`"
	if [ "$TOMCATPWD" = "" ]; then
		TOMCATPWD="`xmlstarlet sel -t -v "/tomcat-users/user[@username='manager']/@password" /home/projects/$PROJECT/tomcat/default/conf/tomcat-users.xml`"
	fi
	echo "app.name=$PROJECT"
	echo "app.path=/"
	echo "catalina.home=/home/projects/$PROJECT/tomcat/default"
	echo "manager.username=manager"
	echo "manager.password=$TOMCATPWD"
	echo "manager.url=http://$PROJECT.$HOSTMACHINE/manager"
	echo "tomcat.sudo_command=sudo"
}

function emit_exports_sh {
	echo "export CLASSPATH=$CLASSPATH:/home/projects/$PROJECT/tomcat/default/lib/catalina-ant.jar"
	echo "export JAVA_HOME=/opt/jdk/default"
	echo "export PATH=$PATH:/opt/ant/bin"
}

function emit_build_xml {
	echo "FIXING AND LINKING BUILD.XML"
	/bin/ls /home/projects/$PROJECT/data/$PROJECT/build*xml | while read B
	do
		BB=`basename $B`
		echo fixing $BB
		cat $B | sed -e "s/openmercury/$PROJECT/g;" | sed -e "s/smartcms/$PROJECT/g;" > /home/projects/$PROJECT/data/$PROJECT/$BB.new
		mv /home/projects/$PROJECT/data/$PROJECT/$BB.new /home/projects/$PROJECT/data/$PROJECT/$BB
	done
	ln -sf build-default.xml build.xml
}

function tryLocalOpenMercury {
	echo "Trying local openmercury"
	if [ -d /home/projects/openmercury/data/OpenMercury/.git ]; then
		#todo exclude unpushed changes
		git remote add tmp /home/projects/openmercury/data/OpenMercury/.git || exit 1
		git fetch tmp || exit 1
		git merge tmp/master
		git remote rm tmp
	else
		echo "NO LOCAL OPENMERCURY FOUND"
		echo "GOING DIRECTLY TO GIT SERVER. THIS WILL BE SLOW"
	fi
}

function setupGitWorkflow {
	echo "CHECKING OUT SMARTCMS FROM GIT"
	mkdir /home/projects/$1/data/$1 || exit 1
	cd /home/projects/$1/data/$1 || exit 1
	git init || exit 1
	touch .placeholder
	git add .placeholder
	git commit -m "Start project $1"
	tryLocalOpenMercury
	git remote add openmercury git@github.com:Kunstmaan/OpenMercury.git || exit 1
	git fetch openmercury
	git config core.filemode false || exit 1
	git flow init
}

function setupDatabase {
	if [ "`xmlsel "/config/var[@name='project.dbuser']/@value"`" = "" ] ; then
		echo "CREATING AN EMPTY MYSQL DATABASE"
		echo "not implemented"
		exit 1
	else
		echo "CREATING AN EMPTY POSTGRES DATABASE"
		DBUSER="`xmlsel "/config/var[@name='project.dbuser']/@value"`"
		DBPASS="`xmlsel "/config/var[@name='project.dbpass']/@value"`"
		DBNAME="`xmlsel "/config/var[@name='project.dbname']/@value"`"
		export PGPASSWORD=$DBPASS
		cat /home/projects/$1/data/$1/docs/database.sql |  psql -U$DBNAME $DBNAME || exit 1
		emit_psql | psql -U$DBNAME $DBNAME || exit 1
		echo "GENERATING SML_DATABASE SETTINGS"
		emit_sml_database_psql | xmlstarlet fo > /home/projects/$1/data/$1/WebRoot/WEB-INF/sml_database.xml
	fi
}

function setupEclipseSettings {
	echo "SETTING UP ECLIPSE"
	mkdir -p /home/projects/$1/data/$1/.settings || exit 1
	emit_org_eclipse_wst_common_component $1 || exit 1
	emit_org_eclipse_wst_common_project_facet_core_xml $1 || exit 1
	emit_org_eclipse_wst_jsdt_ui_superType_container $1 || exit 1
	emit_org_eclipse_wst_jsdt_ui_superType_name $1 || exit 1
	emit_jsdtscope $1  || exit 1
	emit_build_properties > build.properties || exit 1
	emit_exports_sh > /home/projects/$1/data/$1/exports.sh || exit 1
	emit_project $1 || exit 1
	emit_classpath $1 || exit 1
	emit_build_xml $1 || exit 1
}

function emit_jsdtscope {
	echo "GENERATING .jsdtscope FILE"
	cat $ROOT/../scripts/settings/.jsdtscope | sed -e "s/openmercury/$1/g;" | sed -e "s/smartcms/$1/g;" > /home/projects/$1/data/$1/.settings/.jsdtscope || exit 1
}

function emit_org_eclipse_wst_jsdt_ui_superType_name {
	echo "GENERATING org.eclipse.wst.jsdt.ui.superType.name FILE"
	cat $ROOT/../scripts/settings/org.eclipse.wst.jsdt.ui.superType.name | sed -e "s/openmercury/$1/g;" | sed -e "s/smartcms/$1/g;" > /home/projects/$1/data/$1/.settings/org.eclipse.wst.jsdt.ui.superType.name || exit 1
}

function emit_org_eclipse_wst_jsdt_ui_superType_container {
	echo "GENERATING org.eclipse.wst.jsdt.ui.superType.container FILE"
	cat $ROOT/../scripts/settings/org.eclipse.wst.jsdt.ui.superType.container | sed -e "s/openmercury/$1/g;" | sed -e "s/smartcms/$1/g;" > /home/projects/$1/data/$1/.settings/org.eclipse.wst.jsdt.ui.superType.container || exit 1
}

function emit_org_eclipse_wst_common_project_facet_core_xml {
	echo "GENERATING org.eclipse.wst.common.project.facet.core.xml FILE"
	cat $ROOT/../scripts/settings/org.eclipse.wst.common.project.facet.core.xml | sed -e "s/openmercury/$1/g;" | sed -e "s/smartcms/$1/g;" > /home/projects/$1/data/$1/.settings/org.eclipse.wst.common.project.facet.core.xml || exit 1
}

function emit_org_eclipse_wst_common_component {
	echo "GENERATING org.eclipse.wst.common.component FILE"
	cat $ROOT/../scripts/scripts/settings/org.eclipse.wst.common.component | sed -e "s/openmercury/$1/g;" | sed -e "s/smartcms/$1/g;" > /home/projects/$1/data/$1/.settings/org.eclipse.wst.common.component || exit 1
}

function emit_org_eclipse_jdt_core_prefs {
	echo "GENERATING org.eclipse.jdt.core.prefs FILE"
	
}

function emit_project {
	echo "GENERATING .PROJECT FILE"
	cat /home/projects/$1/data/$1/.project  | sed -e "s/openmercury/$1/g;" | sed -e "s/smartcms/$1/g;" > /tmp/p.$$ || exit 1
	cat /tmp/p.$$ > /home/projects/$1/data/$1/.project || exit 1
}

function emit_classpath {
	echo "GENERATING .CLASSPATH FILE"
	cp -f /home/projects/$1/data/$1/.classpath-default /home/projects/$1/data/$1/.classpath || exit 1
}


echo "okay let's go"
runMaintenance $PROJECT || exit 1
setupGitWorkflow $PROJECT || exit 1

cd /home/projects/$PROJECT/data/$PROJECT || exit 1
if [ -f build.xml ] ; then
	rm -f build.xml
fi

setupDatabase $PROJECT || exit 1
setupEclipseSettings $PROJECT || exit 1


echo "CREATING FIRST COMMIT"
cd /home/projects/$PROJECT/data/$PROJECT/ || exit 1
git add .project || exit 1
git add exports.sh || exit 1
git add WebRoot/WEB-INF/sml_database.xml || exit 1
git add build-default.xml || exit 1
git config core.filemode false
git commit -n -m "Initial commit of project $PROJECT : basic configuration files"

cat << END

***** HELP ********
 _____________________________________________________________________
|                                                                     |
| At this point you are done, just some cleaning up to do             |
| Abort by pressing CTRL-C                                            |
| If everything is fine, press ENTER to continue                      |
|_____________________________________________________________________|

END
read nonsense

echo "FINISHING"
runMaintenance $PROJECT
echo 
echo
echo "FINISHED"
echo "========"
echo "Project name: $PROJECT"
echo "Database name: $DBNAME"
echo "Database user: $DBUSER"
echo "Database password: $DBPASS"
echo
echo
echo "now just 'git share $PROJECT' to put this project on the git server'"
